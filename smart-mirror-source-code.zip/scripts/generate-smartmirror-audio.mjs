import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const sampleRate = 22050;
const duration = 10;
const frames = sampleRate * duration;
const outputDir = join(process.cwd(), "public", "audio");
mkdirSync(outputDir, { recursive: true });

const progressions = [
  [48, 55, 57, 53], [50, 57, 59, 55], [53, 60, 57, 55], [45, 52, 53, 50],
  [52, 59, 55, 57], [47, 54, 50, 52], [55, 62, 59, 60], [43, 50, 52, 47],
  [51, 58, 55, 56], [49, 56, 52, 54],
];

const midi = (note) => 440 * 2 ** ((note - 69) / 12);
const envelope = (position, length, attack = 0.08, release = 0.18) => {
  const x = position / length;
  return Math.min(1, x / attack, (1 - x) / release);
};

function addTone(buffer, start, length, frequency, gain, brightness = 0.25) {
  const first = Math.max(0, Math.floor(start * sampleRate));
  const count = Math.min(frames - first, Math.floor(length * sampleRate));
  for (let index = 0; index < count; index += 1) {
    const time = index / sampleRate;
    const env = Math.max(0, envelope(index, count));
    const fundamental = Math.sin(2 * Math.PI * frequency * time);
    const harmonic = Math.sin(2 * Math.PI * frequency * 2 * time) * brightness;
    const velvet = Math.sin(2 * Math.PI * frequency * 0.5 * time) * 0.12;
    buffer[first + index] += (fundamental + harmonic + velvet) * env * gain;
  }
}

function makeTrack(trackIndex) {
  const samples = new Float64Array(frames);
  const roots = progressions[trackIndex];
  const chordLength = duration / 4;
  roots.forEach((root, chordIndex) => {
    const start = chordIndex * chordLength;
    [0, 4, 7, 11].forEach((offset, voice) => {
      addTone(samples, start, chordLength, midi(root + offset), 0.075 / (1 + voice * 0.12), 0.12);
    });
    for (let beat = 0; beat < 4; beat += 1) {
      const note = root + [12, 16, 19, 23][(beat + trackIndex) % 4];
      addTone(samples, start + beat * (chordLength / 4), 0.52, midi(note), 0.12, 0.38);
      addTone(samples, start + beat * (chordLength / 4) + 0.31, 0.28, midi(note + 7), 0.055, 0.45);
    }
  });
  for (let beat = 0; beat < 16; beat += 1) {
    const root = roots[Math.floor(beat / 4)];
    addTone(samples, beat * 0.625, 0.34, midi(root - 12), 0.085, 0.08);
  }
  const pcm = Buffer.alloc(frames * 2);
  for (let index = 0; index < frames; index += 1) {
    const soft = Math.tanh(samples[index] * 1.35) * 0.78;
    pcm.writeInt16LE(Math.round(soft * 32767), index * 2);
  }
  const wav = Buffer.alloc(44 + pcm.length);
  wav.write("RIFF", 0);
  wav.writeUInt32LE(36 + pcm.length, 4);
  wav.write("WAVEfmt ", 8);
  wav.writeUInt32LE(16, 16);
  wav.writeUInt16LE(1, 20);
  wav.writeUInt16LE(1, 22);
  wav.writeUInt32LE(sampleRate, 24);
  wav.writeUInt32LE(sampleRate * 2, 28);
  wav.writeUInt16LE(2, 32);
  wav.writeUInt16LE(16, 34);
  wav.write("data", 36);
  wav.writeUInt32LE(pcm.length, 40);
  pcm.copy(wav, 44);
  writeFileSync(join(outputDir, `smart-lounge-${String(trackIndex + 1).padStart(2, "0")}.wav`), wav);
}

for (let track = 0; track < progressions.length; track += 1) makeTrack(track);
