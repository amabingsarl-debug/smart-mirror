from __future__ import annotations

import os
import re
import logging
import json
import base64
import hashlib
import uuid
import time
import tempfile
import threading
import subprocess
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests
import firebase_admin
from firebase_admin import auth as firebase_auth, messaging as firebase_messaging
from firebase_functions import https_fn, options, scheduler_fn
from genblaze_core import Asset, KeyStrategy, Modality, ObjectStorageSink, Pipeline
from genblaze_core.models.step import Step
from genblaze_core.providers.base import SyncProvider
from genblaze_core.runnable.config import RunnableConfig
from genblaze_s3 import S3StorageBackend
from google import genai
from PIL import Image, ImageChops, ImageDraw, ImageFilter

if not firebase_admin._apps:
    firebase_admin.initialize_app()


def _authenticated_uid(request: https_fn.Request) -> str:
    authorization = str(request.headers.get("Authorization") or "")
    if not authorization.startswith("Bearer "):
        raise PermissionError("Authentification requise.")
    decoded = firebase_auth.verify_id_token(authorization[7:].strip())
    uid = str(decoded.get("uid") or "").strip()
    if not uid or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", uid):
        raise PermissionError("Compte invalide.")
    return uid


def _optional_authenticated_uid(request: https_fn.Request) -> str:
    try:
        return _authenticated_uid(request)
    except Exception:
        return ""


def _b2_backend() -> S3StorageBackend:
    return S3StorageBackend.for_backblaze(
        os.environ["B2_BUCKET_NAME"].strip(),
        region=os.environ["B2_REGION"].strip(),
        key_id=os.environ["B2_KEY_ID"].strip(),
        app_key=os.environ["B2_APP_KEY"].strip(),
    )


def _load_account_snapshot(backend: S3StorageBackend, uid: str):
    key = f"smartmirror/accounts/{uid}/state.json"
    if not uid or not backend.exists(key):
        return None, None
    snapshot = json.loads(backend.get(key).decode("utf-8"))
    if snapshot.get("version") != 1 or not isinstance(snapshot.get("values"), dict):
        return None, None
    return key, snapshot


def _append_tryon_to_account_state(uid: str, response_payload: dict, request_payload: dict) -> None:
    """Keep a completed try-on when the browser closes before receiving it."""
    backend = _b2_backend()
    key, snapshot = _load_account_snapshot(backend, uid)
    if not key or not snapshot:
        return
    values = snapshot["values"]
    try:
        wardrobe = json.loads(values.get("smartmirror-wardrobe", "[]"))
    except Exception:
        wardrobe = []
    if not isinstance(wardrobe, list):
        wardrobe = []
    manifest_hash = str(response_payload.get("manifestHash") or "")
    image_url = str(response_payload.get("imageUrl") or "")
    if not image_url or any(str(item.get("manifestHash") or "") == manifest_hash for item in wardrobe if isinstance(item, dict)):
        return
    wardrobe.append({
        "id": int(time.time() * 1000), "name": "Mon look SMART MIRROR",
        "type": str(request_payload.get("garmentType") or "auto"),
        "size": str(request_payload.get("garmentSize") or "AUTO"),
        "image": image_url, "images": response_payload.get("images") or {},
        "garmentFront": request_payload.get("garmentFront") or "",
        "garmentBack": request_payload.get("garmentBack") or "",
        "manifestHash": manifest_hash,
        "backgroundColors": response_payload.get("backgroundColors"),
        "backgroundGradients": response_payload.get("backgroundGradients"),
        "garmentReferenceCount": response_payload.get("garmentReferenceCount"),
        "unreadTryOn": True,
    })
    values["smartmirror-wardrobe"] = json.dumps(wardrobe, ensure_ascii=False, separators=(",", ":"))
    snapshot["savedAt"] = datetime.now(timezone.utc).isoformat()
    backend.put(key, json.dumps(snapshot, ensure_ascii=False, separators=(",", ":")).encode("utf-8"), content_type="application/json")


def _attach_video_to_account_state(uid: str, source_manifest: dict, video_manifest: dict) -> None:
    """Attach a completed Kling task to its cloud Studio try-on."""
    manifest_hash = str(source_manifest.get("tryOnManifestHash") or "")
    if not uid or not manifest_hash:
        return
    backend = _b2_backend()
    key, snapshot = _load_account_snapshot(backend, uid)
    if not key or not snapshot:
        return
    values = snapshot["values"]
    try:
        wardrobe = json.loads(values.get("smartmirror-wardrobe", "[]"))
    except Exception:
        wardrobe = []
    changed = False
    for item in wardrobe if isinstance(wardrobe, list) else []:
        if isinstance(item, dict) and str(item.get("manifestHash") or "") == manifest_hash:
            item.update({"videoTaskId": video_manifest.get("taskId"),
                         "videoBackgroundColor": video_manifest.get("backgroundColor"),
                         "videoHasAudio": bool(video_manifest.get("audioIncluded")),
                         "unreadVideo": True})
            changed = True
            break
    if changed:
        values["smartmirror-wardrobe"] = json.dumps(wardrobe, ensure_ascii=False, separators=(",", ":"))
        snapshot["savedAt"] = datetime.now(timezone.utc).isoformat()
        backend.put(key, json.dumps(snapshot, ensure_ascii=False, separators=(",", ":")).encode("utf-8"), content_type="application/json")


def _send_user_push(uid: str, title: str, body: str, url: str) -> int:
    if not uid:
        return 0
    backend = _b2_backend()
    key = f"smartmirror/accounts/{uid}/devices.json"
    if not backend.exists(key):
        return 0
    record = json.loads(backend.get(key).decode("utf-8"))
    tokens = [str(token) for token in record.get("tokens", []) if token]
    if not tokens:
        return 0
    messages = [firebase_messaging.Message(
        notification=firebase_messaging.Notification(title=title, body=body),
        data={"url": url, "kind": "smartmirror-ready"},
        webpush=firebase_messaging.WebpushConfig(
            fcm_options=firebase_messaging.WebpushFCMOptions(link=url),
            notification=firebase_messaging.WebpushNotification(icon="/icons/icon-192.png", badge="/icons/icon-192.png"),
        ),
        token=token,
    ) for token in tokens]
    response = firebase_messaging.send_each(messages)
    valid_tokens = [token for token, result in zip(tokens, response.responses) if result.success or "registration-token-not-registered" not in str(result.exception)]
    if valid_tokens != tokens:
        backend.put(key, json.dumps({"tokens": valid_tokens, "updatedAt": datetime.now(timezone.utc).isoformat()}).encode("utf-8"), content_type="application/json")
    return response.success_count


@https_fn.on_request(
    region="us-central1", timeout_sec=60, memory=options.MemoryOption.MB_256,
    secrets=["B2_KEY_ID", "B2_APP_KEY", "B2_BUCKET_NAME", "B2_REGION"],
)
def push_device(request: https_fn.Request) -> https_fn.Response:
    headers = cors_headers(request)
    if request.method == "OPTIONS":
        return https_fn.Response("", status=204, headers=headers)
    try:
        uid = _authenticated_uid(request)
        payload = request.get_json(silent=True) or {}
        token = str(payload.get("token") or "").strip()
        if not token or len(token) > 4096:
            raise ValueError("Jeton de notification invalide.")
        backend = _b2_backend()
        key = f"smartmirror/accounts/{uid}/devices.json"
        current = json.loads(backend.get(key).decode("utf-8")) if backend.exists(key) else {"tokens": []}
        tokens = [str(item) for item in current.get("tokens", []) if item]
        if payload.get("action") == "unregister":
            tokens = [item for item in tokens if item != token]
        elif token not in tokens:
            tokens.append(token)
        tokens = tokens[-10:]
        backend.put(key, json.dumps({"tokens": tokens, "updatedAt": datetime.now(timezone.utc).isoformat()}).encode("utf-8"), content_type="application/json")
        return https_fn.Response(json.dumps({"registered": payload.get("action") != "unregister", "devices": len(tokens)}), status=200, headers=headers, content_type="application/json")
    except PermissionError as exc:
        return https_fn.Response(json.dumps({"error": str(exc)}), status=401, headers=headers, content_type="application/json")
    except Exception as exc:
        logging.exception("SMART MIRROR push device failed")
        return https_fn.Response(json.dumps({"error": str(exc)[:200]}), status=500, headers=headers, content_type="application/json")


@https_fn.on_request(
    region="us-central1",
    timeout_sec=120,
    memory=options.MemoryOption.MB_512,
    secrets=["B2_KEY_ID", "B2_APP_KEY", "B2_BUCKET_NAME", "B2_REGION"],
)
def account_state(request: https_fn.Request) -> https_fn.Response:
    """Private per-user SMART MIRROR state stored in the existing B2 bucket."""
    headers = cors_headers(request)
    if request.method == "OPTIONS":
        return https_fn.Response("", status=204, headers=headers)
    try:
        uid = _authenticated_uid(request)
        backend = S3StorageBackend.for_backblaze(
            os.environ["B2_BUCKET_NAME"].strip(),
            region=os.environ["B2_REGION"].strip(),
            key_id=os.environ["B2_KEY_ID"].strip(),
            app_key=os.environ["B2_APP_KEY"].strip(),
        )
        object_key = f"smartmirror/accounts/{uid}/state.json"
        if request.method == "GET":
            if not backend.exists(object_key):
                return https_fn.Response(json.dumps({"error": "Aucune sauvegarde."}), status=404, headers=headers, content_type="application/json")
            return https_fn.Response(backend.get(object_key), status=200, headers={**headers, "Cache-Control": "no-store"}, content_type="application/json")
        if request.method != "POST":
            return https_fn.Response(json.dumps({"error": "Méthode non autorisée."}), status=405, headers=headers, content_type="application/json")
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict) or payload.get("version") != 1 or not isinstance(payload.get("values"), dict):
            raise ValueError("Sauvegarde invalide.")
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        if len(raw) > 30 * 1024 * 1024:
            raise ValueError("La sauvegarde du compte dépasse 30 Mo.")
        backend.put(object_key, raw, content_type="application/json")
        return https_fn.Response(json.dumps({"saved": True, "sizeBytes": len(raw)}), status=200, headers=headers, content_type="application/json")
    except PermissionError as exc:
        return https_fn.Response(json.dumps({"error": str(exc)}), status=401, headers=headers, content_type="application/json")
    except Exception as exc:
        logging.exception("SMART MIRROR account state failed")
        return https_fn.Response(json.dumps({"error": "La sauvegarde du compte a échoué.", "detail": str(exc)[:200]}), status=500, headers=headers, content_type="application/json")


SMART_MIRROR_AUDIO_COUNT = 10


def _video_audio_track(task_id: str, requested: object = None) -> int:
    try:
        value = int(requested)
        if 1 <= value <= SMART_MIRROR_AUDIO_COUNT:
            return value
    except (TypeError, ValueError):
        pass
    return (int(hashlib.sha256(task_id.encode("utf-8")).hexdigest()[:8], 16) % SMART_MIRROR_AUDIO_COUNT) + 1


def _mix_video_with_smartmirror_audio(video_bytes: bytes, track_number: int) -> bytes:
    import imageio_ffmpeg
    audio_url = f"https://smartmirror-ci.web.app/audio/smart-lounge-{track_number:02d}.wav?v=2"
    audio_response = requests.get(audio_url, timeout=30)
    audio_response.raise_for_status()
    with tempfile.TemporaryDirectory(prefix="smartmirror-mux-") as directory:
        video_path = Path(directory) / "input.mp4"
        audio_path = Path(directory) / "music.wav"
        output_path = Path(directory) / "smartmirror-with-audio.mp4"
        video_path.write_bytes(video_bytes)
        audio_path.write_bytes(audio_response.content)
        command = [
            imageio_ffmpeg.get_ffmpeg_exe(), "-y", "-i", str(video_path), "-stream_loop", "-1", "-i", str(audio_path),
            "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k",
            "-shortest", "-movflags", "+faststart", str(output_path),
        ]
        completed = subprocess.run(command, capture_output=True, timeout=90, check=False)
        if completed.returncode != 0 or not output_path.exists():
            raise RuntimeError(f"Fusion audio MP4 impossible: {completed.stderr.decode('utf-8', errors='ignore')[-500:]}")
        mixed = output_path.read_bytes()
        if not mixed:
            raise RuntimeError("La vidéo fusionnée est vide.")
        return mixed


def _measure_video_background_color(video_bytes: bytes) -> str:
    """Measure the real flat background from a rendered frame without altering the video."""
    import imageio_ffmpeg
    with tempfile.TemporaryDirectory(prefix="smartmirror-video-color-") as directory:
        video_path = Path(directory) / "source.mp4"
        frame_path = Path(directory) / "frame.png"
        video_path.write_bytes(video_bytes)
        command = [
            imageio_ffmpeg.get_ffmpeg_exe(), "-y", "-ss", "0.5", "-i", str(video_path),
            "-frames:v", "1", str(frame_path),
        ]
        completed = subprocess.run(command, capture_output=True, timeout=60, check=False)
        if completed.returncode != 0 or not frame_path.exists():
            return "#e8e5dc"
        with Image.open(frame_path) as image:
            rgb = image.convert("RGB")
            width, height = rgb.size
            sample_width = max(4, int(width * 0.08))
            sample_height = max(4, int(height * 0.08))
            pixels: list[tuple[int, int, int]] = []
            for box in (
                (0, 0, sample_width, sample_height),
                (width - sample_width, 0, width, sample_height),
                (0, height - sample_height, sample_width, height),
                (width - sample_width, height - sample_height, width, height),
            ):
                pixels.extend(list(rgb.crop(box).getdata()))
            channels = [sorted(pixel[index] for pixel in pixels) for index in range(3)]
            middle = len(pixels) // 2
            red, green, blue = (channel[middle] for channel in channels)
            return f"#{red:02x}{green:02x}{blue:02x}"


GEMINI_IMAGE_OUTPUT_USD = {
    "0.5K": 0.045,
    "1K": 0.067,
    "2K": 0.101,
    "4K": 0.151,
}
GEMINI_INPUT_USD_PER_MILLION_TOKENS = 0.50
GEMINI_THOUGHT_USD_PER_MILLION_TOKENS = 3.00


class NanoBananaProvider(SyncProvider):
    """Adaptateur Genblaze pour la génération native d'images Gemini."""

    name = "google-nano-banana"

    def __init__(self, api_key: str):
        super().__init__()
        self.client = genai.Client(api_key=api_key)

    @staticmethod
    def _asset_bytes(asset: Asset) -> bytes:
        parsed = urlparse(asset.url)
        if parsed.scheme == "file":
            path = Path(unquote(parsed.path))
            if os.name == "nt" and path.as_posix().startswith("/"):
                path = Path(path.as_posix().lstrip("/"))
            return path.read_bytes()
        response = requests.get(asset.url, timeout=45)
        response.raise_for_status()
        return response.content

    def generate(self, step: Step, config: RunnableConfig | None = None) -> Step:
        interaction_input: list[dict[str, str]] = [
            {"type": "text", "text": step.prompt or ""}
        ]
        for asset in step.inputs:
            interaction_input.append(
                {
                    "type": "image",
                    "data": base64.b64encode(self._asset_bytes(asset)).decode("ascii"),
                    "mime_type": asset.media_type or "image/png",
                }
            )

        interaction = self.client.interactions.create(
            model=step.model,
            input=interaction_input,
            response_format={
                "type": "image",
                "mime_type": "image/jpeg",
                "aspect_ratio": str(step.params.get("aspect_ratio", "2:3")),
                "image_size": str(step.params.get("image_size", "1K")),
            },
        )
        output_image = interaction.output_image
        if not output_image or not output_image.data:
            raise RuntimeError("Nano Banana n'a retourné aucune image.")

        raw = base64.b64decode(output_image.data)
        fd, temp_name = tempfile.mkstemp(prefix="smartmirror-nano-banana-", suffix=".jpg")
        os.close(fd)
        output_path = Path(temp_name)
        output_path.write_bytes(raw)
        step.assets.append(
            Asset(
                url=output_path.resolve().as_uri(),
                media_type="image/jpeg",
                sha256=hashlib.sha256(raw).hexdigest(),
                size_bytes=len(raw),
            )
        )
        usage = getattr(interaction, "usage", None)
        usage_payload = usage.model_dump(exclude_none=True) if usage else {}
        image_size = str(step.params.get("image_size", "1K")).upper()
        input_tokens = int(usage_payload.get("total_input_tokens", 0) or 0)
        thought_tokens = int(usage_payload.get("total_thought_tokens", 0) or 0)
        image_output_cost = GEMINI_IMAGE_OUTPUT_USD.get(image_size, GEMINI_IMAGE_OUTPUT_USD["1K"])
        input_cost = input_tokens * GEMINI_INPUT_USD_PER_MILLION_TOKENS / 1_000_000
        thought_cost = thought_tokens * GEMINI_THOUGHT_USD_PER_MILLION_TOKENS / 1_000_000
        estimated_cost = round(image_output_cost + input_cost + thought_cost, 6)
        step.cost_usd = estimated_cost
        step.provider_payload = {
            "provider": "Google Gemini API",
            "model": step.model,
            "interaction_id": getattr(interaction, "id", None),
            "image_size": image_size,
            "usage": usage_payload,
            "estimated_cost_usd": estimated_cost,
            "pricing": {
                "image_output_usd": image_output_cost,
                "input_usd_per_million_tokens": GEMINI_INPUT_USD_PER_MILLION_TOKENS,
                "thought_usd_per_million_tokens": GEMINI_THOUGHT_USD_PER_MILLION_TOKENS,
            },
        }
        return step


ALLOWED_ORIGINS = {
    "https://smartmirror-ci.web.app",
    "https://smartmirror-ci.firebaseapp.com",
    "http://localhost:3000",
}

_active_request_ids: set[str] = set()
_active_request_ids_lock = threading.Lock()
def cors_headers(request: https_fn.Request) -> dict[str, str]:
    origin = request.headers.get("origin", "")
    return {
        "Access-Control-Allow-Origin": origin if origin in ALLOWED_ORIGINS else "https://smartmirror-ci.web.app",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Vary": "Origin",
    }


def _kling_headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {os.environ['KLING_API_KEY'].strip()}",
        "Content-Type": "application/json",
    }


@https_fn.on_request(region="us-central1", timeout_sec=60, memory=options.MemoryOption.MB_256)
def download_image(request: https_fn.Request) -> https_fn.Response:
    if request.method != "GET":
        return https_fn.Response("Méthode non autorisée.", status=405)
    image_url = str(request.args.get("url", ""))
    file_name = str(request.args.get("name", "smart-mirror.jpg"))
    parsed = urlparse(image_url)
    allowed_host = parsed.hostname and (
        parsed.hostname == "smartmirror-ci.web.app"
        or parsed.hostname.endswith(".backblazeb2.com")
    )
    if parsed.scheme != "https" or not allowed_host:
        return https_fn.Response("Adresse d’image non autorisée.", status=400)
    safe_name = "".join(character for character in file_name if character.isalnum() or character in ".-_")
    if not safe_name:
        safe_name = "smart-mirror.jpg"
    try:
        response = requests.get(image_url, timeout=45)
        response.raise_for_status()
    except requests.RequestException:
        return https_fn.Response("Image indisponible.", status=502)
    content_type = response.headers.get("Content-Type", "image/jpeg").split(";")[0]
    image_bytes = response.content
    if request.args.get("mirror") == "1" or request.args.get("trim") == "1" or request.args.get("compose") == "1":
        try:
            prepared = Image.open(BytesIO(image_bytes)).convert("RGB")
            if request.args.get("trim") == "1":
                width, height = prepared.size
                trim_x = max(8, round(width * 0.018))
                trim_y = max(4, round(height * 0.004))
                prepared = prepared.crop(
                    (trim_x, trim_y, width - trim_x, height - trim_y)
                ).resize((width, height), Image.Resampling.LANCZOS)
            if request.args.get("mirror") == "1":
                prepared = prepared.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            if request.args.get("compose") == "1":
                def safe_hex(value: str, fallback: str) -> tuple[int, int, int]:
                    candidate = value.strip().lstrip("#")
                    if len(candidate) != 6 or any(character not in "0123456789abcdefABCDEF" for character in candidate):
                        candidate = fallback.lstrip("#")
                    return tuple(int(candidate[index:index + 2], 16) for index in (0, 2, 4))

                top_color = safe_hex(str(request.args.get("bgTop", "#e8e5dc")), "#e8e5dc")
                bottom_color = safe_hex(str(request.args.get("bgBottom", "#e8e5dc")), "#e8e5dc")
                canvas_width = 1440
                canvas_height = 1520
                canvas = Image.new("RGB", (canvas_width, canvas_height), top_color)
                pixels = canvas.load()
                for y in range(canvas_height):
                    ratio = y / max(1, canvas_height - 1)
                    row_color = tuple(round(top_color[channel] * (1 - ratio) + bottom_color[channel] * ratio) for channel in range(3))
                    for x in range(canvas_width):
                        pixels[x, y] = row_color
                requested_scale = max(70, min(150, int(request.args.get("scale", "100")))) / 100
                fit_ratio = min(canvas_width / prepared.width, canvas_height / prepared.height) * requested_scale
                rendered_size = (
                    max(1, round(prepared.width * fit_ratio)),
                    max(1, round(prepared.height * fit_ratio)),
                )
                rendered = prepared.resize(rendered_size, Image.Resampling.LANCZOS)
                canvas.paste(rendered, ((canvas_width - rendered.width) // 2, (canvas_height - rendered.height) // 2))
                prepared = canvas
            output = BytesIO()
            prepared.save(output, format="JPEG", quality=95, optimize=True)
            image_bytes = output.getvalue()
            content_type = "image/jpeg"
        except Exception:
            return https_fn.Response("Le profil miroir n’a pas pu être préparé.", status=500)
    return https_fn.Response(
        image_bytes,
        status=200,
        headers={
            "Content-Disposition": f'attachment; filename="{safe_name}"',
            "Cache-Control": "private, max-age=60",
            "X-Content-Type-Options": "nosniff",
        },
        content_type=content_type,
    )


@https_fn.on_request(
    region="us-central1",
    timeout_sec=60,
    memory=options.MemoryOption.MB_256,
    secrets=["B2_KEY_ID", "B2_APP_KEY", "B2_BUCKET_NAME", "B2_REGION"],
)
def upload_identity_photo(request: https_fn.Request) -> https_fn.Response:
    headers = cors_headers(request)
    if request.method == "OPTIONS":
        return https_fn.Response("", status=204, headers=headers)
    if request.method != "POST":
        return https_fn.Response(
            json.dumps({"error": "Méthode non autorisée."}),
            status=405,
            headers=headers,
            content_type="application/json",
        )

    try:
        payload = request.get_json(silent=True) or {}
        label = str(payload.get("label", ""))
        if label not in {"faceFront", "bodyFront", "bodyRight", "bodyBack"}:
            raise ValueError("Type de photo invalide.")
        data_url = payload.get("image")
        if not isinstance(data_url, str) or not data_url.startswith("data:image/"):
            raise ValueError("Image manquante ou invalide.")
        header, encoded = data_url.split(",", 1)
        media_type = header.split(";", 1)[0].replace("data:", "")
        if media_type not in {"image/jpeg", "image/png", "image/webp"}:
            raise ValueError("Format d’image non accepté.")
        raw = base64.b64decode(encoded, validate=True)
        if not raw or len(raw) > 8 * 1024 * 1024:
            raise ValueError("La photo doit peser moins de 8 Mo.")

        bucket_name = os.environ["B2_BUCKET_NAME"]
        backend = S3StorageBackend.for_backblaze(
            bucket_name,
            region=os.environ["B2_REGION"],
            key_id=os.environ["B2_KEY_ID"],
            app_key=os.environ["B2_APP_KEY"],
        )
        extension = "png" if media_type == "image/png" else "webp" if media_type == "image/webp" else "jpg"
        upload_id = uuid.uuid4().hex
        object_key = f"smartmirror/identity-uploads/{upload_id}/{label}.{extension}"
        backend.put(object_key, raw, content_type=media_type)
        return https_fn.Response(
            json.dumps(
                {
                    "url": backend.presigned_get_url(object_key, expires_in=604800),
                    "objectKey": object_key,
                    "sha256": hashlib.sha256(raw).hexdigest(),
                    "sizeBytes": len(raw),
                    "uploadedAt": datetime.now(timezone.utc).isoformat(),
                    "storage": "Backblaze B2",
                }
            ),
            status=200,
            headers=headers,
            content_type="application/json",
        )
    except Exception as exc:
        logging.exception("SMART MIRROR identity photo upload failed")
        return https_fn.Response(
            json.dumps({"error": "La photo n’a pas pu être envoyée.", "detail": str(exc)[:200]}),
            status=400,
            headers=headers,
            content_type="application/json",
        )


@https_fn.on_request(
    region="us-central1",
    timeout_sec=300,
    memory=options.MemoryOption.GB_1,
    secrets=["GEMINI_API_KEY", "B2_KEY_ID", "B2_APP_KEY", "B2_BUCKET_NAME", "B2_REGION", "YOUCAM_API_KEY"],
)
def generate_tryon(request: https_fn.Request) -> https_fn.Response:
    headers = cors_headers(request)
    if request.method == "OPTIONS":
        return https_fn.Response("", status=204, headers=headers)
    if request.method != "POST":
        return https_fn.Response({"error": "Méthode non autorisée."}, status=405, headers=headers)

    payload = request.get_json(silent=True) or {}
    notification_uid = _optional_authenticated_uid(request)
    mode = "avatar" if payload.get("mode") == "avatar" else "tryon"
    # Kept as a request switch so the previous opaque-background renderer can
    # be restored without reverting code if the 2K cutout experiment is not
    # visually convincing.
    # New cutout pipeline is the server-side default so installed PWAs still
    # benefit even before their cached frontend updates. The historical engine
    # remains available only through an explicit legacy-background request.
    # Avatars are intentionally kept on the exact opaque SMART MIRROR canvas.
    # This avoids cutout halos and guarantees a seamless match with the viewer.
    avatar_render_mode = "legacy-background"
    avatar_uses_cutout = mode == "avatar" and avatar_render_mode == "cutout-2k"
    request_id = str(payload.get("requestId", "")).lower()
    if mode == "tryon" and (
        len(request_id) != 64 or any(character not in "0123456789abcdef" for character in request_id)
    ):
        return https_fn.Response(
            json.dumps({"error": "Identifiant d’essayage manquant ou invalide."}),
            status=400,
            headers=headers,
            content_type="application/json",
        )
    if request_id:
        with _active_request_ids_lock:
            if request_id in _active_request_ids:
                return https_fn.Response(
                    json.dumps({"error": "Cet essayage est déjà en cours.", "requestId": request_id}),
                    status=409,
                    headers=headers,
                    content_type="application/json",
                )
            _active_request_ids.add(request_id)
    garment_type = str(payload.get("garmentType", "vêtement"))[:40]
    garment_size = str(payload.get("garmentSize", ""))[:20]
    garment_sizes = payload.get("garmentSizes") or {}
    top_size = str(garment_sizes.get("top", ""))[:20]
    pants_size = str(garment_sizes.get("pants", ""))[:20]
    shoe_size = str(garment_sizes.get("shoes", ""))[:20]
    gender = str(payload.get("gender", "personne"))[:20]
    height = str(payload.get("height", ""))[:10]
    body_view = str(payload.get("bodyView", "face"))[:20]
    requested_view = str(payload.get("requestedView", ""))[:20]

    def build_fit_analysis() -> str:
        selected = garment_size.strip().upper().replace("3XL+", "3XL")
        alpha_sizes = ["XS", "S", "M", "L", "XL", "XXL", "3XL"]
        usual_top = top_size.strip().upper().replace("3XL+", "3XL")
        notes = [
            f"User height: {height or 'unknown'} cm.",
            f"Selected product size: {garment_size or 'unknown'}.",
            "Sizing standards: interpret letter sizes using international US/EU apparel grading. "
            "Interpret numeric apparel and footwear sizes as European (EU) by default, while cross-checking "
            "their approximate United States (US) equivalent. Use metric centimeters as the rendering basis "
            "and inches only as a secondary verification (1 inch = 2.54 cm).",
        ]
        if selected == "AUTO":
            notes.append(
                "The user did not specify a product size. Automatically detect the garment category and use "
                f"the corresponding usual user size: top/dress/outfit={top_size or 'unknown'}, "
                f"trousers/bottom={pants_size or 'unknown'}, footwear={shoe_size or 'unknown'}. "
                "Render a normal true-to-size fit for that detected category. Do not use the top size for "
                "trousers or footwear."
            )
        if selected in alpha_sizes and usual_top in alpha_sizes:
            grade_delta = alpha_sizes.index(selected) - alpha_sizes.index(usual_top)
            circumference_delta_cm = grade_delta * 5
            notes.append(
                f"For a detected top, dress, jacket or letter-sized outfit, the selected product is "
                f"{grade_delta:+d} international size grade(s) versus the user's usual top size "
                f"({usual_top}); use an estimated garment-circumference difference of "
                f"{circumference_delta_cm:+d} cm ({circumference_delta_cm / 2.54:+.2f} inches). "
                "Cross-check against common European EN 13402 and American ASTM/retail grading, while giving "
                "priority to the visible body reference."
            )
        try:
            selected_numeric = float(selected.replace(",", "."))
        except ValueError:
            selected_numeric = None
        if selected_numeric is not None:
            try:
                pants_numeric = float(pants_size.replace(",", "."))
                pants_delta = selected_numeric - pants_numeric
                notes.append(
                    f"If the detected item is trousers or a numeric-size bottom, it differs by "
                    f"{pants_delta:+g} size points from the user's usual trouser size ({pants_size}); "
                    f"treat these as EU sizes and estimate approximately {pants_delta * 2:+g} cm "
                    f"({pants_delta * 2 / 2.54:+.2f} inches) of waist-circumference difference. "
                    "Use the corresponding US waist/ready-to-wear grading only as a consistency check because "
                    "US numeric labels vary by gender and brand."
                )
            except ValueError:
                pass
            try:
                shoe_numeric = float(shoe_size.replace(",", "."))
                shoe_delta = selected_numeric - shoe_numeric
                notes.append(
                    f"If the detected item is footwear, it differs by {shoe_delta:+g} EU shoe size(s) "
                    f"from the user's usual size ({shoe_size}), equivalent to approximately "
                    f"{shoe_delta * 6.67:+.1f} mm ({shoe_delta * 6.67 / 25.4:+.2f} inches) of shoe-length "
                    "difference. Cross-check using US footwear grading, where one full US size is approximately "
                    "8.47 mm (one third of an inch). Preserve the real foot anatomy; change the shoe volume, "
                    "toe allowance, opening and visible fit rather than changing the foot."
                )
            except ValueError:
                pass
        notes.append(
            "Use only the comparison matching the automatically detected garment category; ignore the other comparisons."
        )
        return " ".join(notes)

    fit_analysis = build_fit_analysis()

    try:
        bucket_name = os.environ["B2_BUCKET_NAME"].strip()
        region = os.environ["B2_REGION"].strip()
        key_id = os.environ["B2_KEY_ID"].strip()
        app_key = os.environ["B2_APP_KEY"].strip()
        gemini_key = os.environ["GEMINI_API_KEY"].strip()
        youcam_key = os.environ["YOUCAM_API_KEY"].strip()
        input_backend = S3StorageBackend.for_backblaze(
            bucket_name, region=region, key_id=key_id, app_key=app_key
        )
        # Keep background removal available in the code, but exclude it from
        # the avatar pipeline by default while the opaque rendering is tested.
        avatar_background_removal_enabled = (
            os.environ.get("AVATAR_BACKGROUND_REMOVAL", "false").lower() == "true"
        )
        cache_suffix = f"-{requested_view}" if requested_view else ""
        cache_namespace = (
            "avatar-cutout-sheet-2k-v1"
            if avatar_uses_cutout
            else (
                "avatar-background-removed-frame-v7"
                if avatar_background_removal_enabled
                else "avatar-dynamic-viewer-gradient-v10"
            )
            if mode == "avatar"
            else "tryon-flat-beige-no-shadow-v4"
        )
        cache_key = (
            f"smartmirror/cache/{cache_namespace}/{request_id}{cache_suffix}.json"
            if request_id
            else ""
        )
        if cache_key and input_backend.exists(cache_key):
            cached_response = json.loads(input_backend.get(cache_key).decode("utf-8"))
            if time.time() - float(cached_response.get("cachedAt", 0)) < 6 * 24 * 60 * 60:
                cached_response["cacheHit"] = True
                return https_fn.Response(
                    json.dumps(cached_response),
                    status=200,
                    headers=headers,
                    content_type="application/json",
                )
        input_temp_files: list[Path] = []

        def upload_reference(data_url: str, label: str):
            if not isinstance(data_url, str):
                return None
            if data_url.startswith("data:image/"):
                header, encoded = data_url.split(",", 1)
                media_type = header.split(";", 1)[0].replace("data:", "")
                raw = base64.b64decode(encoded)
            else:
                reference_url = (
                    f"https://smartmirror-ci.web.app{data_url}"
                    if data_url.startswith("/")
                    else data_url
                )
                parsed_reference = urlparse(reference_url)
                allowed_reference_host = parsed_reference.hostname and (
                    parsed_reference.hostname == "smartmirror-ci.web.app"
                    or parsed_reference.hostname.endswith(".backblazeb2.com")
                )
                if parsed_reference.scheme != "https" or not allowed_reference_host:
                    return None
                reference_response = requests.get(reference_url, timeout=45)
                reference_response.raise_for_status()
                raw = reference_response.content
                media_type = reference_response.headers.get("Content-Type", "image/png").split(";", 1)[0]
                if not media_type.startswith("image/"):
                    return None
            extension = "png" if "png" in media_type else "webp" if "webp" in media_type else "jpg"
            key = f"smartmirror/inputs/{uuid.uuid4().hex}/{label}.{extension}"
            input_backend.put(key, raw, content_type=media_type)
            # OpenAI's image-edit endpoint infers MIME type from the uploaded
            # filename. Genblaze downloads remote inputs to a generic `.img`
            # file, which OpenAI rejects as application/octet-stream. Keep the
            # durable B2 copy above, but pass a correctly suffixed local file to
            # Genblaze for this request.
            fd, temp_name = tempfile.mkstemp(prefix=f"smartmirror-{label}-", suffix=f".{extension}")
            os.close(fd)
            temp_path = Path(temp_name)
            temp_path.write_bytes(raw)
            input_temp_files.append(temp_path)
            return (
                Asset(
                    url=temp_path.resolve().as_uri(),
                    media_type=media_type,
                    sha256=hashlib.sha256(raw).hexdigest(),
                    size_bytes=len(raw),
                ),
                input_backend.presigned_get_url(key, expires_in=3600),
            )

        face_assets = []
        body_assets = []
        face_front_url = None
        identity_images = payload.get("identityImages") or {}
        # Three-photo MVP: one frontal portrait, one frontal full-body reference
        # and one side full-body reference. The opposite side is mirrored in UI.
        face_labels = ("faceFront",)
        body_labels = ("bodyFront", "bodyRight", "bodyBack")
        for label in face_labels:
            data_url = identity_images.get(label)
            uploaded = upload_reference(data_url, str(label))
            if uploaded:
                asset, b2_url = uploaded
                face_assets.append(asset)
                if label == "faceFront":
                    face_front_url = b2_url
        for label in body_labels:
            data_url = identity_images.get(label)
            uploaded = upload_reference(data_url, str(label))
            if uploaded:
                asset, _ = uploaded
                body_assets.append(asset)
        garment_assets = []
        if mode == "tryon":
            for label in ("garmentFront", "garmentBack"):
                uploaded = upload_reference(payload.get(label), label)
                if uploaded:
                    asset, _ = uploaded
                    garment_assets.append(asset)
            if not garment_assets:
                return https_fn.Response(
                    json.dumps({"error": "La photo du vêtement n’a pas atteint le pipeline. Aucun essayage n’a été lancé."}),
                    status=400,
                    headers=headers,
                    content_type="application/json",
                )
        reference_assets = face_assets + body_assets + garment_assets
        continuity_image_url = str(payload.get("continuityImageUrl", ""))
        if continuity_image_url.startswith("https://"):
            continuity_response = requests.get(continuity_image_url, timeout=45)
            continuity_response.raise_for_status()
            continuity_raw = continuity_response.content
            continuity_media_type = continuity_response.headers.get("Content-Type", "image/jpeg").split(";", 1)[0]
            continuity_extension = (
                "png" if "png" in continuity_media_type
                else "webp" if "webp" in continuity_media_type
                else "jpg"
            )
            fd, continuity_name = tempfile.mkstemp(
                prefix="smartmirror-continuity-", suffix=f".{continuity_extension}"
            )
            os.close(fd)
            continuity_path = Path(continuity_name)
            continuity_path.write_bytes(continuity_raw)
            input_temp_files.append(continuity_path)
            reference_assets.append(
                Asset(
                    url=continuity_path.resolve().as_uri(),
                    media_type=continuity_media_type,
                    sha256=hashlib.sha256(continuity_raw).hexdigest(),
                    size_bytes=len(continuity_raw),
                )
            )

        def analyze_face_with_youcam(image_url: str | None) -> dict:
            if not image_url:
                return {"status": "skipped", "reason": "no-face-photo"}
            api_root = "https://yce-api-01.makeupar.com/s2s/v2.0/task/skin-tone-analysis"
            auth_headers = {
                "Authorization": f"Bearer {youcam_key}",
                "Content-Type": "application/json",
            }
            start = requests.post(
                api_root,
                headers=auth_headers,
                json={"src_file_url": image_url},
                timeout=20,
            )
            if not start.ok:
                raise RuntimeError(
                    f"YouCam skin-tone analysis HTTP {start.status_code}: {start.text[:240]}"
                )
            task_id = (start.json().get("data") or {}).get("task_id")
            if not task_id:
                raise RuntimeError("YouCam n'a pas retourné de task_id.")
            for _ in range(12):
                status_response = requests.get(f"{api_root}/{task_id}", headers=auth_headers, timeout=15)
                status_response.raise_for_status()
                task_data = status_response.json().get("data") or {}
                task_status = task_data.get("task_status")
                if task_status == "success":
                    return {
                        "status": "success",
                        "provider": "Perfect Corp YouCam",
                        "model": "AI Skin Tone Analysis v2.0",
                        "results": task_data.get("results") or {},
                    }
                if task_status == "error":
                    return {
                        "status": "error",
                        "provider": "Perfect Corp YouCam",
                        "error": task_data.get("error") or "analysis-failed",
                    }
                time.sleep(1)
            return {"status": "timeout", "provider": "Perfect Corp YouCam"}

        try:
            youcam_analysis = analyze_face_with_youcam(face_front_url)
        except Exception as youcam_exc:
            logging.exception("YouCam face analysis failed")
            youcam_analysis = {
                "status": "error",
                "provider": "Perfect Corp YouCam",
                "error": str(youcam_exc)[:180],
            }
        if payload.get("analysisOnly") is True:
            return https_fn.Response(
                json.dumps({"youcam": youcam_analysis, "storage": "Backblaze B2"}),
                status=200,
                headers=headers,
                content_type="application/json",
            )
        # Safe test mode: generate and persist one front view first. The remaining
        # angles will be enabled only after this end-to-end path is verified.
        all_views = [
            ("bodyFront", "front view, facing the camera"),
            ("bodyRight", "right-side profile view, exactly 90 degrees from the camera"),
            (
                "bodyBack",
                "rear-facing full-body view, facing directly away from the camera, fully clothed in the exact same athletic outfit, no nudity",
            ),
        ]
        views = (
            [view for view in all_views if view[0] == requested_view]
            if requested_view
            else all_views
        )
        if not views:
            return https_fn.Response(
                json.dumps({"error": "Vue demandée invalide."}),
                status=400,
                headers=headers,
                content_type="application/json",
            )
        clothing_prompt = (
            ("Dress the man in a plain, fitted, non-transparent short-sleeve athletic top and knee-length compression shorts."
             if gender == "homme" else
             "Dress the woman in a plain, fitted, non-transparent short-sleeve athletic top and knee-length compression shorts.")
            if mode == "avatar"
            else (
                "First analyze every supplied garment reference image and identify all visible fashion items. "
                "The input may contain a top, shirt, dress, skirt, trousers, shoes, accessories, "
                "or a coordinated multi-piece outfit. Dress the person in every coherent item detected; "
                "do not require a user-provided garment category. Preserve the exact design, colors, materials, "
                f"patterns and layering. The selected size of the garment being tried is {garment_size or 'unknown'}. "
                f"The user's usual sizes are: top {top_size or 'unknown'}, trousers {pants_size or 'unknown'}, "
                f"and shoes {shoe_size or 'unknown'}. FIT CALCULATION: {fit_analysis} "
                "First classify every detected item, then compare its selected "
                "size with the corresponding usual user size. This comparison MUST be visibly reflected in the fit "
                "while preserving the user's body unchanged. Equal size: natural regular fit. One size smaller: "
                "visibly snug with realistic tension, reduced ease and tighter sleeves, waist or thighs as relevant. "
                "Two or more sizes smaller: the person's body cannot realistically fit inside the garment normally. "
                "Show strong fabric tension, overstretched closures, strained stitching and a small realistic seam "
                "failure or localized tear caused by the size mismatch. Keep the result modest and non-explicit: "
                "preserve an opaque underlayer and never expose intimate anatomy. One size "
                "larger: visibly loose with extra ease and longer or wider drape. Two or more sizes larger: clearly "
                "oversized and evidently ill-fitting: dropped shoulders, excess width, loose waist, longer sleeves "
                "or hems, sagging/drooping fabric and large realistic folds. Do not tailor or tuck the oversized "
                "garment to make it look fitted. For letter sizes use XS < S < M < L < XL < XXL "
                "< 3XL. For numeric trousers and shoes compare the numeric difference. Never resize, slim or enlarge "
                "the person's body to make the garment appear to fit."
            )
        )
        youcam_context = ""
        if youcam_analysis.get("status") == "success":
            safe_results = json.dumps(youcam_analysis.get("results") or {}, ensure_ascii=True)[:1800]
            youcam_context = (
                "Perfect Corp YouCam analyzed the frontal face reference. "
                f"Preserve the measured facial skin-tone context without whitening or beautifying: {safe_results}. "
            )
        def choose_chroma_background():
            scores = {"green": 0, "blue": 0, "magenta": 0}
            for asset in garment_assets:
                parsed = urlparse(asset.url)
                path = Path(unquote(parsed.path))
                if os.name == "nt" and path.as_posix().startswith("/"):
                    path = Path(path.as_posix().lstrip("/"))
                try:
                    sample = Image.open(path).convert("RGB")
                    sample.thumbnail((160, 160))
                    for red, green, blue in sample.getdata():
                        if green > 80 and green > red * 1.25 and green > blue * 1.25:
                            scores["green"] += 1
                        if blue > 80 and blue > red * 1.25 and blue > green * 1.25:
                            scores["blue"] += 1
                        if red > 80 and blue > 80 and red > green * 1.25 and blue > green * 1.25:
                            scores["magenta"] += 1
                except Exception:
                    logging.exception("Garment chroma analysis failed")
            selected = min(scores, key=scores.get)
            return {
                "green": ("cinema chroma-key green", "#00FF00"),
                "blue": ("cinema chroma-key blue", "#0066FF"),
                "magenta": ("chroma-key magenta", "#FF00FF"),
            }[selected]

        chroma_name, chroma_hex = choose_chroma_background()
        if mode == "avatar":
            if avatar_uses_cutout:
                chroma_name = "neutral segmentation studio gray"
                chroma_hex = "#667085"
                studio_background = (
                    "TEMPORARY SEGMENTATION BACKGROUND: use exactly one perfectly flat, uniform, medium cool "
                    "studio gray #667085 across all three panels and every canvas edge. This is deliberately a "
                    "neutral photographic background, NOT green screen, blue screen or any saturated chroma key. "
                    "No gradient, texture, wall, floor line, vignette, glow, reflection, colored rim light or "
                    "background color spill. Use soft near-shadowless frontal lighting and at most a tiny neutral "
                    "contact shadow immediately beneath the feet. Keep the person fully separated from the "
                    "background, with clean natural hair strands, complete fingers, complete feet and crisp "
                    "clothing edges. Never copy a background from a reference image. The lightweight SMART "
                    "MIRROR cutout stage will remove this gray studio background after generation. "
                )
            else:
                chroma_name = "SMART MIRROR legacy warm-neutral"
                chroma_hex = "#E8E5DC"
                studio_background = (
                    "STRICT BACKGROUND CONSISTENCY REQUIREMENT: use one single perfectly flat, opaque, uniformly "
                    "lit warm-neutral RGB background #E8E5DC. The three views belong to one photographic set: "
                    "the background RGB values, exposure, white balance, colour temperature and brightness MUST "
                    "be visually identical in every panel and at every canvas edge. Do not relight, warm, cool, "
                    "darken or brighten the background for a side or rear view. No gradient, shadow, floor line, "
                    "vignette, border, spotlight, colour cast or coloured reflection. Only a tiny neutral contact "
                    "shadow may exist directly beneath the feet. This opaque background is part of the final avatar "
                    "image and must be retained exactly as generated. "
                )
        else:
            studio_background = (
                "ABSOLUTE TRY-ON BACKGROUND LOCK — FAILURE OF ANY RULE INVALIDATES THE OUTPUT: use one single "
                "perfectly flat, opaque and uniformly colored SMART MIRROR warm-neutral beige background #EAE7DF "
                "across the complete canvas and every panel. Every empty-background pixel must have the same RGB "
                "appearance from top to bottom and from left to right. There must be NO gradient, NO vignette, "
                "NO spotlight, NO bright center, NO darkened corners, NO floor line, NO horizon, NO wall texture, "
                "NO glow, NO reflection, NO cast shadow, NO contact shadow beneath the feet, and NO shadow of the "
                "person or garment on the background. Lighting and realistic folds may affect the person and the "
                "garment only; they must never alter the background. Never independently relight a panel. "
                "CONDITIONAL BEIGE CONTRAST: first inspect the selected garment. Only when its dominant beige is "
                "so close to #EAE7DF that its outer edges would visually disappear, replace the background for "
                "the entire sheet with one clearly distinguishable but still warm-neutral beige variant, choosing "
                "either #D8C9B8 (darker) or #F4EEE5 (lighter), whichever gives the strongest clean edge contrast. "
                "Use exactly that one chosen hexadecimal color uniformly in every view; never use a gradient or "
                "different beige per panel. Do not change the garment color to create contrast. This opaque "
                "background is part of the final try-on image and must not be green, blue, magenta or transparent. "
            )
        reference_role_prompt = (
            "The last supplied image is a headless outfit-only continuity reference. Use it only to copy the "
            "athletic unitard exactly: identical neckline, sleeve length, shorts length, fabric, seams and color. "
            "Never use that last reference for the face, head, skin tone, hair, identity or body proportions. "
            "AVATAR OUTFIT LOCK: all panels must show one and the same matte warm-beige short-sleeve, mid-thigh "
            "fitted unitard copied from that outfit-only reference. Its exact color, neckline, sleeve length, leg "
            "length, seams, opacity and fabric must be identical in front, profile and rear panels. Never create "
            "separate underwear pieces and never substitute another outfit. "
            if mode == "avatar"
            else
            "MANDATORY VIRTUAL TRY-ON: the final one or two supplied images are the selected garment photographs, "
            "not identity references. Remove the avatar's beige unitard wherever the selected garment covers it, "
            "then visibly dress the person in every coherent selected fashion item. The output is invalid if it "
            "still shows only the original beige avatar outfit. Preserve the garment's exact silhouette, colors, "
            "pattern, neckline, sleeves, hem, material and layering. Do not reinterpret the garment as beige and "
            "do not omit it. Keep the person's identity and body unchanged while replacing only the clothing. "
        )
        base_prompt = (
            "Photorealistic full-body SMART MIRROR identity avatar. "
            f"Create the same {gender} person in every image, approximately {height} cm tall. "
            f"{clothing_prompt} "
            "REFERENCE PRIORITY: the first supplied image is the authoritative frontal identity portrait. "
            "The next images are full-body references seen from the front, the side and optionally the back. "
            "Copy the facial geometry faithfully from the portrait: same eyes and "
            "their spacing, eyebrows, nose, lips, jawline, cheeks, ears, hairline, hairstyle, apparent age "
            "and natural skin texture. Do not invent a new face, beautify, whiten, slim, age, de-age, add "
            "makeup, or alter the person's expression or ethnicity. Use the full-body identity photographs "
            "only for body shape and proportions, and garment photographs only for clothing. "
            f"{youcam_context}"
            "Preserve the exact same identity, body proportions, clothing, colors and studio in every view. "
            f"{reference_role_prompt}"
            "Show realistic anatomy, textile folds and garment fit for the stated size. "
            "Neutral premium studio lighting. "
            f"{studio_background}"
            "Frame the person at the same scale as the reference avatar, centered and filling the canvas "
            "vertically from near the top edge to near the bottom edge without cutting off head or feet. "
            "No text, no logo, no extra limbs, no duplicated garments. Camera view: "
        )
        billing_events: list[dict] = []

        def run_image_pipeline(
            pipeline_name: str,
            prompt: str,
            inputs: list[Asset],
            aspect_ratio: str = "2:3",
            image_size: str = "1K",
        ):
            backend = S3StorageBackend.for_backblaze(
                bucket_name, region=region, key_id=key_id, app_key=app_key
            )
            storage = ObjectStorageSink(backend, key_strategy=KeyStrategy.HIERARCHICAL)
            billing_event = {
                "pipeline": pipeline_name,
                "provider": "Google Gemini API",
                "model": "gemini-3.1-flash-image",
                "imageSize": image_size.upper(),
                "aspectRatio": aspect_ratio,
                "startedAt": datetime.now(timezone.utc).isoformat(),
                "status": "started",
            }
            billing_events.append(billing_event)
            result = (
                Pipeline(pipeline_name)
                .step(
                    NanoBananaProvider(api_key=gemini_key),
                    model="gemini-3.1-flash-image",
                    prompt=prompt,
                    modality=Modality.IMAGE,
                    aspect_ratio=aspect_ratio,
                    image_size=image_size,
                    external_inputs=inputs or None,
                )
                .run(sink=storage, timeout=240, pipeline_timeout=240, raise_on_failure=True)
            )
            completed_step = result.run.steps[0]
            provider_payload = completed_step.provider_payload or {}
            billing_event.update(
                {
                    "status": "completed",
                    "completedAt": datetime.now(timezone.utc).isoformat(),
                    "interactionId": provider_payload.get("interaction_id"),
                    "usage": provider_payload.get("usage", {}),
                    "estimatedCostUsd": provider_payload.get(
                        "estimated_cost_usd", completed_step.cost_usd or 0
                    ),
                    "pricing": provider_payload.get("pricing", {}),
                }
            )
            asset_url = result.run.steps[0].assets[0].url
            object_path = unquote(urlparse(asset_url).path).lstrip("/")
            prefix = f"{bucket_name}/"
            object_key = object_path[len(prefix):] if object_path.startswith(prefix) else object_path
            return backend.presigned_get_url(object_key, expires_in=604800), result.manifest.canonical_hash, result.manifest.verify()

        def find_result_url(value):
            if isinstance(value, dict):
                direct = value.get("url")
                if isinstance(direct, str) and direct.startswith("http"):
                    return direct
                for nested in value.values():
                    found = find_result_url(nested)
                    if found:
                        return found
            if isinstance(value, list):
                for nested in value:
                    found = find_result_url(nested)
                    if found:
                        return found
            return None

        def restore_identity_with_youcam(render_url: str):
            if not face_front_url:
                return None
            api_root = "https://yce-api-01.makeupar.com/s2s/v2.0/task/face-swap"
            auth_headers = {
                "Authorization": f"Bearer {youcam_key}",
                "Content-Type": "application/json",
            }
            start = requests.post(
                api_root,
                headers=auth_headers,
                json={
                    "src_file_url": render_url,
                    "ref_file_urls": [face_front_url],
                    "face_mapping": [{"index": 0, "position": 0}],
                },
                timeout=25,
            )
            start.raise_for_status()
            task_id = (start.json().get("data") or {}).get("task_id")
            if not task_id:
                raise RuntimeError("YouCam Face Swap n'a pas retourné de task_id.")
            for _ in range(40):
                status_response = requests.get(
                    f"{api_root}/{task_id}",
                    headers={"Authorization": f"Bearer {youcam_key}"},
                    timeout=20,
                )
                status_response.raise_for_status()
                task_data = status_response.json().get("data") or {}
                task_status = task_data.get("task_status")
                if task_status == "success":
                    result_url = find_result_url(task_data.get("results") or {})
                    if not result_url:
                        raise RuntimeError("YouCam Face Swap n'a pas retourné d'image.")
                    final_response = requests.get(result_url, timeout=30)
                    final_response.raise_for_status()
                    final_raw = final_response.content
                    final_key = f"smartmirror/outputs/identity/{uuid.uuid4().hex}.png"
                    input_backend.put(final_key, final_raw, content_type="image/png")
                    return (
                        input_backend.presigned_get_url(final_key, expires_in=604800),
                        hashlib.sha256(final_raw).hexdigest(),
                    )
                if task_status == "error":
                    raise RuntimeError(
                        f"YouCam Face Swap: {task_data.get('error_message') or task_data.get('error') or 'échec'}"
                    )
                time.sleep(1.5)
            raise RuntimeError("YouCam Face Swap a dépassé le délai d'attente.")

        def normalize_avatar_cutout(render_url: str, view_key: str):
            """Remove the connected studio background and standardize avatar framing."""
            response = requests.get(render_url, timeout=45)
            response.raise_for_status()
            source = Image.open(BytesIO(response.content)).convert("RGB")
            width, height = source.size
            sample_size = max(6, round(min(source.size) * 0.025))
            corner_samples = []
            for left, top in (
                (0, 0),
                (width - sample_size, 0),
                (0, height - sample_size),
                (width - sample_size, height - sample_size),
            ):
                corner_samples.extend(
                    source.crop((left, top, left + sample_size, top + sample_size)).getdata()
                )
            background_rgb = tuple(
                sorted(pixel[channel] for pixel in corner_samples)[len(corner_samples) // 2]
                for channel in range(3)
            )
            background_max = max(background_rgb)
            background_min = min(background_rgb)
            background_saturation = (
                (background_max - background_min) / background_max if background_max else 0
            )
            marker = (255, 0, 255)
            flooded = source.copy()
            seeds = (
                (0, 0), (width - 1, 0), (0, height - 1), (width - 1, height - 1),
                (width // 2, 0), (width // 2, height - 1),
                (0, height // 2), (width - 1, height // 2),
            )
            for seed in seeds:
                # A conservative edge flood protects skin and beige fabric even
                # when Gemini adds a small amount of chroma spill.
                ImageDraw.floodfill(flooded, seed, marker, thresh=34)

            rgba = source.convert("RGBA")
            flood_pixels = flooded.load()
            rgba_pixels = rgba.load()
            for y in range(height):
                for x in range(width):
                    red, green, blue, _ = rgba_pixels[x, y]
                    color_distance = (
                        (red - background_rgb[0]) ** 2
                        + (green - background_rgb[1]) ** 2
                        + (blue - background_rgb[2]) ** 2
                    ) ** 0.5
                    pixel_max = max(red, green, blue)
                    pixel_min = min(red, green, blue)
                    pixel_saturation = (pixel_max - pixel_min) / pixel_max if pixel_max else 0
                    background_total = max(1, sum(background_rgb))
                    pixel_total = max(1, red + green + blue)
                    chroma_distance = sum(
                        (
                            pixel / pixel_total
                            - background_rgb[channel] / background_total
                        ) ** 2
                        for channel, pixel in enumerate((red, green, blue))
                    ) ** 0.5
                    # Edge-connected background is always removed. When Gemini
                    # delivered the requested saturated chroma matte, matching
                    # islands enclosed by arms or legs are removed globally as
                    # well. The saturation guard prevents beige clothes and skin
                    # from being mistaken for an unsuitable neutral background.
                    enclosed_chroma = (
                        background_saturation >= 0.52
                        and pixel_saturation >= max(0.40, background_saturation - 0.22)
                        and (color_distance <= 46 or chroma_distance <= 0.20)
                    )
                    if flood_pixels[x, y] == marker or enclosed_chroma:
                        rgba_pixels[x, y] = (red, green, blue, 0)
            # Refine only the outermost pixel instead of eroding several pixels
            # from the underwear, lips, fingers or hair.
            clean_alpha = rgba.getchannel("A").filter(ImageFilter.MinFilter(3))
            clean_alpha = clean_alpha.filter(ImageFilter.GaussianBlur(0.40))
            rgba.putalpha(clean_alpha)
            bbox = clean_alpha.getbbox()
            if not bbox:
                raise RuntimeError("Le détourage de l'avatar n'a trouvé aucune silhouette.")
            subject = rgba.crop(bbox)
            # Match the exact canvas and silhouette height used by the curated
            # default avatars displayed by the frontend.
            if gender == "homme":
                canvas_width, canvas_height = 884, 1778
                target_height = 1600
                target_top = 88
            else:
                canvas_width, canvas_height = 843, 1696
                target_height = 1565
                target_top = 65
            scale = min(
                target_height / subject.height,
                (canvas_width * 0.90) / subject.width,
            )
            target_size = (
                max(1, round(subject.width * scale)),
                max(1, round(subject.height * scale)),
            )
            subject = subject.resize(target_size, Image.Resampling.LANCZOS)
            canvas = Image.new("RGBA", (canvas_width, canvas_height), (0, 0, 0, 0))
            canvas.alpha_composite(
                subject,
                ((canvas_width - target_size[0]) // 2, target_top),
            )
            output = BytesIO()
            canvas.save(output, format="PNG", optimize=True)
            normalized_raw = output.getvalue()
            normalized_key = f"smartmirror/outputs/avatar-normalized/{uuid.uuid4().hex}-{view_key}.png"
            input_backend.put(normalized_key, normalized_raw, content_type="image/png")
            return (
                input_backend.presigned_get_url(normalized_key, expires_in=604800),
                hashlib.sha256(normalized_raw).hexdigest(),
            )

        avatar_background_colors = {}
        avatar_background_gradients = {}

        def normalize_avatar_frame(render_url: str, view_key: str):
            """Keep the complete render on the canonical opaque SMART MIRROR canvas."""
            response = requests.get(render_url, timeout=45)
            response.raise_for_status()
            source = Image.open(BytesIO(response.content)).convert("RGB")
            if gender == "homme":
                canvas_width, canvas_height = 884, 1778
                target_height, target_top = 1600, 88
            else:
                canvas_width, canvas_height = 843, 1696
                target_height, target_top = 1565, 65
            # Infer the actual generated background from all four corners. Gemini
            # does not always reproduce the requested hex value exactly.
            sample_size = max(8, round(min(source.size) * 0.04))
            corner_pixels = []
            for left, top in (
                (0, 0),
                (source.width - sample_size, 0),
                (0, source.height - sample_size),
                (source.width - sample_size, source.height - sample_size),
            ):
                corner_pixels.extend(
                    source.crop(
                        (left, top, left + sample_size, top + sample_size)
                    ).getdata()
                )
            corner_pixels.sort(key=lambda pixel: sum(pixel))
            middle = corner_pixels[len(corner_pixels) // 2]
            avatar_background_colors[view_key] = "#{:02X}{:02X}{:02X}".format(*middle)
            top_pixels = list(source.crop((0, 0, sample_size, sample_size)).getdata())
            top_pixels.extend(source.crop((source.width - sample_size, 0, source.width, sample_size)).getdata())
            bottom_pixels = list(source.crop((0, source.height - sample_size, sample_size, source.height)).getdata())
            bottom_pixels.extend(source.crop((source.width - sample_size, source.height - sample_size, source.width, source.height)).getdata())
            top_pixels.sort(key=lambda pixel: sum(pixel))
            bottom_pixels.sort(key=lambda pixel: sum(pixel))
            top_background = top_pixels[len(top_pixels) // 2]
            bottom_background = bottom_pixels[len(bottom_pixels) // 2]
            avatar_background_gradients[view_key] = {
                "top": "#{:02X}{:02X}{:02X}".format(*top_background),
                "bottom": "#{:02X}{:02X}{:02X}".format(*bottom_background),
            }
            generated_background = Image.new("RGB", source.size, middle)
            difference = ImageChops.difference(source, generated_background).convert("L")
            bbox = None
            # Raise tolerance progressively until neutral lighting variations no
            # longer count as the subject.
            for tolerance in (18, 28, 40, 55, 70):
                candidate_mask = difference.point(
                    lambda value, limit=tolerance: 255 if value > limit else 0
                )
                candidate = candidate_mask.getbbox()
                if not candidate:
                    continue
                candidate_width = candidate[2] - candidate[0]
                candidate_height = candidate[3] - candidate[1]
                if (
                    candidate_width < source.width * 0.92
                    and candidate_height < source.height * 0.985
                    and candidate_height > source.height * 0.40
                ):
                    bbox = candidate
                    break
            canonical_background = (232, 229, 220)
            if avatar_background_removal_enabled:
                # Preserved background-removal path. It can be restored later
                # with AVATAR_BACKGROUND_REMOVAL=true without rewriting it.
                synchronized_source = source.copy()
                perimeter_step = max(1, min(source.size) // 20)
                edge_seeds = set()
                for x in range(0, source.width, perimeter_step):
                    edge_seeds.add((x, 0))
                    edge_seeds.add((x, source.height - 1))
                for y in range(0, source.height, perimeter_step):
                    edge_seeds.add((0, y))
                    edge_seeds.add((source.width - 1, y))
                for seed in edge_seeds:
                    ImageDraw.floodfill(
                        synchronized_source,
                        seed,
                        canonical_background,
                        thresh=64,
                    )
            else:
                # Active test path: preserve Gemini's opaque render byte-for-byte
                # at pixel level. The frontend receives the sampled background
                # colour and adapts the viewer instead of altering the image.
                synchronized_source = source

            if bbox:
                padding_x = max(8, round(source.width * 0.025))
                padding_y = max(8, round(source.height * 0.015))
                bbox = (
                    max(0, bbox[0] - padding_x),
                    max(0, bbox[1] - padding_y),
                    min(source.width, bbox[2] + padding_x),
                    min(source.height, bbox[3] + padding_y),
                )
                subject_frame = synchronized_source.crop(bbox)
            else:
                subject_frame = synchronized_source
            logging.info(
                "Avatar frame %s: source=%sx%s background=%s bbox=%s target=%sx%s",
                view_key,
                source.width,
                source.height,
                middle,
                bbox,
                canvas_width,
                canvas_height,
            )
            scale = min(
                target_height / subject_frame.height,
                (canvas_width * 0.90) / subject_frame.width,
            )
            target_size = (
                max(1, round(subject_frame.width * scale)),
                max(1, round(subject_frame.height * scale)),
            )
            framed = subject_frame.resize(target_size, Image.Resampling.LANCZOS)
            if avatar_background_removal_enabled:
                canvas = Image.new("RGB", (canvas_width, canvas_height), canonical_background)
            else:
                canvas = Image.new("RGB", (canvas_width, canvas_height), top_background)
                canvas_pixels = canvas.load()
                for y in range(canvas_height):
                    ratio = y / max(1, canvas_height - 1)
                    row_color = tuple(
                        round(top_background[channel] * (1 - ratio) + bottom_background[channel] * ratio)
                        for channel in range(3)
                    )
                    for x in range(canvas_width):
                        canvas_pixels[x, y] = row_color
            canvas.paste(
                framed,
                (
                    (canvas_width - target_size[0]) // 2,
                    target_top,
                ),
            )
            output = BytesIO()
            canvas.save(output, format="PNG", optimize=True)
            normalized_raw = output.getvalue()
            normalized_key = f"smartmirror/outputs/avatar-framed/{uuid.uuid4().hex}-{view_key}.png"
            input_backend.put(normalized_key, normalized_raw, content_type="image/png")
            return (
                input_backend.presigned_get_url(normalized_key, expires_in=604800),
                hashlib.sha256(normalized_raw).hexdigest(),
            )

        def generate_view(view_key: str, view_prompt: str):
            first_url, first_hash, first_verified = run_image_pipeline(
                f"smartmirror-try-on-{view_key}",
                base_prompt + view_prompt,
                reference_assets,
            )
            if face_front_url:
                try:
                    restored = restore_identity_with_youcam(first_url)
                    if restored:
                        final_url, face_hash = restored
                        combined_hash = hashlib.sha256(f"{first_hash}:{face_hash}".encode()).hexdigest()
                        if mode == "avatar":
                            normalizer = normalize_avatar_cutout if avatar_uses_cutout else normalize_avatar_frame
                            final_url, normalized_hash = normalizer(final_url, view_key)
                            combined_hash = hashlib.sha256(
                                f"{combined_hash}:{normalized_hash}".encode()
                            ).hexdigest()
                        return view_key, final_url, combined_hash, first_verified, True
                except Exception:
                    logging.exception("YouCam Face Swap identity restoration failed")
            if mode == "avatar":
                normalizer = normalize_avatar_cutout if avatar_uses_cutout else normalize_avatar_frame
                first_url, normalized_hash = normalizer(first_url, view_key)
                first_hash = hashlib.sha256(f"{first_hash}:{normalized_hash}".encode()).hexdigest()
            return view_key, first_url, first_hash, first_verified, False

        generation_mode = str(payload.get("generationMode", "progressive"))
        images = {}
        manifest_hashes = {}
        verified = []
        identity_locked = []
        if generation_mode == "multiview-sheet":
            sheet_prompt = (
                base_prompt
                + "one single horizontal three-panel contact sheet. The canvas must contain exactly three "
                "equal-width vertical panels with no gutter, no border and no text. PANEL 1: full-body front "
                "view facing the camera. PANEL 2: full-body right-side profile at exactly 90 degrees. PANEL 3: "
                "full-body rear view facing directly away from the camera. Show the same person, same face, "
                "same body proportions, same garment, same garment fit and the exact same studio "
                "background already specified above in all three panels. BACKGROUND LOCK: render the background "
                "once as one continuous flat field spanning the entire contact sheet, then place all three views "
                "over that same field. Do not create or relight a separate background inside each panel. A pixel "
                "of empty background in panel 1 must have the same RGB appearance as empty background pixels in "
                "panels 2 and 3. No background shadow or gradient is permitted anywhere, including beneath the "
                "feet. Keep the head and feet fully visible inside every panel."
            )
            sheet_url, sheet_hash, sheet_verified = run_image_pipeline(
                "smartmirror-try-on-multiview-sheet",
                sheet_prompt,
                reference_assets,
                aspect_ratio="3:2",
                image_size="2K",
            )
            sheet_response = requests.get(sheet_url, timeout=45)
            sheet_response.raise_for_status()
            sheet_image = Image.open(BytesIO(sheet_response.content)).convert("RGB")
            sheet_width, sheet_height = sheet_image.size
            sheet_views = ("bodyFront", "bodyRight", "bodyBack")
            for sheet_index, view_key in enumerate(sheet_views):
                left = round(sheet_index * sheet_width / 3)
                right = round((sheet_index + 1) * sheet_width / 3)
                panel_width = right - left
                trim_x = max(8, round(panel_width * 0.018))
                trim_y = max(4, round(sheet_height * 0.004))
                crop = sheet_image.crop(
                    (left + trim_x, trim_y, right - trim_x, sheet_height - trim_y)
                ).resize((panel_width, sheet_height), Image.Resampling.LANCZOS)
                gradient_sample = max(8, round(min(crop.size) * 0.04))
                crop_top_pixels = list(crop.crop((0, 0, gradient_sample, gradient_sample)).getdata())
                crop_top_pixels.extend(crop.crop((crop.width - gradient_sample, 0, crop.width, gradient_sample)).getdata())
                crop_bottom_pixels = list(crop.crop((0, crop.height - gradient_sample, gradient_sample, crop.height)).getdata())
                crop_bottom_pixels.extend(crop.crop((crop.width - gradient_sample, crop.height - gradient_sample, crop.width, crop.height)).getdata())
                crop_top_pixels.sort(key=lambda pixel: sum(pixel))
                crop_bottom_pixels.sort(key=lambda pixel: sum(pixel))
                crop_top = crop_top_pixels[len(crop_top_pixels) // 2]
                crop_bottom = crop_bottom_pixels[len(crop_bottom_pixels) // 2]
                avatar_background_colors[view_key] = "#{:02X}{:02X}{:02X}".format(*crop_top)
                avatar_background_gradients[view_key] = {
                    "top": "#{:02X}{:02X}{:02X}".format(*crop_top),
                    "bottom": "#{:02X}{:02X}{:02X}".format(*crop_bottom),
                }
                crop_buffer = BytesIO()
                crop.save(crop_buffer, format="JPEG", quality=94, optimize=True)
                crop_raw = crop_buffer.getvalue()
                crop_key = f"smartmirror/outputs/multiview/{uuid.uuid4().hex}-{view_key}.jpg"
                input_backend.put(crop_key, crop_raw, content_type="image/jpeg")
                crop_url = input_backend.presigned_get_url(crop_key, expires_in=604800)
                crop_hash = hashlib.sha256(crop_raw).hexdigest()
                was_identity_locked = False
                if view_key == "bodyFront" and face_front_url:
                    try:
                        restored = restore_identity_with_youcam(crop_url)
                        if restored:
                            crop_url, face_hash = restored
                            crop_hash = hashlib.sha256(f"{crop_hash}:{face_hash}".encode()).hexdigest()
                            was_identity_locked = True
                    except Exception:
                        logging.exception("YouCam multiview front identity restoration failed")
                if mode == "avatar":
                    normalizer = normalize_avatar_cutout if avatar_uses_cutout else normalize_avatar_frame
                    crop_url, normalized_hash = normalizer(crop_url, view_key)
                    crop_hash = hashlib.sha256(
                        f"{crop_hash}:{normalized_hash}".encode()
                    ).hexdigest()
                images[view_key] = crop_url
                manifest_hashes[view_key] = hashlib.sha256(
                    f"{sheet_hash}:{view_key}:{crop_hash}".encode()
                ).hexdigest()
                verified.append(sheet_verified)
                identity_locked.append(was_identity_locked if view_key == "bodyFront" else True)
        else:
            for view_key, view_prompt in views:
                view_key, signed_url, manifest_hash, is_verified, was_identity_locked = generate_view(
                    view_key, view_prompt
                )
                images[view_key] = signed_url
                manifest_hashes[view_key] = manifest_hash
                verified.append(is_verified)
                identity_locked.append(was_identity_locked)
        primary_view = requested_view if requested_view in images else next(iter(images))
        response_payload = {
                "imageUrl": images[primary_view],
                "images": images,
                "backgroundColors": avatar_background_colors,
                "backgroundGradients": avatar_background_gradients,
                "manifestHash": manifest_hashes[primary_view],
                "manifestHashes": manifest_hashes,
                "manifestVerified": all(verified),
                "pipeline": "Genblaze",
                "provider": "Google Nano Banana 2",
                "model": "gemini-3.1-flash-image",
                "chromaKey": {
                    "name": None,
                    "hex": None,
                    "removed": False,
                },
                "avatarRenderMode": avatar_render_mode if mode == "avatar" else None,
                "finalBackground": (
                    "SMART MIRROR warm neutral #E8E5DC"
                    if mode == "avatar"
                    else "SMART MIRROR warm neutral #EAE7DF"
                ),
                "youcam": youcam_analysis,
                "storage": "Backblaze B2",
                "identityPreservation": "youcam-face-swap" if all(identity_locked) else "nano-banana-reference",
                "generationMode": (
                    "multiview-sheet-2k"
                    if generation_mode == "multiview-sheet"
                    else "single-view-progressive" if requested_view else "three-view-avatar"
                ),
                "garmentReferenceCount": len(garment_assets),
                "generatedView": primary_view,
                "remainingViews": [key for key, _ in all_views if key not in images],
                "cacheHit": False,
                "requestId": request_id,
                "cachedAt": time.time(),
            }
        estimated_cost_usd = round(
            sum(float(event.get("estimatedCostUsd", 0) or 0) for event in billing_events), 6
        )
        response_payload["billing"] = {
            "estimatedCostUsd": estimated_cost_usd,
            "geminiCalls": len([event for event in billing_events if event.get("status") == "completed"]),
            "events": billing_events,
            "pricingVersion": "Gemini API public pricing checked 2026-07-31",
            "note": "Estimate based on actual Gemini usage metadata and published model prices; Google billing is authoritative.",
        }
        audit_id = request_id or uuid.uuid4().hex
        audit_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        audit_key = f"smartmirror/audit/{audit_date}/{audit_id}.json"
        audit_payload = {
            "requestId": audit_id,
            "createdAt": datetime.now(timezone.utc).isoformat(),
            "mode": mode,
            "generationMode": response_payload["generationMode"],
            "generatedView": primary_view,
            "cacheHit": False,
            "billing": response_payload["billing"],
            "manifestHashes": manifest_hashes,
            "storage": "Backblaze B2",
        }
        input_backend.put(
            audit_key,
            json.dumps(audit_payload, ensure_ascii=False).encode("utf-8"),
            content_type="application/json",
        )
        response_payload["billing"]["auditKey"] = audit_key
        if cache_key:
            input_backend.put(
                cache_key,
                json.dumps(response_payload).encode("utf-8"),
                content_type="application/json",
            )
        if mode == "tryon" and payload.get("notifyOnComplete") and notification_uid:
            try:
                _append_tryon_to_account_state(notification_uid, response_payload, payload)
                _send_user_push(
                    notification_uid,
                    "Votre essayage est prêt",
                    "Votre nouveau rendu est disponible dans le Studio.",
                    "/?studio=1&notification=tryon",
                )
            except Exception:
                logging.exception("SMART MIRROR try-on push failed")
        return https_fn.Response(
            json.dumps(response_payload),
            status=200,
            headers=headers,
            content_type="application/json",
        )
    except Exception as exc:
        logging.exception("SMART MIRROR Genblaze pipeline failed")
        return https_fn.Response(
            json.dumps({"error": "Le pipeline Genblaze n’a pas pu terminer la génération.", "detail": str(exc)[:300]}),
            status=500,
            headers=headers,
            content_type="application/json",
        )
    finally:
        if request_id:
            with _active_request_ids_lock:
                _active_request_ids.discard(request_id)


@https_fn.on_request(
    region="us-central1",
    timeout_sec=60,
    memory=options.MemoryOption.MB_256,
    secrets=["KLING_API_KEY", "B2_KEY_ID", "B2_APP_KEY", "B2_BUCKET_NAME", "B2_REGION"],
)
def generate_kling_video(request: https_fn.Request) -> https_fn.Response:
    """Launch a Kling multi-image fashion video task."""
    headers = cors_headers(request)
    if request.method == "OPTIONS":
        return https_fn.Response("", status=204, headers=headers)
    if request.method != "POST":
        return https_fn.Response(
            json.dumps({"error": "Méthode non autorisée."}),
            status=405,
            headers=headers,
            content_type="application/json",
        )
    try:
        payload = request.get_json(silent=True) or {}
        notification_uid = _optional_authenticated_uid(request)
        images = payload.get("images") or []
        requested_audio_track = _video_audio_track("pending", payload.get("audioTrack"))
        video_kind = "avatar-presentation" if payload.get("videoKind") == "avatar-presentation" else "try-on"
        requested_background = str(payload.get("backgroundColor") or "").strip()
        video_background_color = requested_background if re.fullmatch(r"#[0-9A-Fa-f]{6}", requested_background) else "#e8e5dc"
        logging.info("SMART MIRROR Kling submission received with %s image references", len(images) if isinstance(images, list) else 0)
        if not isinstance(images, list):
            raise ValueError("Les vues de l’essayage sont invalides.")
        valid_images = []
        for value in images[:4]:
            if not isinstance(value, str):
                continue
            parsed = urlparse(value)
            allowed = parsed.hostname and (
                parsed.hostname == "smartmirror-ci.web.app"
                or parsed.hostname.endswith(".backblazeb2.com")
            )
            if parsed.scheme == "https" and allowed:
                valid_images.append(value)
        if len(valid_images) < 2:
            raise ValueError("Au moins deux vues HTTPS de l’essayage sont nécessaires.")
        logging.info("SMART MIRROR sending %s validated try-on views to Kling", len(valid_images))

        kling_payload = {
            "element_name": "SMARTAVATAR" if video_kind == "avatar-presentation" else "SMARTLOOK",
            "element_description": (
                "The exact SMART MIRROR avatar, ready for virtual fashion try-ons, shown from multiple angles."
                if video_kind == "avatar-presentation"
                else "The exact SMART MIRROR user wearing the selected garment, shown from four angles."
            ),
            "reference_type": "image_refer",
            "element_image_list": {
                "frontal_image": valid_images[0],
                "refer_images": [{"image_url": image_url} for image_url in valid_images[1:]],
            },
            "tag_list": [{"tag_id": "o_102"}, {"tag_id": "o_105"}],
        }
        response = requests.post(
            "https://api-singapore.klingai.com/v1/general/advanced-custom-elements",
            headers=_kling_headers(),
            json=kling_payload,
            timeout=45,
        )
        response.raise_for_status()
        result = response.json()
        if int(result.get("code", -1)) != 0:
            raise RuntimeError(str(result.get("message") or "Kling a refusé la génération."))
        task_id = str((result.get("data") or {}).get("task_id", "")).strip()
        if not task_id:
            raise RuntimeError("Kling n’a retourné aucun identifiant de tâche.")
        # Kling 3.0 requires a first_frame even when an Element is supplied.
        # Persist the validated references so the polling function can attach
        # the exact front view once the multi-image Element is ready.
        backend = S3StorageBackend.for_backblaze(
            os.environ["B2_BUCKET_NAME"].strip(),
            region=os.environ["B2_REGION"].strip(),
            key_id=os.environ["B2_KEY_ID"].strip(),
            app_key=os.environ["B2_APP_KEY"].strip(),
        )
        source_key = f"smartmirror/videos/kling/e-{task_id}/source.json"
        backend.put(
            source_key,
            json.dumps({"images": valid_images, "backgroundColor": video_background_color, "audioTrack": requested_audio_track, "videoKind": video_kind, "tryOnManifestHash": payload.get("tryOnManifestHash"), "uid": notification_uid, "createdAt": datetime.now(timezone.utc).isoformat()}).encode("utf-8"),
            content_type="application/json",
        )
        return https_fn.Response(
            json.dumps({"taskId": f"e-{task_id}", "status": "submitted", "progress": 8, "provider": "Kling AI", "model": "kling-3.0", "imagesAccepted": len(valid_images)}),
            status=202,
            headers=headers,
            content_type="application/json",
        )
    except Exception as exc:
        logging.exception("SMART MIRROR Kling video submission failed")
        return https_fn.Response(
            json.dumps({"error": "La vidéo n’a pas pu être lancée.", "detail": str(exc)[:300]}),
            status=502,
            headers=headers,
            content_type="application/json",
        )


@https_fn.on_request(
    region="us-central1",
    timeout_sec=240,
    memory=options.MemoryOption.MB_512,
    secrets=["KLING_API_KEY", "B2_KEY_ID", "B2_APP_KEY", "B2_BUCKET_NAME", "B2_REGION"],
)
def get_kling_video_status(request: https_fn.Request) -> https_fn.Response:
    """Poll Kling and persist a completed MP4 plus its manifest in Backblaze B2."""
    headers = cors_headers(request)
    if request.method == "OPTIONS":
        return https_fn.Response("", status=204, headers=headers)
    if request.method != "GET":
        return https_fn.Response(json.dumps({"error": "Méthode non autorisée."}), status=405, headers=headers, content_type="application/json")
    try:
        task_id = str(request.args.get("taskId", "")).strip()
        if not task_id or len(task_id) > 160 or any(ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for ch in task_id):
            raise ValueError("Identifiant Kling invalide.")
        stage, kling_task_id = ("element", task_id[2:]) if task_id.startswith("e-") else ("video", task_id[2:] if task_id.startswith("v-") else task_id)
        backend = S3StorageBackend.for_backblaze(
            os.environ["B2_BUCKET_NAME"].strip(),
            region=os.environ["B2_REGION"].strip(),
            key_id=os.environ["B2_KEY_ID"].strip(),
            app_key=os.environ["B2_APP_KEY"].strip(),
        )
        manifest_key = f"smartmirror/videos/kling/{task_id}/manifest.json"
        if backend.exists(manifest_key):
            manifest = json.loads(backend.get(manifest_key).decode("utf-8"))
            manifest_changed = False
            if not manifest.get("audioIncluded"):
                track_number = _video_audio_track(task_id, manifest.get("audioTrack"))
                mixed_bytes = _mix_video_with_smartmirror_audio(backend.get(manifest["objectKey"]), track_number)
                backend.put(manifest["objectKey"], mixed_bytes, content_type="video/mp4")
                manifest.update({
                    "audioIncluded": True,
                    "audioTrack": track_number,
                    "sha256": hashlib.sha256(mixed_bytes).hexdigest(),
                    "sizeBytes": len(mixed_bytes),
                    "mixedAt": datetime.now(timezone.utc).isoformat(),
                })
                manifest_changed = True
            if not manifest.get("backgroundColor") and manifest.get("objectKey"):
                manifest["backgroundColor"] = _measure_video_background_color(backend.get(manifest["objectKey"]))
                manifest["backgroundMeasuredAt"] = datetime.now(timezone.utc).isoformat()
                manifest_changed = True
            if manifest_changed:
                backend.put(manifest_key, json.dumps(manifest).encode("utf-8"), content_type="application/json")
            source_key = f"smartmirror/videos/kling/{task_id}/source.json"
            source_manifest = json.loads(backend.get(source_key).decode("utf-8")) if backend.exists(source_key) else {}
            if source_manifest.get("uid") and not manifest.get("pushSentAt"):
                try:
                    _attach_video_to_account_state(str(source_manifest["uid"]), source_manifest, manifest)
                    _send_user_push(str(source_manifest["uid"]), "Votre vidéo est prête", "Regardez-la dans le Studio SMART MIRROR.", "/?studio=1&notification=video")
                    manifest["pushSentAt"] = datetime.now(timezone.utc).isoformat()
                    backend.put(manifest_key, json.dumps(manifest).encode("utf-8"), content_type="application/json")
                except Exception:
                    logging.exception("SMART MIRROR Kling push failed")
            manifest["videoUrl"] = backend.presigned_get_url(manifest["objectKey"], expires_in=604800)
            return https_fn.Response(json.dumps(manifest), status=200, headers=headers, content_type="application/json")

        if stage == "element":
            response = requests.get(
                f"https://api-singapore.klingai.com/v1/general/advanced-custom-elements/{kling_task_id}",
                headers=_kling_headers(),
                timeout=45,
            )
        else:
            response = requests.get(
                "https://api-singapore.klingai.com/tasks",
                headers=_kling_headers(),
                params={"task_ids": kling_task_id},
                timeout=45,
            )
        response.raise_for_status()
        result = response.json()
        if int(result.get("code", -1)) != 0:
            raise RuntimeError(str(result.get("message") or "Statut Kling indisponible."))
        raw_data = result.get("data") or {}
        data = (raw_data[0] if isinstance(raw_data, list) and raw_data else raw_data) or {}
        task_status = str(data.get("task_status") or data.get("status") or "submitted")
        if task_status in ("failed", "fail"):
            return https_fn.Response(
                json.dumps({"status": "failed", "error": data.get("task_status_msg") or "La génération Kling a échoué."}),
                status=200,
                headers=headers,
                content_type="application/json",
            )
        if task_status not in ("succeed", "succeeded"):
            progress = 58 if stage == "video" and task_status == "processing" else 22 if stage == "element" else 40
            return https_fn.Response(json.dumps({"status": task_status, "progress": progress}), status=200, headers=headers, content_type="application/json")

        if stage == "element":
            elements = ((data.get("task_result") or {}).get("elements") or [])
            element_id = str((elements[0] if elements else {}).get("element_id", "")).strip()
            if not element_id:
                raise RuntimeError("Kling n’a retourné aucun élément multi-vues exploitable.")
            source_key = f"smartmirror/videos/kling/e-{kling_task_id}/source.json"
            if not backend.exists(source_key):
                raise RuntimeError("La vue de départ de la vidéo est introuvable.")
            source_manifest = json.loads(backend.get(source_key).decode("utf-8"))
            source_images = source_manifest.get("images") or []
            source_background = str(source_manifest.get("backgroundColor") or "#e8e5dc").strip()
            video_kind = str(source_manifest.get("videoKind") or "try-on")
            video_background_color = source_background if re.fullmatch(r"#[0-9A-Fa-f]{6}", source_background) else "#e8e5dc"
            first_frame_url = str(source_images[0] if source_images else "").strip()
            if not first_frame_url.startswith("https://"):
                raise RuntimeError("La vue de face ne peut pas être transmise à Kling.")
            presentation_prompt = (
                "@SMARTLOOK makes one elegant, slow and natural presentation turn in a continuous fixed-camera shot: "
                "front, right profile, back, left profile, then front. The avatar calmly shows that it is ready for virtual fashion try-ons. "
                "Preserve the exact face, body, skin tone, underwear, colors and proportions from all references. "
                "Keep the complete person continuously inside the frame with a generous safety margin on all four sides. "
                "Both hands, every finger, both feet, the top of the hair and the full body silhouette must remain fully visible in every frame; "
                "never crop, clip, erase, merge or deform any hand, finger, arm, foot or body part during the turn. "
                f"The entire background must be the exact uniform flat solid color {video_background_color}, edge to edge in every frame. "
                "Every outer border and corner must contain only that same solid background color, with no white line, light strip, frame, seam or border. "
                "No zoom, camera movement, garment change, gradient, vignette, hotspot, texture, floor line, horizon, cast shadow, camera cut, text or added accessory."
                if video_kind == "avatar-presentation"
                else
                "@SMARTLOOK performs one slow, natural fashion turn in a continuous fixed-camera shot: "
                "front, right profile, back, left profile, then front. Preserve the exact face, body, skin tone, "
                "garment construction, fabric, colors and proportions from all references. The entire background "
                f"must be the exact uniform flat solid color {video_background_color}, edge to edge in every frame. "
                "No gradient, vignette, hotspot, texture, floor line, horizon, cast shadow, camera cut or added accessory."
            )
            video_response = requests.post(
                "https://api-singapore.klingai.com/image-to-video/kling-3.0",
                headers=_kling_headers(),
                json={
                    "contents": [
                        {
                            "type": "prompt",
                            "text": presentation_prompt,
                        },
                        {"type": "first_frame", "url": first_frame_url},
                        {"type": "element", "element_id": element_id, "id": "SMARTLOOK"},
                    ],
                    "settings": {"resolution": "720p", "duration": 5, "audio": "off", "multi_shot": False},
                    "options": {"watermark_info": {"enabled": False}},
                },
                timeout=45,
            )
            if not video_response.ok:
                raise RuntimeError(f"Kling video HTTP {video_response.status_code}: {video_response.text[:500]}")
            video_result = video_response.json()
            if int(video_result.get("code", -1)) != 0:
                raise RuntimeError(str(video_result.get("message") or "Kling a refusé la vidéo."))
            video_task_id = str((video_result.get("data") or {}).get("id", "")).strip()
            if not video_task_id:
                raise RuntimeError("Kling n’a retourné aucun identifiant vidéo.")
            backend.put(
                f"smartmirror/videos/kling/v-{video_task_id}/source.json",
                json.dumps(source_manifest).encode("utf-8"),
                content_type="application/json",
            )
            source_manifest["nextTaskId"] = f"v-{video_task_id}"
            backend.put(source_key, json.dumps(source_manifest).encode("utf-8"), content_type="application/json")
            return https_fn.Response(
                json.dumps({"taskId": f"v-{video_task_id}", "status": "submitted", "progress": 32}),
                status=200,
                headers=headers,
                content_type="application/json",
            )

        outputs = data.get("outputs") or []
        videos = [item for item in outputs if item.get("type") == "video"]
        video_url = str((videos[0] if videos else {}).get("url", ""))
        if not video_url.startswith("https://"):
            raise RuntimeError("Kling n’a retourné aucune vidéo exploitable.")
        video_response = requests.get(video_url, timeout=90)
        video_response.raise_for_status()
        video_bytes = video_response.content
        if not video_bytes or len(video_bytes) > 150 * 1024 * 1024:
            raise RuntimeError("La vidéo Kling est vide ou trop volumineuse.")
        source_key = f"smartmirror/videos/kling/{task_id}/source.json"
        source_manifest = json.loads(backend.get(source_key).decode("utf-8")) if backend.exists(source_key) else {}
        track_number = _video_audio_track(task_id, source_manifest.get("audioTrack"))
        video_bytes = _mix_video_with_smartmirror_audio(video_bytes, track_number)
        object_key = f"smartmirror/videos/kling/{task_id}/smartmirror-turntable.mp4"
        backend.put(object_key, video_bytes, content_type="video/mp4")
        manifest = {
            "status": "succeed",
            "progress": 100,
            "taskId": task_id,
            "provider": "Kling AI",
            "model": "kling-3.0",
            "audioIncluded": True,
            "audioTrack": track_number,
            "backgroundColor": _measure_video_background_color(video_bytes),
            "storage": "Backblaze B2",
            "objectKey": object_key,
            "sha256": hashlib.sha256(video_bytes).hexdigest(),
            "sizeBytes": len(video_bytes),
            "storedAt": datetime.now(timezone.utc).isoformat(),
        }
        backend.put(manifest_key, json.dumps(manifest).encode("utf-8"), content_type="application/json")
        if source_manifest.get("uid"):
            try:
                _attach_video_to_account_state(str(source_manifest["uid"]), source_manifest, manifest)
                _send_user_push(str(source_manifest["uid"]), "Votre vidéo est prête", "Regardez-la dans le Studio SMART MIRROR.", "/?studio=1&notification=video")
                manifest["pushSentAt"] = datetime.now(timezone.utc).isoformat()
                backend.put(manifest_key, json.dumps(manifest).encode("utf-8"), content_type="application/json")
            except Exception:
                logging.exception("SMART MIRROR Kling push failed")
        manifest["videoUrl"] = backend.presigned_get_url(object_key, expires_in=604800)
        return https_fn.Response(json.dumps(manifest), status=200, headers=headers, content_type="application/json")
    except Exception as exc:
        logging.exception("SMART MIRROR Kling video status failed")
        return https_fn.Response(
            json.dumps({"error": "Le suivi de la vidéo a échoué.", "detail": str(exc)[:300]}),
            status=502,
            headers=headers,
            content_type="application/json",
        )


@scheduler_fn.on_schedule(
    schedule="every 2 minutes",
    region="us-central1",
    timeout_sec=240,
    memory=options.MemoryOption.MB_512,
    secrets=["KLING_API_KEY", "B2_KEY_ID", "B2_APP_KEY", "B2_BUCKET_NAME", "B2_REGION"],
)
def monitor_kling_notifications(event: scheduler_fn.ScheduledEvent) -> None:
    """Keep Kling jobs moving and notify their owner even when the PWA is closed."""
    backend = _b2_backend()
    page = backend.list("smartmirror/videos/kling/", max_keys=1000)
    checked = 0
    for entry in page.entries:
        if checked >= 40 or not entry.key.endswith("/source.json"):
            continue
        task_id = entry.key.split("/")[-2]
        manifest_key = f"smartmirror/videos/kling/{task_id}/manifest.json"
        source = json.loads(backend.get(entry.key).decode("utf-8"))
        if task_id.startswith("e-") and source.get("nextTaskId"):
            continue
        if backend.exists(manifest_key):
            manifest = json.loads(backend.get(manifest_key).decode("utf-8"))
            if manifest.get("pushSentAt"):
                continue
        checked += 1
        try:
            requests.get(
                "https://us-central1-smartmirror-ci.cloudfunctions.net/get_kling_video_status",
                params={"taskId": task_id},
                timeout=220,
            ).raise_for_status()
        except Exception:
            logging.exception("SMART MIRROR scheduled Kling monitor failed for %s", task_id)
