"""SMART MIRROR: avatar -> rendu IA -> vidéo -> B2 + manifest Genblaze."""
from __future__ import annotations
import argparse, json, os
from pathlib import Path
from dotenv import load_dotenv
from genblaze_core import KeyStrategy, Modality, ObjectStorageSink, Pipeline
from genblaze_openai import DalleProvider, SoraProvider
from genblaze_s3 import S3StorageBackend

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env.local")

def require(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"Variable obligatoire absente : {name}")
    return value

def run(args):
    for name in ("YOUCAM_API_KEY", "YOUCAM_SECRET_KEY", "B2_KEY_ID", "B2_APP_KEY", "OPENAI_API_KEY"):
        require(name)
    storage = ObjectStorageSink(
        S3StorageBackend.for_backblaze(os.getenv("B2_BUCKET_NAME", "smartmirror-amabing-media")),
        key_strategy=KeyStrategy.HIERARCHICAL,
    )
    prompt = (
        "Photorealistic full-body virtual try-on for SMART MIRROR. Preserve identity, "
        f"skin tone ({args.skin_tone}), {args.gender} body and {args.body_type} morphology. "
        f"Avatar reference: {args.avatar_url}. Garment reference: {args.garment_url}. "
        "Natural anatomy, realistic textile folds, neutral studio, three-quarter pose."
    )
    image_result = Pipeline("smartmirror-try-on-image").step(
        DalleProvider(), model="dall-e-3", prompt=prompt, modality=Modality.IMAGE
    ).run(sink=storage)
    image = image_result.run.steps[0].assets[0]
    result = {
        "image_url": image.url, "image_sha256": image.sha256,
        "manifest_hash": image_result.manifest.canonical_hash,
        "manifest_verified": image_result.manifest.verify(),
        "providers": {"avatar":"Avaturn Web SDK","skin_face":"Perfect Corp YouCam API","image":"OpenAI DALL-E 3 via Genblaze","storage":"Backblaze B2 via genblaze-s3"}
    }
    if args.video:
        video_result = Pipeline("smartmirror-look-video").step(
            SoraProvider(), model="sora-2",
            prompt=f"Animate a subtle 5-second runway turn. Preserve identity and clothes. Source: {image.url}",
            modality=Modality.VIDEO, expected_duration_sec=120,
        ).run(sink=storage)
        video = video_result.run.steps[0].assets[0]
        result.update(video_url=video.url, video_sha256=video.sha256, video_manifest_hash=video_result.manifest.canonical_hash, video_manifest_verified=video_result.manifest.verify())
        result["providers"]["video"] = "OpenAI Sora 2 via Genblaze"
    return result

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--avatar-url", required=True); p.add_argument("--garment-url", required=True)
    p.add_argument("--skin-tone", default="Fitzpatrick IV"); p.add_argument("--gender", choices=("male","female"), required=True)
    p.add_argument("--body-type", default="standard"); p.add_argument("--video", action="store_true")
    print(json.dumps(run(p.parse_args()), ensure_ascii=False, indent=2))
if __name__ == "__main__": main()
