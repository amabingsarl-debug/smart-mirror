"use client";

import { useEffect, useState } from "react";

interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export default function PwaInstall() {
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);

  useEffect(() => {
    const release = "2026-07-31-139";
    if (localStorage.getItem("smartmirror-release") !== release) {
      void (async () => {
        try {
          if ("serviceWorker" in navigator) {
            const registrations = await navigator.serviceWorker.getRegistrations();
            await Promise.all(registrations.map((registration) => registration.unregister()));
          }
          if ("caches" in window) {
            const cacheNames = await caches.keys();
            await Promise.all(cacheNames.filter((name) => name.startsWith("smart-mirror")).map((name) => caches.delete(name)));
          }
        } finally {
          localStorage.setItem("smartmirror-release", release);
          const nextUrl = new URL(window.location.href);
          nextUrl.searchParams.set("release", "113");
          window.location.replace(`${nextUrl.pathname}${nextUrl.search}${nextUrl.hash}`);
        }
      })();
      return;
    }

    let updateTimer: number | undefined;
    const reloadOnNewWorker = () => {
      if (sessionStorage.getItem("smartmirror-worker-reloaded") === "1") return;
      sessionStorage.setItem("smartmirror-worker-reloaded", "1");
      window.location.reload();
    };

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.addEventListener("controllerchange", reloadOnNewWorker);
      void navigator.serviceWorker
        .register("/sw.js?v=79", { updateViaCache: "none" })
        .then(async (registration) => {
          await registration.update();
          updateTimer = window.setInterval(() => void registration.update(), 60_000);
        });
    }

    const onPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("pageshow", () => sessionStorage.removeItem("smartmirror-worker-reloaded"), { once: true });
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      navigator.serviceWorker?.removeEventListener("controllerchange", reloadOnNewWorker);
      if (updateTimer) window.clearInterval(updateTimer);
    };
  }, []);

  if (!installPrompt) return null;

  return (
    <button
      className="pwa-install"
      type="button"
      onClick={async () => {
        await installPrompt.prompt();
        await installPrompt.userChoice;
        setInstallPrompt(null);
      }}
    >
      Installer SMART MIRROR
    </button>
  );
}
