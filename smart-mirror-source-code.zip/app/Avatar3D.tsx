"use client";

import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { ContactShadows, Environment, OrbitControls } from "@react-three/drei";
import { Suspense, useMemo, useRef, useState } from "react";
import * as THREE from "three";

type Avatar3DProps = {
  name: string;
  photo: string;
  skin: string;
  body: "mince" | "standard" | "généreux" | "fort";
  gender: "homme" | "femme";
  topSize: string;
  pantsSize: string;
  height: number;
};

const proportions = {
  mince: { torso: 0.78, hips: 0.7, limb: 0.82 },
  standard: { torso: 0.95, hips: 0.88, limb: 0.94 },
  généreux: { torso: 1.16, hips: 1.08, limb: 1.08 },
  fort: { torso: 1.35, hips: 1.23, limb: 1.2 },
};

function Limb({
  position,
  rotation,
  length,
  radius,
  color,
}: {
  position: [number, number, number];
  rotation?: [number, number, number];
  length: number;
  radius: number;
  color: string;
}) {
  return (
    <mesh position={position} rotation={rotation} castShadow>
      <capsuleGeometry args={[radius, length, 8, 20]} />
      <meshStandardMaterial color={color} roughness={0.58} metalness={0.02} />
    </mesh>
  );
}

function Person({
  profile,
  motion,
}: {
  profile: Avatar3DProps;
  motion: "idle" | "walk";
}) {
  const root = useRef<THREE.Group>(null);
  const leftArm = useRef<THREE.Group>(null);
  const rightArm = useRef<THREE.Group>(null);
  const leftLeg = useRef<THREE.Group>(null);
  const rightLeg = useRef<THREE.Group>(null);
  const shape = proportions[profile.body];
  const isWoman = profile.gender === "femme";
  const shoulderWidth = shape.torso * (isWoman ? 0.86 : 1.04);
  const hipWidth = shape.hips * (isWoman ? 1.16 : 0.96);
  const scale = THREE.MathUtils.clamp(profile.height / 172, 0.84, 1.17);
  const faceTexture = useMemo(() => {
    if (!profile.photo) return null;
    const texture = new THREE.TextureLoader().load(profile.photo);
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  }, [profile.photo]);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    if (!root.current) return;
    root.current.position.y = Math.sin(t * 1.7) * 0.014 - 1.37;
    root.current.rotation.y = Math.sin(t * 0.42) * 0.055;
    const speed = motion === "walk" ? 5.2 : 1.35;
    const amount = motion === "walk" ? 0.56 : 0.045;
    if (leftArm.current && rightArm.current) {
      leftArm.current.rotation.x = Math.sin(t * speed) * amount;
      rightArm.current.rotation.x = -Math.sin(t * speed) * amount;
    }
    if (leftLeg.current && rightLeg.current) {
      leftLeg.current.rotation.x = -Math.sin(t * speed) * amount * 0.72;
      rightLeg.current.rotation.x = Math.sin(t * speed) * amount * 0.72;
    }
  });

  return (
    <group ref={root} scale={scale}>
      <group position={[0, 2.75, 0]}>
        <mesh castShadow>
          <sphereGeometry args={[0.33, 48, 48]} />
          <meshPhysicalMaterial
            color={profile.skin}
            roughness={0.62}
            clearcoat={0.12}
            clearcoatRoughness={0.7}
          />
        </mesh>
        <mesh position={[0, 0.015, 0.322]}>
          <circleGeometry args={[0.265, 48]} />
          {faceTexture ? (
            <meshBasicMaterial map={faceTexture} toneMapped={false} />
          ) : (
            <meshStandardMaterial color={profile.skin} />
          )}
        </mesh>
        <mesh position={[0, 0.27, -0.02]} rotation={[0.1, 0, 0]} castShadow>
          <sphereGeometry args={[0.34, 32, 18, 0, Math.PI * 2, 0, Math.PI / 2]} />
          <meshStandardMaterial color="#171510" roughness={0.92} />
        </mesh>
        <mesh position={[-0.34, 0, 0]} castShadow>
          <sphereGeometry args={[0.055, 20, 20]} />
          <meshStandardMaterial color={profile.skin} />
        </mesh>
        <mesh position={[0.34, 0, 0]} castShadow>
          <sphereGeometry args={[0.055, 20, 20]} />
          <meshStandardMaterial color={profile.skin} />
        </mesh>
      </group>

      <Limb position={[0, 2.35, 0]} length={0.18} radius={0.12} color={profile.skin} />

      <mesh position={[0, 1.72, 0]} scale={[shoulderWidth, 1, 0.72 + shape.torso * 0.12]} castShadow>
        <capsuleGeometry args={[0.46, 0.72, 12, 36]} />
        <meshPhysicalMaterial color={profile.skin} roughness={0.6} clearcoat={0.08} />
      </mesh>
      {isWoman && (
        <>
          <mesh position={[-0.17 * shoulderWidth, 1.79, 0.38]} scale={[shoulderWidth, 1, 1]} castShadow>
            <sphereGeometry args={[0.2, 28, 20]} />
            <meshStandardMaterial color={profile.skin} roughness={0.62} />
          </mesh>
          <mesh position={[0.17 * shoulderWidth, 1.79, 0.38]} scale={[shoulderWidth, 1, 1]} castShadow>
            <sphereGeometry args={[0.2, 28, 20]} />
            <meshStandardMaterial color={profile.skin} roughness={0.62} />
          </mesh>
          <mesh position={[0, 1.78, 0.35]} scale={[shoulderWidth, 0.72, 0.78]} castShadow>
            <capsuleGeometry args={[0.31, 0.18, 8, 28]} />
            <meshPhysicalMaterial color="#262623" roughness={0.5} clearcoat={0.18} />
          </mesh>
          <mesh position={[0, 1.99, 0.16]} scale={[shoulderWidth, 1, 1]} castShadow>
            <boxGeometry args={[0.68, 0.055, 0.055]} />
            <meshStandardMaterial color="#262623" />
          </mesh>
        </>
      )}

      <group ref={leftArm} position={[-0.57 * shoulderWidth, 2.04, 0]}>
        <Limb position={[0, -0.43, 0]} rotation={[0, 0, -0.04]} length={0.65} radius={0.12 * shape.limb} color={profile.skin} />
        <Limb position={[0.04, -1.03, 0]} rotation={[0, 0, -0.06]} length={0.55} radius={0.105 * shape.limb} color={profile.skin} />
      </group>
      <group ref={rightArm} position={[0.57 * shoulderWidth, 2.04, 0]}>
        <Limb position={[0, -0.43, 0]} rotation={[0, 0, 0.04]} length={0.65} radius={0.12 * shape.limb} color={profile.skin} />
        <Limb position={[-0.04, -1.03, 0]} rotation={[0, 0, 0.06]} length={0.55} radius={0.105 * shape.limb} color={profile.skin} />
      </group>

      <mesh position={[0, 0.9, 0]} scale={[hipWidth, 1, 0.78]} castShadow>
        <capsuleGeometry args={[0.39, 0.36, 8, 28]} />
        <meshStandardMaterial color="#262623" roughness={0.58} />
      </mesh>
      <mesh position={[0, 1.12, 0.28]} scale={[hipWidth, 1, 1]} castShadow>
        <boxGeometry args={[0.69, 0.08, 0.12]} />
        <meshStandardMaterial color="#d7ff45" roughness={0.52} />
      </mesh>

      <group ref={leftLeg} position={[-0.22 * hipWidth, 0.74, 0]}>
        <Limb position={[0, -0.48, 0]} length={0.72} radius={0.15 * shape.limb} color="#a19e95" />
        <Limb position={[0, -1.08, 0]} length={0.55} radius={0.125 * shape.limb} color={profile.skin} />
        <mesh position={[0, -1.49, 0.1]} scale={[1, 0.55, 1.65]} castShadow>
          <capsuleGeometry args={[0.16 * shape.limb, 0.12, 8, 18]} />
          <meshStandardMaterial color="#161612" roughness={0.42} />
        </mesh>
      </group>
      <group ref={rightLeg} position={[0.22 * hipWidth, 0.74, 0]}>
        <Limb position={[0, -0.48, 0]} length={0.72} radius={0.15 * shape.limb} color="#a19e95" />
        <Limb position={[0, -1.08, 0]} length={0.55} radius={0.125 * shape.limb} color={profile.skin} />
        <mesh position={[0, -1.49, 0.1]} scale={[1, 0.55, 1.65]} castShadow>
          <capsuleGeometry args={[0.16 * shape.limb, 0.12, 8, 18]} />
          <meshStandardMaterial color="#161612" roughness={0.42} />
        </mesh>
      </group>
    </group>
  );
}

function CameraSetup() {
  const { camera } = useThree();
  useMemo(() => {
    camera.position.set(0, 1.2, 6.4);
    camera.lookAt(0, 1.05, 0);
  }, [camera]);
  return null;
}

export default function Avatar3D(profile: Avatar3DProps) {
  const [motion, setMotion] = useState<"idle" | "walk">("idle");
  return (
    <div className="avatar-3d">
      <Canvas shadows dpr={[1, 1.75]} gl={{ antialias: true, alpha: true }}>
        <CameraSetup />
        <ambientLight intensity={1.5} />
        <directionalLight position={[4, 7, 5]} intensity={3.2} castShadow shadow-mapSize={[1024, 1024]} />
        <spotLight position={[-4, 4, 3]} intensity={2.2} angle={0.5} penumbra={1} color="#d7ff45" />
        <Suspense fallback={null}>
          <Person profile={profile} motion={motion} />
          <Environment preset="studio" />
          <ContactShadows position={[0, -1.43, 0]} opacity={0.42} scale={6} blur={2.3} far={4} />
        </Suspense>
        <OrbitControls
          enablePan={false}
          enableZoom
          minDistance={4.3}
          maxDistance={8}
          minPolarAngle={Math.PI / 3}
          maxPolarAngle={Math.PI / 1.85}
          autoRotate={motion === "idle"}
          autoRotateSpeed={0.65}
          target={[0, 1.05, 0]}
        />
      </Canvas>
      <div className="avatar-3d-badge"><i /> Avatar 3D actif</div>
      <div className="motion-controls">
        <button className={motion === "idle" ? "active" : ""} onClick={() => setMotion("idle")}>Pose</button>
        <button className={motion === "walk" ? "active" : ""} onClick={() => setMotion("walk")}>Marche</button>
      </div>
      <p className="drag-hint">Glissez pour tourner · Pincez pour zoomer</p>
    </div>
  );
}
