import { getApp, getApps, initializeApp } from "firebase/app";
import { browserLocalPersistence, getAuth, setPersistence } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCpEfEfXeggfyRwq2R7KjcKWEu3Q7T_b_E",
  authDomain: "smartmirror-ci.firebaseapp.com",
  projectId: "smartmirror-ci",
  storageBucket: "smartmirror-ci.firebasestorage.app",
  messagingSenderId: "709233619866",
  appId: "1:709233619866:web:0e111caa476cbbe6d44023",
};

export const firebaseApp = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const smartMirrorAuth = getAuth(firebaseApp);

if (typeof window !== "undefined") {
  void setPersistence(smartMirrorAuth, browserLocalPersistence);
}
