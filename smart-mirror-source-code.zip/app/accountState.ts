import type { User } from "firebase/auth";

const ACCOUNT_KEYS = [
  "smartmirror-profile",
  "smartmirror-client-flow",
  "smartmirror-wardrobe",
  "smartmirror-avatar-library",
  "smartmirror-default-avatar-measurements",
  "smartmirror-active-avatar-id",
  "smartmirror-base-avatar-v2",
  "smartmirror-base-avatar",
  "smartmirror-avatar-background-colors",
  "smartmirror-avatar-background-gradients",
  "smartmirror-youcam-status",
  "smartmirror-pending-product",
] as const;

type AccountSnapshot = {
  version: 1;
  savedAt: string;
  values: Record<string, string>;
};

export async function saveAccountState(user: User) {
  const values: Record<string, string> = {};
  ACCOUNT_KEYS.forEach((key) => {
    const value = localStorage.getItem(key);
    if (value !== null) values[key] = value;
  });
  Object.keys(localStorage).forEach((key) => {
    if (key.startsWith("smartmirror-tryon:")) {
      const value = localStorage.getItem(key);
      if (value !== null) values[key] = value;
    }
  });
  const snapshot: AccountSnapshot = { version: 1, savedAt: new Date().toISOString(), values };
  const token = await user.getIdToken();
  const response = await fetch("/api/account-state", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(snapshot),
  });
  if (!response.ok) throw new Error(`Sauvegarde cloud refusée (${response.status}).`);
}

export async function restoreAccountState(user: User) {
  try {
    const token = await user.getIdToken();
    const response = await fetch("/api/account-state", { headers: { Authorization: `Bearer ${token}` }, cache: "no-store" });
    if (response.status === 404) return false;
    if (!response.ok) throw new Error(`Restauration cloud refusée (${response.status}).`);
    const snapshot = await response.json() as AccountSnapshot;
    if (snapshot.version !== 1 || !snapshot.values) return false;
    clearLocalAccountState();
    Object.entries(snapshot.values).forEach(([key, value]) => localStorage.setItem(key, value));
    localStorage.setItem("smartmirror-local-owner", user.uid);
    return true;
  } catch (error) { throw error; }
}

export function clearLocalAccountState() {
  const keys = Object.keys(localStorage).filter((key) =>
    (key.startsWith("smartmirror-") && key !== "smartmirror-language")
    || key.startsWith("firebase-heartbeat"),
  );
  keys.forEach((key) => localStorage.removeItem(key));
  Object.keys(sessionStorage)
    .filter((key) => key.startsWith("smartmirror-"))
    .forEach((key) => sessionStorage.removeItem(key));
}

export async function clearSmartMirrorCaches() {
  if (!("caches" in window)) return;
  const names = await caches.keys();
  await Promise.all(names.filter((name) => name.startsWith("smartmirror-") || name.startsWith("smart-mirror-"))
    .map((name) => caches.delete(name)));
}
