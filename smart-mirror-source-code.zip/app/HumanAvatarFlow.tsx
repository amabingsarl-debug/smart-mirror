"use client";

import { AvaturnSDK } from "@avaturn/sdk";
import { Canvas } from "@react-three/fiber";
import { ContactShadows, Environment, OrbitControls, useGLTF } from "@react-three/drei";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";

export type ExportResult = {
  url: string;
  urlType: "httpURL" | "dataURL";
  avatarId: string;
  sessionId: string;
  avatarSupportsFaceAnimations: boolean;
  bodyId: string;
  gender: "male" | "female";
};

function HumanModel({ url }: { url: string }) {
  const gltf = useGLTF(url);
  const root = useRef<THREE.Group>(null);
  const model = useMemo(() => gltf.scene.clone(true), [gltf.scene]);

  useEffect(() => {
    const box = new THREE.Box3().setFromObject(model);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    model.position.set(-center.x, -box.min.y - 1.28, -center.z);
    const targetHeight = 3.7;
    const scale = size.y ? targetHeight / size.y : 1;
    model.scale.setScalar(scale);
    model.traverse((object) => {
      if (object instanceof THREE.Mesh) {
        object.castShadow = true;
        object.receiveShadow = true;
      }
    });
  }, [model]);

  return (
    <group ref={root}>
      <primitive object={model} />
    </group>
  );
}

function HumanViewer({ url }: { url: string }) {
  return (
    <div className="human-viewer">
      <Canvas shadows dpr={[1, 1.7]} camera={{ position: [0, 0.7, 5.5], fov: 38 }}>
        <ambientLight intensity={1.3} />
        <directionalLight position={[4, 7, 5]} intensity={3} castShadow />
        <spotLight position={[-4, 5, 4]} intensity={2} angle={0.48} penumbra={1} color="#d7ff45" />
        <Suspense fallback={null}>
          <HumanModel url={url} />
          <Environment preset="studio" />
          <ContactShadows position={[0, -1.28, 0]} opacity={0.42} scale={5} blur={2.4} far={4} />
        </Suspense>
        <OrbitControls
          enablePan={false}
          minDistance={3.7}
          maxDistance={7}
          target={[0, 0.65, 0]}
          minPolarAngle={Math.PI / 3}
          maxPolarAngle={Math.PI / 1.8}
        />
      </Canvas>
      <p className="drag-hint">Glissez pour tourner · Pincez pour zoomer</p>
    </div>
  );
}

export default function HumanAvatarFlow({
  name,
  gender,
  initialAvatar = null,
  onComplete,
  onRecreate,
  viewerOnly = false,
}: {
  name: string;
  gender: "homme" | "femme";
  initialAvatar?: ExportResult | null;
  onComplete?: (avatar: ExportResult) => void;
  onRecreate?: () => void;
  viewerOnly?: boolean;
}) {
  const container = useRef<HTMLDivElement>(null);
  const sdk = useRef<AvaturnSDK | null>(null);
  const [avatar, setAvatar] = useState<ExportResult | null>(initialAvatar);
  const [creatorOpen, setCreatorOpen] = useState(!initialAvatar);
  const [status, setStatus] = useState("Préparation du studio d’avatar…");

  useEffect(() => {
    if (!creatorOpen || !container.current || sdk.current) return;
    const instance = new AvaturnSDK();
    sdk.current = instance;

    instance
      .init(container.current, {
        url: "https://smartmirror.avaturn.dev",
        iframeClassName: "avaturn-frame",
      })
      .then(() => {
        setStatus("Créez votre avatar ici, puis appuyez sur Next : SMART MIRROR le récupérera automatiquement.");
        instance.on("export", (data) => {
          const exported = data as ExportResult;
          setAvatar(exported);
          setCreatorOpen(false);
          setStatus("Votre mannequin humain est prêt.");
        });
      })
      .catch(() => setStatus("Le studio Avaturn n’a pas pu démarrer. Réessayez."));

    return () => {
      sdk.current = null;
    };
  }, [creatorOpen]);

  if (avatar && !creatorOpen) {
    if (viewerOnly) {
      return <HumanViewer url={avatar.url} />;
    }

    return (
      <div className="human-result">
        <HumanViewer url={avatar.url} />
        <div className="avaturn-action-bar">
          <span role="status">
            {name || "Votre mannequin"} · {gender === "femme" ? "Mannequin féminin" : "Mannequin masculin"} · prêt
          </span>
          <button onClick={() => {
            if (onComplete) {
              onComplete(avatar);
              return;
            }
            if (onRecreate) {
              onRecreate();
              return;
            }
            setAvatar(null);
            setCreatorOpen(true);
          }}>
            {onComplete ? "Continuer" : "Recréer"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="avaturn-flow">
      <div ref={container} className="avaturn-container" />
      <div className="avaturn-action-bar">
        <span role="status">
          {status || "Appuyez sur Next dans Avaturn : le mannequin sera transmis automatiquement."}
        </span>
        <button type="button" disabled>Continuer</button>
      </div>
    </div>
  );
}
