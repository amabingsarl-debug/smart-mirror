import type { Metadata, Viewport } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import PwaInstall from "./PwaInstall";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SMART MIRROR — Votre style, réinventé",
  description:
    "Créez votre avatar mode personnel à partir de votre visage, votre morphologie et vos tailles.",
  manifest: "/manifest.webmanifest",
  applicationName: "SMART MIRROR",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "SMART MIRROR",
  },
  icons: {
    icon: [
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" }],
  },
};

export const viewport: Viewport = {
  themeColor: "#171711",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body className={`${geistSans.variable} antialiased`}>
        {children}
        <PwaInstall />
      </body>
    </html>
  );
}
