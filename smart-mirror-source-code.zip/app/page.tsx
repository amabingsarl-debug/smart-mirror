"use client";

import { ChangeEvent, useEffect, useMemo, useRef, useState } from "react";
import { GoogleAuthProvider, onAuthStateChanged, signInWithPopup, signOut, type User } from "firebase/auth";
import HumanAvatarFlow, { type ExportResult } from "./HumanAvatarFlow";
import { smartMirrorAuth } from "./firebaseClient";
import { clearLocalAccountState, clearSmartMirrorCaches, restoreAccountState, saveAccountState } from "./accountState";
import { disablePushNotifications, enablePushNotifications } from "./pushNotifications";

type PhotoKey = "faceFront" | "bodyFront" | "bodyRight" | "bodyBack";
type AvatarBackgroundColors = Partial<Record<PhotoKey, string>>;
type AvatarBackgroundGradients = Partial<Record<PhotoKey, { top: string; bottom: string }>>;
type DownloadViewKey = "front" | "right" | "back" | "left";

function warmAvatarImageCache(images: Partial<Record<PhotoKey, string>>) {
  const urls = Object.values(images).filter((url): url is string => Boolean(url));
  urls.forEach((url) => {
    const preload = new Image();
    preload.decoding = "async";
    preload.src = url;
  });
  navigator.serviceWorker?.controller?.postMessage({ type: "CACHE_AVATAR_IMAGES", urls });
}

function warmVideoCache(url: string) {
  if (!url) return;
  navigator.serviceWorker?.controller?.postMessage({ type: "CACHE_MEDIA_URLS", urls: [url] });
}

function imageSurfaceStyle(
  colors: AvatarBackgroundColors | undefined,
  gradients: AvatarBackgroundGradients | undefined,
  key: PhotoKey = "bodyFront",
): React.CSSProperties {
  const color = colors?.[key] || "#e8e5dc";
  const gradient = gradients?.[key];
  return {
    backgroundColor: color,
    backgroundImage: gradient
      ? `linear-gradient(to bottom, ${gradient.top}, ${gradient.bottom})`
      : "none",
  };
}
type GarmentType = "auto" | "chemise" | "pantalon" | "chaussures" | "ensemble";
type AppLanguage = "fr" | "en" | "zh";
type WardrobeItem = {
  id: number;
  name: string;
  type: GarmentType;
  size: string;
  image: string;
  images: Partial<Record<PhotoKey, string>>;
  garmentFront: string;
  garmentBack: string;
  manifestHash: string;
  backgroundColors?: AvatarBackgroundColors;
  backgroundGradients?: AvatarBackgroundGradients;
  garmentReferenceCount?: number;
  videoUrl?: string;
  videoTaskId?: string;
  videoBackgroundColor?: string;
  audioTrack?: string;
  videoHasAudio?: boolean;
  unreadTryOn?: boolean;
  unreadVideo?: boolean;
};

const LEGACY_KLING_TASK_BY_TRYON_NUMBER: Record<number, string> = {
  3: "v-912714077955297297",
  5: "v-912702210813857873",
};
const LEGACY_KLING_BACKGROUND_BY_TRYON_NUMBER: Record<number, string> = {
  3: "rgb(230, 221, 214)",
};
const SMART_MIRROR_AUDIO_TRACKS = Array.from({ length: 10 }, (_, index) => `/audio/smart-lounge-${String(index + 1).padStart(2, "0")}.wav?v=2`);
const DEFAULT_AVATAR_AUDIO_TRACKS: Record<"femme" | "homme", string> = {
  femme: SMART_MIRROR_AUDIO_TRACKS[2],
  homme: SMART_MIRROR_AUDIO_TRACKS[7],
};

type TryOnResult = {
  imageUrl: string;
  images: Partial<Record<PhotoKey, string>>;
  manifestHash: string;
  manifestVerified: boolean;
  backgroundColors?: AvatarBackgroundColors;
  backgroundGradients?: AvatarBackgroundGradients;
};

type ShopProduct = {
  id: string;
  name: string;
  type: GarmentType;
  price: string;
  image: string;
  color: string;
};

type Profile = {
  gender: "" | "homme" | "femme";
  name: string;
  email: string;
  password: string;
  height: number;
  topSize: string;
  pantsSize: string;
  shoeSize: string;
};

type AvatarMeasurements = Pick<Profile, "height" | "topSize" | "pantsSize" | "shoeSize">;

type AvatarLibraryItem = {
  id: string;
  label: string;
  gender: Profile["gender"];
  images: Partial<Record<PhotoKey, string>>;
  backgroundColors?: AvatarBackgroundColors;
  backgroundGradients?: AvatarBackgroundGradients;
  identityPhotos: Partial<Record<PhotoKey, string>>;
  measurements: AvatarMeasurements;
  createdAt: string;
  presentationVideoUrl?: string;
  presentationVideoTaskId?: string;
  presentationVideoBackgroundColor?: string;
  presentationVideoHasAudio?: boolean;
};

type AvatarVideoRecord = {
  videoUrl?: string;
  taskId?: string;
  backgroundColor?: string;
  hasAudio?: boolean;
};

type AvatarVideoTarget = {
  usesDefaultAvatar: boolean;
  gender: "femme" | "homme";
  avatarId: string;
};

const photoGuides: { key: PhotoKey; label: string; hint: string; kind: "face" | "body"; example: string }[] = [
  { key: "faceFront", label: "Visage de face", hint: "Regardez droit devant vous", kind: "face", example: "/pose-examples/face-front.webp" },
  { key: "bodyFront", label: "Corps de face", hint: "Le corps entier doit être visible", kind: "body", example: "/pose-examples/body-front.webp" },
  { key: "bodyRight", label: "Corps de profil", hint: "Restez droit et entièrement visible", kind: "body", example: "/pose-examples/body-right.webp" },
  { key: "bodyBack", label: "Corps de dos", hint: "Gardez une posture naturelle", kind: "body", example: "/pose-examples/body-back.webp" },
];

const onboardingPhotoSteps = [
  {
    step: 1,
    key: "faceFront" as PhotoKey,
    title: "Commençons par votre visage.",
    utility: "Cette photo devient votre identité principale et aide l’IA à préserver votre visage dans chaque essayage.",
    optional: true,
  },
  {
    step: 2,
    key: "bodyFront" as PhotoKey,
    title: "Votre silhouette de face.",
    utility: "Elle permet de respecter vos proportions, votre taille apparente et la façon dont le vêtement tombe sur vous.",
    optional: true,
  },
  {
    step: 3,
    key: "bodyRight" as PhotoKey,
    title: "Ajoutez votre profil.",
    utility: "Cette vue facultative améliore l’épaisseur, les courbes et les profils gauche et droit de votre avatar.",
    optional: true,
  },
  {
    step: 4,
    key: "bodyBack" as PhotoKey,
    title: "Une vue de dos.",
    utility: "Cette photo facultative rend plus fidèles le dos, les cheveux et l’arrière des vêtements.",
    optional: true,
  },
];

const initialProfile: Profile = {
  gender: "femme",
  name: "",
  email: "",
  password: "",
  height: 172,
  topSize: "M",
  pantsSize: "42",
  shoeSize: "41",
};

const bodyRotation: { key: PhotoKey; label: string }[] = [
  { key: "bodyFront", label: "Vue de face" },
  { key: "bodyRight", label: "Profil droit" },
  { key: "bodyBack", label: "Vue de dos" },
  { key: "bodyRight", label: "Profil gauche" },
];
const downloadViewKeys: DownloadViewKey[] = ["front", "right", "back", "left"];

const TRYON_API_URL = "https://us-central1-smartmirror-ci.cloudfunctions.net/generate_tryon";
// Same-origin routes are forwarded by Firebase to the Kling functions. This is
// more reliable in installed PWAs and mobile browsers than cross-origin calls.
const KLING_VIDEO_API_URL = "/api/kling-video";
const KLING_VIDEO_STATUS_API_URL = "/api/kling-video-status";
const DEFAULT_AVATAR_PRESENTATION_VIDEOS: Record<"femme" | "homme", AvatarVideoRecord> = {
  femme: { taskId: "v-912896303905644547", backgroundColor: "#e5ddd0" },
  homme: { taskId: "v-912873405051961393", backgroundColor: "#d3bba1" },
};
const IDENTITY_UPLOAD_API_URL = "https://us-central1-smartmirror-ci.cloudfunctions.net/upload_identity_photo";
const STUDIO_STEP = 6;
const SHOP_STEP = 7;
const PROFILE_STEP = 8;
const CLOSET_STEP = 9;

const UI_TRANSLATIONS: Record<string, { en: string; zh: string }> = {
  "Accueil": { en: "Home", zh: "首页" },
  "Boutique": { en: "Shop", zh: "商店" },
  "Profil": { en: "Profile", zh: "个人资料" },
  "Paramètres": { en: "Settings", zh: "设置" },
  "Langue": { en: "Language", zh: "语言" },
  "Déconnexion": { en: "Sign out", zh: "退出登录" },
  "Vue de face": { en: "Front view", zh: "正面" },
  "Profil droit": { en: "Right profile", zh: "右侧面" },
  "Profil gauche": { en: "Left profile", zh: "左侧面" },
  "Vue de dos": { en: "Back view", zh: "背面" },
  "HAUT": { en: "TOP", zh: "上身" },
  "BAS": { en: "BOTTOM", zh: "下身" },
  "Essayer un vêtement": { en: "Try on a garment", zh: "试穿服装" },
  "Commençons par votre visage.": { en: "Let’s start with your face.", zh: "先从您的脸部开始。" },
  "Cette photo devient votre identité principale et aide l’IA à préserver votre visage dans chaque essayage.": { en: "This photo becomes your main identity and helps AI preserve your face in every try-on.", zh: "这张照片将成为您的主要身份图像，帮助 AI 在每次试穿中保留您的面部特征。" },
  "Votre genre": { en: "Your gender", zh: "您的性别" },
  "Femme": { en: "Woman", zh: "女性" },
  "Homme": { en: "Man", zh: "男性" },
  "Visage de face": { en: "Front-facing portrait", zh: "正面人像" },
  "Regardez droit devant vous": { en: "Look straight ahead", zh: "请直视前方" },
  "Prendre une photo": { en: "Take a photo", zh: "拍照" },
  "Importer": { en: "Upload", zh: "上传" },
  "Facultatif": { en: "Optional", zh: "可选" },
  "Continuer": { en: "Continue", zh: "继续" },
  "Retour": { en: "Back", zh: "返回" },
  "Utiliser l’avatar par défaut": { en: "Use the default avatar", zh: "使用默认虚拟形象" },
  "CRÉEZ VOTRE IDENTITÉ": { en: "CREATE YOUR IDENTITY", zh: "创建您的身份形象" },
  "VOTRE IDENTITÉ": { en: "YOUR IDENTITY", zh: "您的身份形象" },
  "Votre silhouette de face.": { en: "Your front silhouette.", zh: "您的正面全身照。" },
  "Elle permet de respecter vos proportions, votre taille apparente et la façon dont le vêtement tombe sur vous.": { en: "It helps preserve your proportions, apparent height and the way clothing falls on your body.", zh: "它有助于保留您的身体比例、视觉身高以及服装在身上的垂坠效果。" },
  "Corps de face": { en: "Full body — front", zh: "全身正面" },
  "Le corps entier doit être visible": { en: "Your full body must be visible", zh: "全身必须清晰可见" },
  "Ajoutez votre profil.": { en: "Add your side profile.", zh: "添加您的侧面照。" },
  "Cette vue facultative améliore l’épaisseur, les courbes et les profils gauche et droit de votre avatar.": { en: "This optional view improves depth, curves and both side profiles of your avatar.", zh: "此可选视图可改善虚拟形象的厚度、曲线和左右侧面。" },
  "Corps de profil": { en: "Full body — side", zh: "全身侧面" },
  "Une vue de dos.": { en: "A back view.", zh: "添加背面照。" },
  "Cette photo facultative rend plus fidèles le dos, les cheveux et l’arrière des vêtements.": { en: "This optional photo improves the back, hair and rear view of garments.", zh: "此可选照片可提升背部、头发和服装背面的还原度。" },
  "Corps de dos": { en: "Full body — back", zh: "全身背面" },
  "Tout est prêt.": { en: "Everything is ready.", zh: "一切准备就绪。" },
  "Vérifiez vos photos. Elles serviront à créer votre avatar de référence en sous-vêtement pour tous vos futurs essayages.": { en: "Review your photos. They will create your reference avatar in underwear for all future try-ons.", zh: "请检查您的照片。系统将用它们创建穿着内衣的参考虚拟形象，用于之后的所有试穿。" },
  "Générer mon avatar": { en: "Generate my avatar", zh: "生成我的虚拟形象" },
  "Génération en cours…": { en: "Generating…", zh: "正在生成…" },
  "Votre avatar prend forme": { en: "Your avatar is taking shape", zh: "您的虚拟形象正在生成" },
  "Votre avatar se recrée": { en: "Your avatar is being recreated", zh: "正在重新创建您的虚拟形象" },
  "Retour au profil": { en: "Back to profile", zh: "返回个人资料" },
  "Ajouter un vêtement": { en: "Add a garment", zh: "添加服装" },
  "Importer une photo": { en: "Upload a photo", zh: "上传照片" },
  "Lancer l’essayage": { en: "Start try-on", zh: "开始试穿" },
  "Voir sur moi": { en: "See on me", zh: "在我身上查看" },
  "Télécharger cette vue dans ma galerie": { en: "Download this view to my gallery", zh: "将此视图下载到相册" },
  "Télécharger cette vidéo dans ma galerie": { en: "Download this video to my gallery", zh: "将此视频下载到相册" },
  "Mes avatars": { en: "My avatars", zh: "我的虚拟形象" },
  "Modifier les données de mensuration": { en: "Edit measurements", zh: "修改身体尺寸" },
  "Créer mon avatar": { en: "Create my avatar", zh: "创建我的虚拟形象" },
  "Créer un nouvel avatar": { en: "Create a new avatar", zh: "创建新的虚拟形象" },
  "Utiliser cet avatar ?": { en: "Use this avatar?", zh: "使用此虚拟形象？" },
  "Utiliser cet avatar": { en: "Use this avatar", zh: "使用此虚拟形象" },
  "Annuler": { en: "Cancel", zh: "取消" },
  "Supprimer cet avatar ?": { en: "Delete this avatar?", zh: "删除此虚拟形象？" },
  "Supprimer l’avatar": { en: "Delete avatar", zh: "删除虚拟形象" },
  "Taille": { en: "Height", zh: "身高" },
  "Chemise / haut": { en: "Shirt / top", zh: "衬衫 / 上衣" },
  "Pantalon": { en: "Trousers", zh: "裤子" },
  "Pointure": { en: "Shoe size", zh: "鞋码" },
  "Enregistrer les mensurations": { en: "Save measurements", zh: "保存身体尺寸" },
  "Ma garde-robe": { en: "My wardrobe", zh: "我的衣橱" },
  "Mes essayages": { en: "My try-ons", zh: "我的试穿" },
  "Voir et pivoter": { en: "View and rotate", zh: "查看并旋转" },
  "Supprimer": { en: "Delete", zh: "删除" },
  "Ajouter à la garde-robe": { en: "Add to wardrobe", zh: "添加到衣橱" },
  "Acheter": { en: "Buy", zh: "购买" },
  "Choisir une taille": { en: "Choose a size", zh: "选择尺码" },
  "Recto": { en: "Front", zh: "正面" },
  "Verso": { en: "Back", zh: "背面" },
  "Photo ajoutée ✓": { en: "Photo added ✓", zh: "照片已添加 ✓" },
  "Modèle par défaut": { en: "Default model", zh: "默认模型" },
};

function translateUiText(value: string, language: AppLanguage) {
  if (language === "fr") return value;
  const leading = value.match(/^\s*/)?.[0] || "";
  const trailing = value.match(/\s*$/)?.[0] || "";
  const clean = value.trim();
  const alreadyTranslated = Object.values(UI_TRANSLATIONS).some((translations) => clean.includes(translations[language]));
  if (alreadyTranslated) return value;
  const exact = UI_TRANSLATIONS[clean];
  if (exact) return `${leading}${exact[language]}${trailing}`;
  const available = clean.match(/^(\d+) disponibles$/);
  if (available) return `${leading}${available[1]} ${language === "zh" ? "个可用" : "available"}${trailing}`;
  const defaultAvatarMessage = clean.match(/^Sans photo, nous utiliserons directement l’avatar (homme|femme) par défaut\.$/);
  if (defaultAvatarMessage) {
    const gender = defaultAvatarMessage[1] === "homme"
      ? (language === "zh" ? "男性" : "male")
      : (language === "zh" ? "女性" : "female");
    return `${leading}${language === "zh" ? `如果不添加照片，我们将直接使用默认${gender}虚拟形象。` : `Without a photo, we will use the default ${gender} avatar.`}${trailing}`;
  }
  let translated = clean;
  for (const [french, translations] of Object.entries(UI_TRANSLATIONS)) {
    if (translated.includes(french)) translated = translated.split(french).join(translations[language]);
  }
  return translated === clean ? value : `${leading}${translated}${trailing}`;
}
const shopProducts: ShopProduct[] = [
  { id: "sm-shirt-ivory", name: "Chemise ivoire", type: "chemise", price: "24 900 FCFA", image: "/shop/chemise-ivoire.webp", color: "Ivoire" },
  { id: "sm-trousers-noir", name: "Pantalon essentiel", type: "pantalon", price: "29 900 FCFA", image: "/shop/pantalon-noir.webp", color: "Noir" },
  { id: "sm-set-lime", name: "Ensemble signature", type: "ensemble", price: "49 900 FCFA", image: "/shop/ensemble-signature.webp", color: "Citron" },
  { id: "sm-dress-terracotta", name: "Robe Terracotta", type: "ensemble", price: "39 900 FCFA", image: "/shop/robe-terracotta.webp", color: "Terracotta" },
  { id: "sm-bomber-cobalt", name: "Bomber Cobalt", type: "chemise", price: "44 900 FCFA", image: "/shop/bomber-cobalt.webp", color: "Bleu cobalt" },
  { id: "sm-tee-white", name: "T-shirt essentiel", type: "chemise", price: "14 900 FCFA", image: "/shop/tshirt-blanc.webp", color: "Blanc" },
  { id: "sm-jeans-indigo", name: "Jean Indigo", type: "pantalon", price: "32 900 FCFA", image: "/shop/jean-indigo.webp", color: "Indigo" },
  { id: "sm-blouse-emerald", name: "Blouse Émeraude", type: "chemise", price: "27 900 FCFA", image: "/shop/blouse-emeraude.webp", color: "Émeraude" },
  { id: "sm-suit-sand", name: "Costume Sable", type: "ensemble", price: "89 900 FCFA", image: "/shop/costume-beige.webp", color: "Sable" },
  { id: "sm-sneakers-white", name: "Sneakers Studio", type: "chaussures", price: "34 900 FCFA", image: "/shop/sneakers-blanches.webp", color: "Blanc" },
];

function defaultPhotoFor(example: string, gender: Profile["gender"]) {
  const bodyView = example.match(/body-(front|back|left|right)\.webp$/)?.[1];
  if (bodyView) {
    const genderPrefix = gender === "homme" ? "male" : "female";
    const version = gender === "homme" ? "v3" : "v2";
    return `/default-avatars/${genderPrefix}-${bodyView}-pipeline-${version}.png`;
  }
  return `/default-avatars/${gender === "homme" ? "male" : "female"}-face-premium-v3.png`;
}

function Logo() {
  return (
    <div className="brand">
      <span className="brand-mark">S</span>
      <span>SMART MIRROR</span>
    </div>
  );
}

function Arrow() {
  return <span aria-hidden="true">→</span>;
}

function MainNavigation({ active, onNavigate, language, studioNotifications = 0 }: { active: "home" | "studio" | "shop" | "profile"; onNavigate: (step: number) => void; language: AppLanguage; studioNotifications?: number }) {
  return (
    <nav className="main-navigation" aria-label="Navigation principale">
      <button className={`navigation-brand${active === "home" ? " active" : ""}`} aria-label="Accueil SMART MIRROR" aria-current={active === "home" ? "page" : undefined} onClick={() => onNavigate(STUDIO_STEP)}>
        <span className="brand-mark">S</span>
        <span className="navigation-brand-name">SMART MIRROR</span>
      </button>
      <span className="navigation-links">
        <button className={active === "studio" ? "active" : ""} aria-current={active === "studio" ? "page" : undefined} onClick={() => onNavigate(CLOSET_STEP)}>
          <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="16" height="14" rx="2" /><path d="m6 16 4-4 3 3 2-2 3 3M7 2h12a3 3 0 0 1 3 3v11" /></svg>
          <span>Studio</span>
          {studioNotifications > 0 && <b className="studio-notification-count" aria-label={`${studioNotifications} nouvelle${studioNotifications > 1 ? "s" : ""} notification${studioNotifications > 1 ? "s" : ""}`}>{studioNotifications > 9 ? "9+" : studioNotifications}</b>}
        </button>
        <button className={active === "shop" ? "active" : ""} aria-current={active === "shop" ? "page" : undefined} onClick={() => onNavigate(SHOP_STEP)}>
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h16l-1 13H5L4 8Z" /><path d="M8 9V6a4 4 0 0 1 8 0v3" /></svg>
          <span>{language === "zh" ? "商店" : language === "en" ? "Shop" : "Boutique"}</span>
        </button>
        <button className={active === "profile" ? "active" : ""} aria-current={active === "profile" ? "page" : undefined} onClick={() => onNavigate(PROFILE_STEP)}>
          <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4" /><path d="M4 21c.7-5 3.3-7 8-7s7.3 2 8 7" /></svg>
          <span>{language === "zh" ? "个人资料" : language === "en" ? "Profile" : "Profil"}</span>
        </button>
      </span>
    </nav>
  );
}

function StudioHeader({ onNavigate, language }: { onNavigate: (step: number) => void; language: AppLanguage }) {
  return (
    <header className="wardrobe-header studio-page-header">
      <button className="studio-header-control studio-header-back" type="button" aria-label="Retour à l’accueil" onClick={() => onNavigate(STUDIO_STEP)}>
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12H5" /><path d="m11 6-6 6 6 6" /></svg>
      </button>
      <strong>STUDIO</strong>
      <button className="studio-header-control studio-header-profile" type="button" aria-label="Ouvrir mon profil" onClick={() => onNavigate(PROFILE_STEP)}>
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4" /><path d="M4 21c.7-5 3.3-7 8-7s7.3 2 8 7" /></svg>
        <span>{language === "zh" ? "个人资料" : language === "en" ? "Profile" : "Profil"}</span>
      </button>
    </header>
  );
}

function BoutiqueHeader({ onNavigate, language }: { onNavigate: (step: number) => void; language: AppLanguage }) {
  return (
    <header className="wardrobe-header studio-page-header">
      <button className="studio-header-control studio-header-back" type="button" aria-label="Retour à l’accueil" onClick={() => onNavigate(STUDIO_STEP)}>
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12H5" /><path d="m11 6-6 6 6 6" /></svg>
      </button>
      <strong>{language === "zh" ? "商店" : language === "en" ? "SHOP" : "BOUTIQUE"}</strong>
      <button className="studio-header-control studio-header-profile" type="button" aria-label="Ouvrir mon profil" onClick={() => onNavigate(PROFILE_STEP)}>
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4" /><path d="M4 21c.7-5 3.3-7 8-7s7.3 2 8 7" /></svg>
        <span>{language === "zh" ? "个人资料" : language === "en" ? "Profile" : "Profil"}</span>
      </button>
    </header>
  );
}

function TryOnDetailHeader({ number, onBack, onProfile }: { number: number; onBack: () => void; onProfile: () => void }) {
  return (
    <header className="wardrobe-header studio-page-header">
      <button className="studio-header-control studio-header-back" type="button" aria-label="Retour au Studio" onClick={onBack}>
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12H5" /><path d="m11 6-6 6 6 6" /></svg>
      </button>
      <strong>ESSAI N° {number}</strong>
      <button className="studio-header-control studio-header-profile" type="button" aria-label="Ouvrir mon profil" onClick={onProfile}>
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4" /><path d="M4 21c.7-5 3.3-7 8-7s7.3 2 8 7" /></svg>
        <span>Profil</span>
      </button>
    </header>
  );
}

function ProfileHeader({ onBack, onLogout, language, onLanguage }: { onBack: () => void; onLogout: () => void; language: AppLanguage; onLanguage: (language: AppLanguage) => void }) {
  const [settingsOpen, setSettingsOpen] = useState(false);
  return (
    <header className="wardrobe-header studio-page-header">
      <button className="studio-header-control studio-header-back" type="button" aria-label="Retour à la page précédente" onClick={onBack}>
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12H5" /><path d="m11 6-6 6 6 6" /></svg>
      </button>
      <strong>{language === "zh" ? "个人资料" : language === "en" ? "PROFILE" : "PROFIL"}</strong>
      <button className="studio-header-control profile-edit-shortcut" type="button" aria-expanded={settingsOpen} onClick={() => setSettingsOpen((current) => !current)}>
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6 1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></svg>
        <span>{language === "zh" ? "设置" : language === "en" ? "Settings" : "Paramètres"}</span>
      </button>
      {settingsOpen && (
        <div className="settings-menu">
          <strong>{language === "zh" ? "语言" : language === "en" ? "Language" : "Langue"}</strong>
          <button className={language === "fr" ? "selected" : ""} type="button" onClick={() => { onLanguage("fr"); setSettingsOpen(false); }}><span>🇫🇷</span> Français <b>{language === "fr" ? "✓" : ""}</b></button>
          <button className={language === "en" ? "selected" : ""} type="button" onClick={() => { onLanguage("en"); setSettingsOpen(false); }}><span>🇬🇧</span> English <b>{language === "en" ? "✓" : ""}</b></button>
          <button className={language === "zh" ? "selected" : ""} type="button" onClick={() => { onLanguage("zh"); setSettingsOpen(false); }}><span>🇨🇳</span> 中文 <b>{language === "zh" ? "✓" : ""}</b></button>
          <div className="settings-menu-divider" />
          <button className="settings-logout" type="button" onClick={onLogout}>
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 4H5v16h5" /><path d="M14 8l4 4-4 4M18 12H9" /></svg>
            {language === "zh" ? "退出登录" : language === "en" ? "Sign out" : "Déconnexion"}
          </button>
        </div>
      )}
    </header>
  );
}

export default function Home() {
  const [language, setLanguage] = useState<AppLanguage>("fr");
  const [step, setStep] = useState(1);
  const [profile, setProfile] = useState(initialProfile);
  const [avaturnAvatar, setAvaturnAvatar] = useState<ExportResult | null>(null);
  const [avatarStudioOpen, setAvatarStudioOpen] = useState(false);
  const [photos, setPhotos] = useState<Partial<Record<PhotoKey, string>>>({});
  const uploadedIdentityPhotos = useRef<Partial<Record<PhotoKey, string>>>({});
  const identityUploadPromises = useRef<Partial<Record<PhotoKey, Promise<void>>>>({});
  const [identityUploadStatus, setIdentityUploadStatus] = useState<Partial<Record<PhotoKey, "uploading" | "uploaded" | "error">>>({});
  const [garment, setGarment] = useState("");
  const [garmentBack, setGarmentBack] = useState("");
  const [garmentType, setGarmentType] = useState<GarmentType>("auto");
  const [garmentSize, setGarmentSize] = useState("AUTO");
  const [wardrobe, setWardrobe] = useState<WardrobeItem[]>([]);
  const [tryOnOpen, setTryOnOpen] = useState(false);
  const [bodyView, setBodyView] = useState(0);
  const [bodyZoom, setBodyZoom] = useState<"full" | "top" | "bottom">("full");
  const [avatarScale, setAvatarScale] = useState(100);
  const [tryOnScale, setTryOnScale] = useState(100);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [sessionReady, setSessionReady] = useState(false);
  const [tryOnGenerating, setTryOnGenerating] = useState(false);
  const [tryOnProgress, setTryOnProgress] = useState(0);
  const [tryOnResult, setTryOnResult] = useState<TryOnResult | null>(null);
  const [tryOnVideoUrl, setTryOnVideoUrl] = useState("");
  const [tryOnVideoTaskId, setTryOnVideoTaskId] = useState("");
  const [tryOnVideoGenerating, setTryOnVideoGenerating] = useState(false);
  const [tryOnVideoProgress, setTryOnVideoProgress] = useState(0);
  const [tryOnVideoPlaying, setTryOnVideoPlaying] = useState(false);
  const [tryOnVideoLoaded, setTryOnVideoLoaded] = useState(false);
  const [tryOnVideoHasAudio, setTryOnVideoHasAudio] = useState(false);
  const [tryOnVideoBackgroundColor, setTryOnVideoBackgroundColor] = useState("");
  const [tryOnAudioTrack, setTryOnAudioTrack] = useState("");
  const [tryOnAudioMuted, setTryOnAudioMuted] = useState(false);
  const tryOnVideoRef = useRef<HTMLVideoElement | null>(null);
  const [avatarVideoUrl, setAvatarVideoUrl] = useState("");
  const [avatarVideoTaskId, setAvatarVideoTaskId] = useState("");
  const [avatarVideoGenerating, setAvatarVideoGenerating] = useState(false);
  const [avatarVideoProgress, setAvatarVideoProgress] = useState(0);
  const [avatarVideoPlaying, setAvatarVideoPlaying] = useState(false);
  const [avatarVideoLoaded, setAvatarVideoLoaded] = useState(false);
  const [avatarVideoHasAudio, setAvatarVideoHasAudio] = useState(false);
  const [avatarVideoBackgroundColor, setAvatarVideoBackgroundColor] = useState("");
  const [avatarVideoMuted, setAvatarVideoMuted] = useState(false);
  const [defaultAvatarVideos, setDefaultAvatarVideos] = useState<Partial<Record<"femme" | "homme", AvatarVideoRecord>>>(DEFAULT_AVATAR_PRESENTATION_VIDEOS);
  const avatarVideoRef = useRef<HTMLVideoElement | null>(null);
  const avatarAudioRef = useRef<HTMLAudioElement | null>(null);
  const [completionNotice, setCompletionNotice] = useState("");
  const [loadedImageUrls, setLoadedImageUrls] = useState<Record<string, true>>({});
  const [lookDownloading, setLookDownloading] = useState(false);
  const [downloadCooldowns, setDownloadCooldowns] = useState<Partial<Record<DownloadViewKey, number>>>({});
  const [downloadErrors, setDownloadErrors] = useState<Partial<Record<DownloadViewKey, string>>>({});
  const [viewingSavedLook, setViewingSavedLook] = useState(false);
  const [selectedTryOnNumber, setSelectedTryOnNumber] = useState(1);
  const [baseAvatarImages, setBaseAvatarImages] = useState<Partial<Record<PhotoKey, string>>>({});
  const [avatarBackgroundColors, setAvatarBackgroundColors] = useState<AvatarBackgroundColors>({});
  const [avatarBackgroundGradients, setAvatarBackgroundGradients] = useState<AvatarBackgroundGradients>({});
  const [usesDefaultAvatar, setUsesDefaultAvatar] = useState(false);
  const [avatarLibrary, setAvatarLibrary] = useState<AvatarLibraryItem[]>([]);
  const [activeAvatarId, setActiveAvatarId] = useState("");
  const displayingDefaultAvatar = usesDefaultAvatar
    || !baseAvatarImages.bodyFront
    || baseAvatarImages.bodyFront.includes("/default-avatars/");
  const [avatarChoice, setAvatarChoice] = useState<AvatarLibraryItem | "default-femme" | "default-homme" | null>(null);
  const [avatarToDelete, setAvatarToDelete] = useState<AvatarLibraryItem | null>(null);
  const [measurementsOpen, setMeasurementsOpen] = useState(false);
  const [desktopSettingsOpen, setDesktopSettingsOpen] = useState(false);
  const [publicSettingsOpen, setPublicSettingsOpen] = useState(false);
  const [desktopRailView, setDesktopRailView] = useState<"studio" | "shop">("studio");
  const [identityCaptureStarted, setIdentityCaptureStarted] = useState(false);
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [authIntent, setAuthIntent] = useState<"create" | "default" | null>(null);
  const [authMethod, setAuthMethod] = useState<"choices" | "email" | "code">("choices");
  const [authEmail, setAuthEmail] = useState("");
  const [authCode, setAuthCode] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [authMessage, setAuthMessage] = useState("");
  const [demoEmailAuthenticated, setDemoEmailAuthenticated] = useState(false);
  const [authCountdown, setAuthCountdown] = useState(10);
  const [measurementDraft, setMeasurementDraft] = useState<AvatarMeasurements>({
    height: initialProfile.height,
    topSize: initialProfile.topSize,
    pantsSize: initialProfile.pantsSize,
    shoeSize: initialProfile.shoeSize,
  });
  const [defaultMeasurements, setDefaultMeasurements] = useState<Record<"femme" | "homme", AvatarMeasurements>>({
    femme: { height: 172, topSize: "M", pantsSize: "42", shoeSize: "41" },
    homme: { height: 178, topSize: "M", pantsSize: "42", shoeSize: "43" },
  });
  const [recreateBackup, setRecreateBackup] = useState<{
    photos: Partial<Record<PhotoKey, string>>;
    images: Partial<Record<PhotoKey, string>>;
  } | null>(null);
  const [youcamReady, setYoucamReady] = useState(false);
  const [avatarGenerating, setAvatarGenerating] = useState(false);
  const [avatarProgress, setAvatarProgress] = useState(0);
  const [avatarGenerationMode, setAvatarGenerationMode] = useState<"create" | "recreate">("create");
  const [avatarPendingViews, setAvatarPendingViews] = useState<PhotoKey[]>([]);
  const [pendingShopProduct, setPendingShopProduct] = useState<ShopProduct | null>(null);
  const [shopSelectedSizes, setShopSelectedSizes] = useState<Record<string, string>>({});
  const [profileReturnStep, setProfileReturnStep] = useState(STUDIO_STEP);
  const [profileSaveStatus, setProfileSaveStatus] = useState("");
  const baseAvatarAttempted = useRef(false);
  const avatarRequestInFlight = useRef(false);
  const tryOnRequestInFlight = useRef(false);
  const shopAutoTryOnStarted = useRef(false);
  const garmentInput = useRef<HTMLInputElement>(null);
  const garmentCameraInput = useRef<HTMLInputElement>(null);
  const garmentBackInput = useRef<HTMLInputElement>(null);
  const garmentBackCameraInput = useRef<HTMLInputElement>(null);
  const photoAdvanceTimer = useRef<number | null>(null);

  const progress = useMemo(() => Math.min(100, ((step - 1) / 4) * 100), [step]);

  useEffect(() => {
    return onAuthStateChanged(smartMirrorAuth, async (user) => {
      if (user) {
        const restoreMarker = `smartmirror-cloud-restored:${user.uid}`;
        const owner = localStorage.getItem("smartmirror-local-owner");
        if (owner && owner !== user.uid) clearLocalAccountState();
        if (sessionStorage.getItem(restoreMarker) !== "1") {
          try {
            const restored = await restoreAccountState(user);
            sessionStorage.setItem(restoreMarker, "1");
            if (restored) {
              window.location.reload();
              return;
            }
          } catch (restoreError) {
            console.error("La restauration du compte a échoué.", restoreError);
          }
        }
        localStorage.setItem("smartmirror-local-owner", user.uid);
      }
      setAuthUser(user);
      setAuthReady(true);
    });
  }, []);

  useEffect(() => {
    if (!authUser || !authReady || !sessionReady || sessionStorage.getItem("smartmirror-push-registered") === authUser.uid) return;
    if (typeof Notification !== "undefined" && Notification.permission === "granted") {
      void enablePushNotifications(authUser).catch((pushError) => console.error("Notifications Firebase indisponibles.", pushError));
    }
  }, [authUser, authReady, sessionReady]);

  useEffect(() => {
    if (!Object.values(downloadCooldowns).some((seconds) => Number(seconds) > 0)) return;
    const timer = window.setInterval(() => {
      setDownloadCooldowns((current) => {
        const next = { ...current };
        const completedViews: DownloadViewKey[] = [];
        Object.entries(next).forEach(([key, seconds]) => {
          next[key as DownloadViewKey] = Math.max(0, Number(seconds) - 1);
          if (next[key as DownloadViewKey] === 0) completedViews.push(key as DownloadViewKey);
        });
        if (completedViews.length) {
          setDownloadErrors((errors) => {
            const updated = { ...errors };
            completedViews.forEach((key) => delete updated[key]);
            return updated;
          });
        }
        return next;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [Object.values(downloadCooldowns).some((seconds) => Number(seconds) > 0)]);

  useEffect(() => {
    if (!sessionReady) return;
    setDesktopRailView(wardrobe.length > 0 ? "studio" : "shop");
  }, [sessionReady, wardrobe.length]);

  function navigateMain(nextStep: number) {
    setAvatarVideoPlaying(false);
    setAvatarVideoLoaded(false);
    if (nextStep === PROFILE_STEP && step !== PROFILE_STEP) setProfileReturnStep(step);
    if (nextStep === STUDIO_STEP) {
      setTryOnVideoPlaying(false);
      setTryOnVideoLoaded(false);
      setViewingSavedLook(false);
      setTryOnResult(null);
      setBodyView(0);
    }
    setStep(nextStep);
  }
  const currentPhotoStep = onboardingPhotoSteps.find((item) => item.step === step);
  const currentPhotoGuide = currentPhotoStep
    ? photoGuides.find((item) => item.key === currentPhotoStep.key)
    : undefined;
  const studioNotificationCount = wardrobe.reduce((total, item) => total + (item.unreadTryOn ? 1 : 0) + (item.unreadVideo ? 1 : 0), 0);

  useEffect(() => {
    try {
      const savedLanguage = localStorage.getItem("smartmirror-language");
      if (savedLanguage === "en" || savedLanguage === "fr" || savedLanguage === "zh") {
        setLanguage(savedLanguage);
        document.documentElement.lang = savedLanguage;
      }
      let restoredUsesDefaultAvatar = false;
      let restoredIdentityPhotos: Partial<Record<PhotoKey, string>> = {};
      let restoredGender: Profile["gender"] = "femme";
      let restoredProfileData: Record<string, unknown> = {};
      const stored = localStorage.getItem("smartmirror-profile");
      if (stored) {
        const saved = JSON.parse(stored);
        restoredProfileData = saved;
        restoredGender = saved.gender || "femme";
        restoredUsesDefaultAvatar = saved.usesDefaultAvatar === true;
        setUsesDefaultAvatar(restoredUsesDefaultAvatar);
        setProfile((current) => ({
          ...current,
          gender: saved.gender || current.gender,
          name: saved.name || current.name,
          email: saved.email || current.email,
          password: saved.password || current.password,
          height: Number(saved.height) || current.height,
          topSize: saved.topSize || current.topSize,
          pantsSize: saved.pantsSize || current.pantsSize,
          shoeSize: saved.shoeSize || current.shoeSize,
        }));
        const hasNewPhotoFlow = localStorage.getItem("smartmirror-client-flow") === "photo-flow-v2";
        if (saved.onboardingVersion === 3 && hasNewPhotoFlow) {
          const restoredPhotos = (saved.identityPhotoData && typeof saved.identityPhotoData === "object")
            ? saved.identityPhotoData as Partial<Record<PhotoKey, string>>
            : {} as Partial<Record<PhotoKey, string>>;
          if (saved.profilePhoto && !restoredPhotos.faceFront) restoredPhotos.faceFront = saved.profilePhoto;
          restoredIdentityPhotos = restoredPhotos;
          setPhotos(restoredPhotos);
          setStep(STUDIO_STEP);
        }
      }
      const storedWardrobe = localStorage.getItem("smartmirror-wardrobe");
      if (storedWardrobe) {
        const restoredWardrobe = (JSON.parse(storedWardrobe) as WardrobeItem[]).map((item, index) => ({
          ...item,
          videoTaskId: item.videoTaskId || LEGACY_KLING_TASK_BY_TRYON_NUMBER[index + 1],
          videoBackgroundColor: item.videoBackgroundColor || LEGACY_KLING_BACKGROUND_BY_TRYON_NUMBER[index + 1],
        }));
        setWardrobe(restoredWardrobe);
        restoredWardrobe.forEach((item) => warmAvatarImageCache(item.images || { bodyFront: item.image }));
      }
      const storedAvatarLibrary = localStorage.getItem("smartmirror-avatar-library");
      let restoredAvatarLibrary: AvatarLibraryItem[] = storedAvatarLibrary ? JSON.parse(storedAvatarLibrary) : [];
      restoredAvatarLibrary = restoredAvatarLibrary.map((avatar) => ({
        ...avatar,
        measurements: avatar.measurements || {
          height: Number(restoredProfileData.height) || initialProfile.height,
          topSize: String(restoredProfileData.topSize || initialProfile.topSize),
          pantsSize: String(restoredProfileData.pantsSize || initialProfile.pantsSize),
          shoeSize: String(restoredProfileData.shoeSize || initialProfile.shoeSize),
        },
      }));
      const storedDefaultMeasurements = localStorage.getItem("smartmirror-default-avatar-measurements");
      if (storedDefaultMeasurements) setDefaultMeasurements(JSON.parse(storedDefaultMeasurements));
      setActiveAvatarId(localStorage.getItem("smartmirror-active-avatar-id") || "");
      const storedAvatar = localStorage.getItem("smartmirror-base-avatar-v2")
        || localStorage.getItem("smartmirror-base-avatar");
      if (restoredUsesDefaultAvatar) {
        localStorage.removeItem("smartmirror-base-avatar-v2");
        localStorage.removeItem("smartmirror-base-avatar");
        setBaseAvatarImages({});
      } else if (storedAvatar) {
        const restoredAvatar = JSON.parse(storedAvatar) as Partial<Record<PhotoKey, string>>;
        setBaseAvatarImages(restoredAvatar);
        const storedBackgroundColors = localStorage.getItem("smartmirror-avatar-background-colors");
        if (storedBackgroundColors) setAvatarBackgroundColors(JSON.parse(storedBackgroundColors));
        const storedBackgroundGradients = localStorage.getItem("smartmirror-avatar-background-gradients");
        if (storedBackgroundGradients) setAvatarBackgroundGradients(JSON.parse(storedBackgroundGradients));
        warmAvatarImageCache(restoredAvatar);
        localStorage.setItem("smartmirror-base-avatar-v2", JSON.stringify(restoredAvatar));
        const isPersonalAvatar = Boolean(restoredAvatar.bodyFront)
          && !restoredAvatar.bodyFront?.includes("/default-avatars/");
        const alreadyListed = restoredAvatarLibrary.some((avatar) => avatar.images.bodyFront === restoredAvatar.bodyFront);
        if (isPersonalAvatar && !alreadyListed) {
          const migratedAvatar: AvatarLibraryItem = {
            id: `avatar-imported-${Date.now()}`,
            label: `Avatar ${restoredAvatarLibrary.length + 1}`,
            gender: restoredGender,
            images: restoredAvatar,
            identityPhotos: restoredIdentityPhotos,
            measurements: {
              height: Number(restoredProfileData.height) || initialProfile.height,
              topSize: String(restoredProfileData.topSize || initialProfile.topSize),
              pantsSize: String(restoredProfileData.pantsSize || initialProfile.pantsSize),
              shoeSize: String(restoredProfileData.shoeSize || initialProfile.shoeSize),
            },
            createdAt: new Date().toISOString(),
          };
          restoredAvatarLibrary = [...restoredAvatarLibrary, migratedAvatar];
          localStorage.setItem("smartmirror-avatar-library", JSON.stringify(restoredAvatarLibrary));
          localStorage.setItem("smartmirror-active-avatar-id", migratedAvatar.id);
        }
        setStep(STUDIO_STEP);
      }
      setAvatarLibrary(restoredAvatarLibrary);
      const storedDefaultAvatarVideos = localStorage.getItem("smartmirror-default-avatar-videos");
      if (storedDefaultAvatarVideos) {
        const stored = JSON.parse(storedDefaultAvatarVideos) as Partial<Record<"femme" | "homme", AvatarVideoRecord>>;
        const restored = (Object.keys(DEFAULT_AVATAR_PRESENTATION_VIDEOS) as Array<"femme" | "homme">).reduce((videos, gender) => {
          const permanent = DEFAULT_AVATAR_PRESENTATION_VIDEOS[gender];
          const saved = stored[gender];
          videos[gender] = saved?.taskId === permanent.taskId ? { ...permanent, ...saved } : permanent;
          return videos;
        }, {} as Record<"femme" | "homme", AvatarVideoRecord>);
        setDefaultAvatarVideos(restored);
        localStorage.setItem("smartmirror-default-avatar-videos", JSON.stringify(restored));
      } else {
        localStorage.setItem("smartmirror-default-avatar-videos", JSON.stringify(DEFAULT_AVATAR_PRESENTATION_VIDEOS));
      }
      setYoucamReady(localStorage.getItem("smartmirror-youcam-status") === "success");
      const pending = localStorage.getItem("smartmirror-pending-product");
      if (pending) setPendingShopProduct(JSON.parse(pending));
      setDemoEmailAuthenticated(localStorage.getItem("smartmirror-demo-email-auth") === "1");
    } catch {
      localStorage.removeItem("smartmirror-profile");
    } finally {
      const params = new URLSearchParams(window.location.search);
      if (params.get("studio") === "1") setStep(STUDIO_STEP);
      else if (params.get("market") === "1" || params.has("product")) setStep(SHOP_STEP);
      setSessionReady(true);
    }
  }, []);

  function completeAuthIntent(intent: "create" | "default" | null = authIntent) {
    setAuthOpen(false);
    setAuthIntent(null);
    setAuthMethod("choices");
    setAuthMessage("");
    if (intent === "create") {
      setIdentityCaptureStarted(true);
      setStep(1);
    }
    if (intent === "default") next();
  }

  function requireAuthentication(intent: "create" | "default") {
    if (smartMirrorAuth.currentUser || authUser || demoEmailAuthenticated) {
      completeAuthIntent(intent);
      return;
    }
    setAuthIntent(intent);
    setAuthMethod("choices");
    setAuthMessage(authReady ? "" : "Vérification de votre connexion…");
    setAuthBusy(!authReady);
    setAuthOpen(true);
  }

  useEffect(() => {
    if (!authReady) return;
    setAuthBusy(false);
    if (authIntent && (authUser || demoEmailAuthenticated)) completeAuthIntent(authIntent);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authReady, authUser, demoEmailAuthenticated, authIntent]);

  async function disconnectAccount() {
    const user = smartMirrorAuth.currentUser || authUser;
    if (user) {
      try {
        await saveAccountState(user);
      } catch (saveError) {
        console.error("La sauvegarde du compte a échoué.", saveError);
        setError("La déconnexion a été interrompue car vos données n’ont pas pu être sauvegardées. Réessayez dans quelques instants.");
        return false;
      }
    }
    try {
      if (user) await disablePushNotifications(user);
      await signOut(smartMirrorAuth);
    } finally {
      clearLocalAccountState();
      await clearSmartMirrorCaches();
      setDemoEmailAuthenticated(false);
      setAuthUser(null);
      window.location.replace(`/?release=${Date.now()}&fresh=1`);
    }
    return true;
  }

  const accountConnected = Boolean(smartMirrorAuth.currentUser || authUser || demoEmailAuthenticated);

  useEffect(() => {
    const gender = profile.gender === "homme" ? "homme" : "femme";
    const personalAvatar = !displayingDefaultAvatar
      ? avatarLibrary.find((avatar) => avatar.id === activeAvatarId)
        || avatarLibrary.find((avatar) => avatar.images.bodyFront === baseAvatarImages.bodyFront)
      : undefined;
    const record: AvatarVideoRecord | undefined = personalAvatar ? {
      videoUrl: personalAvatar.presentationVideoUrl,
      taskId: personalAvatar.presentationVideoTaskId,
      backgroundColor: personalAvatar.presentationVideoBackgroundColor,
      hasAudio: personalAvatar.presentationVideoHasAudio,
    } : defaultAvatarVideos[gender];
    setAvatarVideoUrl(record?.videoUrl || "");
    setAvatarVideoTaskId(record?.taskId || "");
    setAvatarVideoBackgroundColor(record?.backgroundColor || "");
    setAvatarVideoHasAudio(Boolean(record?.hasAudio));
    setAvatarVideoProgress(record?.videoUrl ? 100 : 0);
    setAvatarVideoPlaying(false);
    setAvatarVideoLoaded(false);
  }, [activeAvatarId, avatarLibrary, baseAvatarImages.bodyFront, defaultAvatarVideos, displayingDefaultAvatar, profile.gender]);

  useEffect(() => {
    if (!displayingDefaultAvatar) return;
    const gender = profile.gender === "homme" ? "homme" : "femme";
    const record = defaultAvatarVideos[gender];
    if (!record?.taskId) return;
    const target: AvatarVideoTarget = { usesDefaultAvatar: true, gender, avatarId: activeAvatarId };
    let cancelled = false;
    void (async () => {
      try {
        const response = await fetch(`${KLING_VIDEO_STATUS_API_URL}?taskId=${encodeURIComponent(record.taskId || "")}`, { cache: "no-store" });
        const status = await response.json() as { videoUrl?: string; backgroundColor?: string; audioIncluded?: boolean };
        if (!response.ok || !status.videoUrl || cancelled) return;
        const refreshed: AvatarVideoRecord = {
          videoUrl: status.videoUrl,
          taskId: record.taskId,
          backgroundColor: status.backgroundColor || record.backgroundColor,
          hasAudio: Boolean(status.audioIncluded),
        };
        setAvatarVideoUrl(status.videoUrl);
        setAvatarVideoTaskId(record.taskId || "");
        setAvatarVideoBackgroundColor(refreshed.backgroundColor || "");
        setAvatarVideoHasAudio(Boolean(refreshed.hasAudio));
        setAvatarVideoProgress(100);
        warmVideoCache(status.videoUrl);
        persistAvatarVideo(refreshed, target);
      } catch {
        // The permanent task remains saved and will be refreshed on the next visit.
      }
    })();
    return () => { cancelled = true; };
    // Refresh only when the selected default avatar changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [displayingDefaultAvatar, profile.gender]);

  useEffect(() => {
    if (!sessionReady || !authReady || !accountConnected) return;
    if (step === 1 && !identityCaptureStarted) setStep(STUDIO_STEP);
  }, [sessionReady, authReady, accountConnected, step, identityCaptureStarted]);

  useEffect(() => {
    if (!sessionReady || !authReady || accountConnected || step !== 1) return;
    setIdentityCaptureStarted(false);
  }, [sessionReady, authReady, accountConnected, step]);

  async function continueWithGoogle() {
    setAuthBusy(true);
    setAuthMessage("");
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: "select_account" });
      const result = await signInWithPopup(smartMirrorAuth, provider);
      const nextProfile = {
        ...profile,
        name: result.user.displayName || profile.name,
        email: result.user.email || profile.email,
      };
      setProfile(nextProfile);
      localStorage.setItem("smartmirror-profile", JSON.stringify(nextProfile));
      completeAuthIntent();
    } catch (authError) {
      const code = typeof authError === "object" && authError && "code" in authError ? String(authError.code) : "";
      setAuthMessage(code.includes("popup-closed") ? "Connexion annulée." : "La connexion Google n’a pas abouti. Réessayez.");
    } finally {
      setAuthBusy(false);
    }
  }

  async function requestEmailCode() {
    const email = authEmail.trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setAuthMessage("Saisissez une adresse e-mail valide.");
      return;
    }
    // Mode démo hackathon : aucun e-mail réel n'est envoyé pour le moment.
    setAuthCode("");
    setAuthCountdown(10);
    setAuthMethod("code");
    setAuthMessage("Mode démo : votre compte sera créé automatiquement dans 10 secondes.");
  }

  function completeDemoEmailAuthentication() {
    const email = authEmail.trim().toLowerCase();
    const nextProfile = { ...profile, email };
    setProfile(nextProfile);
    setDemoEmailAuthenticated(true);
    localStorage.setItem("smartmirror-profile", JSON.stringify(nextProfile));
    localStorage.setItem("smartmirror-demo-email-auth", "1");
    completeAuthIntent();
  }

  useEffect(() => {
    if (!authOpen || authMethod !== "code") return;
    if (authCountdown <= 0) {
      completeDemoEmailAuthentication();
      return;
    }
    setAuthMessage(`Mode démo : création automatique du compte dans ${authCountdown} seconde${authCountdown > 1 ? "s" : ""}.`);
    const timer = window.setTimeout(() => setAuthCountdown((value) => value - 1), 1000);
    return () => window.clearTimeout(timer);
    // Ce compte à rebours remplace temporairement le véritable service OTP.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authOpen, authMethod, authCountdown]);

  async function verifyEmailCode() {
    // En mode démo, n'importe quel code à six chiffres valide immédiatement le compte.
    if (/^\d{6}$/.test(authCode)) {
      completeDemoEmailAuthentication();
      return;
    }
    if (!/^\d{6}$/.test(authCode)) {
      setAuthMessage("Entrez le code à 6 chiffres reçu par e-mail.");
      return;
    }
    setAuthBusy(true);
    try {
      const response = await fetch("/api/auth/verify-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: authEmail.trim().toLowerCase(), code: authCode }),
      });
      if (!response.ok) throw new Error("invalid-code");
      const payload = await response.json() as { customToken?: string };
      if (!payload.customToken) throw new Error("missing-token");
      const { signInWithCustomToken } = await import("firebase/auth");
      const result = await signInWithCustomToken(smartMirrorAuth, payload.customToken);
      const nextProfile = { ...profile, email: result.user.email || authEmail.trim().toLowerCase() };
      setProfile(nextProfile);
      localStorage.setItem("smartmirror-profile", JSON.stringify(nextProfile));
      completeAuthIntent();
    } catch {
      setAuthMessage("Code incorrect ou expiré. Demandez un nouveau code.");
    } finally {
      setAuthBusy(false);
    }
  }

  useEffect(() => {
    const root = document.querySelector("main");
    if (!root) return;
    const translateTree = () => {
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let node = walker.nextNode() as Text | null;
      while (node) {
        const current = node.textContent || "";
        const translated = translateUiText(current, language);
        if (node.textContent !== translated) node.textContent = translated;
        node = walker.nextNode() as Text | null;
      }
    };
    translateTree();
    const observer = new MutationObserver(() => translateTree());
    observer.observe(root, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, [language, step, tryOnOpen, measurementsOpen, avatarChoice, avatarToDelete]);

  useEffect(() => {
    if (!sessionReady) return;
    localStorage.setItem("smartmirror-wardrobe", JSON.stringify(wardrobe));
  }, [wardrobe, sessionReady]);

  useEffect(() => {
    if (step !== STUDIO_STEP || !pendingShopProduct || !garment || tryOnGenerating || shopAutoTryOnStarted.current) return;
    shopAutoTryOnStarted.current = true;
    setTryOnResult(null);
    setTryOnOpen(false);
    setTryOnProgress(1);
    window.requestAnimationFrame(() => {
      window.setTimeout(() => void generateTryOn(), 120);
    });
  }, [step, pendingShopProduct, garment, tryOnGenerating]);

  function updateProfile<K extends keyof Profile>(key: K, value: Profile[K]) {
    setProfile((current) => ({ ...current, [key]: value }));
    setError("");
    setProfileSaveStatus("");
  }

  function saveProfileChanges() {
    const cleanName = profile.name.trim();
    if (!cleanName) {
      setProfileSaveStatus("");
      setError("Ajoutez votre nom avant d’enregistrer.");
      return;
    }
    if (!Number.isFinite(profile.height)) {
      setProfileSaveStatus("");
      setError("Sélectionnez une taille valide.");
      return;
    }
    try {
      localStorage.setItem("smartmirror-profile", JSON.stringify({
        ...profile,
        name: cleanName,
        onboardingVersion: 3,
        profilePhoto: photos.faceFront || "",
        identityPhotos: Object.keys(photos),
        identityPhotoData: photos,
        usesDefaultAvatar,
      }));
      setProfile((current) => ({ ...current, name: cleanName }));
      setError("");
      setProfileSaveStatus("Modifications enregistrées ✓");
    } catch {
      setProfileSaveStatus("");
      setError("L’enregistrement a échoué. Essayez une photo moins lourde.");
    }
  }

  function defaultSize(type: GarmentType) {
    if (type === "pantalon") return profile.pantsSize;
    if (type === "chaussures") return profile.shoeSize;
    return profile.topSize;
  }

  function availableShopSizes(type: GarmentType) {
    if (type === "chaussures") return Array.from({ length: 14 }, (_, index) => String(35 + index));
    if (type === "pantalon") return Array.from({ length: 10 }, (_, index) => String(34 + index * 2));
    return ["XS", "S", "M", "L", "XL", "XXL", "3XL+"];
  }

  function identityImagesForTryOn(): Partial<Record<PhotoKey, string>> {
    const genderPrefix = profile.gender === "homme" ? "male" : "female";
    const defaultAvatarVersion = profile.gender === "homme" ? "v3" : "v2";
    return {
      faceFront: `/default-avatars/${genderPrefix}-face-premium-v3.png`,
      bodyFront: `/default-avatars/${genderPrefix}-front-pipeline-${defaultAvatarVersion}.png`,
      bodyRight: `/default-avatars/${genderPrefix}-right-pipeline-${defaultAvatarVersion}.png`,
      bodyBack: `/default-avatars/${genderPrefix}-back-pipeline-${defaultAvatarVersion}.png`,
      ...photos,
      ...baseAvatarImages,
    };
  }

  function selectGarmentType(type: GarmentType) {
    setGarmentType(type);
    setGarmentSize(defaultSize(type));
  }

  function readImage(file: File, callback: (value: string) => void) {
    if (file.size > 8 * 1024 * 1024) {
      setError("Choisissez une image de moins de 8 Mo.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const source = String(reader.result);
      const image = new Image();
      image.onload = () => {
        const scale = Math.min(1, 1280 / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        canvas.getContext("2d")?.drawImage(image, 0, 0, canvas.width, canvas.height);
        callback(canvas.toDataURL("image/jpeg", 0.82));
      };
      image.onerror = () => callback(source);
      image.src = source;
    };
    reader.readAsDataURL(file);
  }

  function uploadIdentityPhoto(key: PhotoKey, image: string) {
    setIdentityUploadStatus((current) => ({ ...current, [key]: "uploading" }));
    const uploadPromise = fetch(IDENTITY_UPLOAD_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ label: key, image }),
    })
      .then(async (response) => {
        const result = await response.json();
        if (!response.ok || !result.url) throw new Error(result.error || "Envoi impossible.");
        uploadedIdentityPhotos.current = { ...uploadedIdentityPhotos.current, [key]: result.url };
        setIdentityUploadStatus((current) => ({ ...current, [key]: "uploaded" }));
      })
      .catch(() => {
        delete uploadedIdentityPhotos.current[key];
        setIdentityUploadStatus((current) => ({ ...current, [key]: "error" }));
      })
      .finally(() => {
        delete identityUploadPromises.current[key];
      });
    identityUploadPromises.current[key] = uploadPromise;
  }

  function onIdentityPhoto(key: PhotoKey, event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    event.target.value = "";
    readImage(file, (value) => {
      setPhotos((current) => ({ ...current, [key]: value }));
      uploadIdentityPhoto(key, value);
      setError("");
      if (photoAdvanceTimer.current) window.clearTimeout(photoAdvanceTimer.current);
      const photoStep = onboardingPhotoSteps.find((item) => item.key === key)?.step;
      if (photoStep) {
        photoAdvanceTimer.current = window.setTimeout(() => {
          setStep((current) => current === photoStep ? Math.min(5, current + 1) : current);
          photoAdvanceTimer.current = null;
        }, 2000);
      }
    });
  }

  function onGarment(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    readImage(file, (value) => {
      setGarment(value);
      setGarmentSize("AUTO");
      setTryOnResult(null);
      setError("");
    });
  }

  function onGarmentBack(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    readImage(file, (value) => {
      setGarmentBack(value);
      setError("");
    });
  }

  async function selectShopProduct(product: ShopProduct) {
    setError("");
    shopAutoTryOnStarted.current = false;
    setPendingShopProduct(product);
    localStorage.setItem("smartmirror-pending-product", JSON.stringify(product));
    try {
      const response = await fetch(product.image);
      if (!response.ok) throw new Error("product-image");
      const blob = await response.blob();
      readImage(new File([blob], `${product.id}.svg`, { type: blob.type || "image/svg+xml" }), (value) => {
        setGarment(value);
        setGarmentBack("");
        setGarmentType(product.type);
        setGarmentSize(shopSelectedSizes[product.id] || defaultSize(product.type));
        setTryOnResult(null);
        const saved = localStorage.getItem("smartmirror-profile");
        const hasAvatar = Boolean(localStorage.getItem("smartmirror-base-avatar-v2") || localStorage.getItem("smartmirror-base-avatar"));
        let hasAccount = false;
        try { hasAccount = Boolean(saved && JSON.parse(saved).onboardingVersion === 3); } catch {}
        if (hasAccount || hasAvatar) {
          setStep(STUDIO_STEP);
          setTryOnOpen(false);
        } else {
          uploadedIdentityPhotos.current = {};
          identityUploadPromises.current = {};
          setIdentityUploadStatus({});
          setPhotos({});
          setIdentityCaptureStarted(false);
          setStep(1);
        }
      });
    } catch {
      setError("La boutique n’a pas pu transmettre la photo du vêtement. Réessayez.");
    }
  }

  function next() {
    if (step === 1) {
      if (!photos.faceFront) {
        const defaultPhotos = Object.fromEntries(
          photoGuides.map((photo) => [photo.key, defaultPhotoFor(photo.example, profile.gender)]),
        ) as Partial<Record<PhotoKey, string>>;
        setPhotos(defaultPhotos);
        setUsesDefaultAvatar(true);
        localStorage.setItem("smartmirror-profile", JSON.stringify({
          ...profile,
          onboardingVersion: 3,
          profilePhoto: "",
          identityPhotos: [],
          usesDefaultAvatar: true,
        }));
        localStorage.setItem("smartmirror-client-flow", "photo-flow-v2");
        setError("");
        setStep(STUDIO_STEP);
        return;
      }
    }
    setError("");
    setStep((current) => Math.min(5, current + 1));
  }

  function saveGeneratedTryOn(result: TryOnResult) {
    if (!garment || !result.imageUrl) return;
    localStorage.removeItem("smartmirror-pending-product");
    setPendingShopProduct(null);
    setWardrobe((current) => {
      const alreadySaved = current.some((item) =>
        (result.manifestHash && item.manifestHash === result.manifestHash) || item.image === result.imageUrl
      );
      if (alreadySaved) return current;
      return [
        ...current,
        {
          id: Date.now(),
          name: garmentType === "auto" || garmentType === "ensemble" ? "Mon look SMART MIRROR" : garmentType === "chemise" ? "Look avec mon haut" : garmentType === "pantalon" ? "Look avec mon pantalon" : "Look avec mes chaussures",
          type: garmentType,
          size: garmentSize,
          image: result.imageUrl,
          images: result.images,
          garmentFront: garment,
          garmentBack,
          manifestHash: result.manifestHash,
          backgroundColors: result.backgroundColors,
          backgroundGradients: result.backgroundGradients,
          unreadTryOn: true,
        },
      ];
    });
  }

  function deleteSavedTryOn(item: WardrobeItem, tryOnNumber: number) {
    const confirmed = window.confirm(
      `Supprimer définitivement l’essai n° ${tryOnNumber} ?`,
    );
    if (!confirmed) return;
    setWardrobe((current) => current.filter((savedItem) => savedItem.id !== item.id));
  }

  function downloadSavedLook() {
    if (!tryOnResult || lookDownloading) return;
    const labels: Record<DownloadViewKey, string> = {
      front: "face",
      right: "profil-droit",
      back: "dos",
      left: "profil-gauche",
    };
    const currentKey = bodyRotation[bodyView]?.key || "bodyFront";
    const downloadKey = downloadViewKeys[bodyView] || "front";
    if (Number(downloadCooldowns[downloadKey]) > 0) return;
    const currentImage = tryOnResult.images?.[currentKey] || tryOnResult.imageUrl;
    if (!currentImage) {
      setDownloadErrors((current) => ({ ...current, [downloadKey]: "Cette vue n’est pas disponible au téléchargement." }));
      setDownloadCooldowns((current) => ({ ...current, [downloadKey]: 10 }));
      return;
    }
    setLookDownloading(true);
    setDownloadErrors((current) => ({ ...current, [downloadKey]: "" }));
    try {
      const viewName = labels[downloadKey];
      const downloadUrl = new URL("https://us-central1-smartmirror-ci.cloudfunctions.net/download_image");
      downloadUrl.searchParams.set("url", currentImage);
      downloadUrl.searchParams.set("name", `smart-mirror-essai-${selectedTryOnNumber}-${viewName}.jpg`);
      downloadUrl.searchParams.set("trim", "1");
      downloadUrl.searchParams.set("compose", "1");
      const viewGradient = tryOnResult.backgroundGradients?.[currentKey];
      const viewBackground = tryOnResult.backgroundColors?.[currentKey] || "#e8e5dc";
      downloadUrl.searchParams.set("bgTop", viewGradient?.top || viewBackground);
      downloadUrl.searchParams.set("bgBottom", viewGradient?.bottom || viewBackground);
      downloadUrl.searchParams.set("scale", String(tryOnScale));
      const mirrorDownloadedProfile = downloadKey === "left";
      if (mirrorDownloadedProfile) downloadUrl.searchParams.set("mirror", "1");
      const link = document.createElement("a");
      link.href = downloadUrl.toString();
      link.style.display = "none";
      document.body.appendChild(link);
      link.click();
      link.remove();
      setDownloadCooldowns((current) => ({ ...current, [downloadKey]: 10 }));
    } catch {
      setDownloadErrors((current) => ({ ...current, [downloadKey]: "Le téléchargement de cette vue n’a pas pu démarrer." }));
      setDownloadCooldowns((current) => ({ ...current, [downloadKey]: 10 }));
    } finally {
      setLookDownloading(false);
    }
  }

  function downloadSavedVideo() {
    if (!tryOnVideoUrl || lookDownloading) return;
    setLookDownloading(true);
    setDownloadErrors((current) => ({ ...current, front: "" }));
    try {
      const downloadUrl = new URL("https://us-central1-smartmirror-ci.cloudfunctions.net/download_image");
      downloadUrl.searchParams.set("url", tryOnVideoUrl);
      downloadUrl.searchParams.set("name", `smart-mirror-essai-${selectedTryOnNumber}-video.mp4`);
      const link = document.createElement("a");
      link.href = downloadUrl.toString();
      link.style.display = "none";
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch {
      setDownloadErrors((current) => ({ ...current, front: "Le téléchargement de la vidéo n’a pas pu démarrer." }));
    } finally {
      window.setTimeout(() => setLookDownloading(false), 800);
    }
  }

  async function createTryOnRequestId() {
    const identityImages = identityImagesForTryOn();
    const identity = [
      "smartmirror-tryon-v12-garment-mandatory-multiview-sheet-2k",
      profile.gender,
      profile.height,
      profile.topSize,
      profile.pantsSize,
      profile.shoeSize,
      garmentSize,
      identityImages.faceFront || "",
      identityImages.bodyFront || "",
      identityImages.bodyRight || "",
      identityImages.bodyBack || "",
      garment,
      garmentBack,
    ].join("|");
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(identity));
    return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  async function generateTryOn() {
    if (!garment) return setError("Ajoutez d’abord le recto du vêtement.");
    if (tryOnRequestInFlight.current) return;
    setTryOnScale(100);
    tryOnRequestInFlight.current = true;
    const notificationUser = smartMirrorAuth.currentUser || authUser;
    if (notificationUser) void enablePushNotifications(notificationUser).catch(() => undefined);
    setTryOnGenerating(true);
    setTryOnProgress(4);
    setError("");
    const progressTimer = window.setInterval(() => {
      setTryOnProgress((current) => Math.min(92, current + Math.max(1, Math.round((94 - current) / 8))));
    }, 700);
    try {
      if (notificationUser) await saveAccountState(notificationUser).catch(() => undefined);
      const firebaseToken = notificationUser ? await notificationUser.getIdToken() : "";
      const requestHeaders = { "Content-Type": "application/json", ...(firebaseToken ? { Authorization: `Bearer ${firebaseToken}` } : {}) };
      const requestId = await createTryOnRequestId();
      const cachedRaw = localStorage.getItem(`smartmirror-tryon:${requestId}`);
      if (cachedRaw) {
        const cached = JSON.parse(cachedRaw) as TryOnResult;
        if (cached.imageUrl) {
          warmAvatarImageCache(cached.images);
          setTryOnResult(cached);
          saveGeneratedTryOn(cached);
          setTryOnProgress(100);
          setBodyView(0);
          announceBackgroundCompletion("Votre essayage est prêt", "Le nouveau rendu a été enregistré automatiquement dans le Studio.");
          return;
        }
      }
      const sheetResponse = await fetch(TRYON_API_URL, {
        method: "POST",
        headers: requestHeaders,
        body: JSON.stringify({
          requestId,
          generationMode: "multiview-sheet",
          notifyOnComplete: true,
          garmentType: "auto-detect",
          garmentSize,
          garmentSizes: {
            top: profile.topSize,
            pants: profile.pantsSize,
            shoes: profile.shoeSize,
          },
          gender: profile.gender,
          height: profile.height,
          identityImages: identityImagesForTryOn(),
          garmentFront: garment,
          garmentBack: garmentBack || undefined,
        }),
      });
      const sheetResult = await sheetResponse.json();
      if (!sheetResponse.ok) {
        const reason = sheetResult.detail
          ? `${sheetResult.error || "La génération a échoué."} ${sheetResult.detail}`
          : sheetResult.error;
        throw new Error(reason || "La planche multivue n’a pas pu être générée.");
      }
      if (!sheetResult.garmentReferenceCount) {
        throw new Error("Le vêtement n’a pas été transmis au moteur. Le résultat n’a pas été enregistré.");
      }
      if (sheetResult.images?.bodyFront && sheetResult.images?.bodyRight && sheetResult.images?.bodyBack) {
        warmAvatarImageCache(sheetResult.images);
        setTryOnResult(sheetResult);
        saveGeneratedTryOn(sheetResult);
        localStorage.setItem(`smartmirror-tryon:${requestId}`, JSON.stringify(sheetResult));
        setTryOnProgress(100);
        setBodyView(0);
        announceBackgroundCompletion("Votre essayage est prêt", "Le nouveau rendu a été enregistré automatiquement dans le Studio.");
        return;
      }
      throw new Error("La planche multivue est incomplète.");

      /*
       * Pipeline historique conservé pour retour rapide aux trois générations
       * séparées si le test multivue n’offre pas une qualité suffisante.
       */
      const viewOrder: { key: PhotoKey; index: number }[] = [
        { key: "bodyFront", index: 0 },
        { key: "bodyRight", index: 1 },
        { key: "bodyBack", index: 2 },
      ];
      let progressiveImages: Partial<Record<PhotoKey, string>> = {};
      let progressiveResult: TryOnResult | null = null;
      let lastViewError: Error | null = null;
      for (let index = 0; index < viewOrder.length; index += 1) {
        const view = viewOrder[index];
        try {
          const response = await fetch(TRYON_API_URL, {
            method: "POST",
            headers: requestHeaders,
            body: JSON.stringify({
              requestId,
              requestedView: view.key,
              notifyOnComplete: index === viewOrder.length - 1,
              garmentType: "auto-detect",
              garmentSize,
              garmentSizes: {
                top: profile.topSize,
                pants: profile.pantsSize,
                shoes: profile.shoeSize,
              },
              gender: profile.gender,
              height: profile.height,
              bodyView: bodyRotation[view.index].label,
              identityImages: identityImagesForTryOn(),
              continuityImageUrl: progressiveImages.bodyFront || undefined,
              garmentFront: garment,
              garmentBack: garmentBack || undefined,
            }),
          });
          const result = await response.json();
          if (!response.ok) {
            const reason = result.detail ? `${result.error || "La génération a échoué."} ${result.detail}` : result.error;
            throw new Error(reason || "La génération a échoué.");
          }
          progressiveImages = { ...progressiveImages, ...result.images };
          progressiveResult = {
            ...result,
            imageUrl: progressiveImages.bodyFront || result.imageUrl,
            images: progressiveImages,
          };
          warmAvatarImageCache(progressiveImages);
          setTryOnResult(progressiveResult);
          setBodyView(view.index);
          setTryOnProgress(Math.round(((index + 1) / viewOrder.length) * 96));
        } catch (viewError) {
          lastViewError = viewError instanceof Error ? viewError : new Error("Une vue n’a pas pu être générée.");
        }
      }
      if (!progressiveResult) throw lastViewError || new Error("Aucune vue n’a pu être générée.");
      saveGeneratedTryOn(progressiveResult);
      localStorage.setItem(`smartmirror-tryon:${requestId}`, JSON.stringify(progressiveResult));
      setTryOnProgress(100);
      setBodyView(0);
      announceBackgroundCompletion("Votre essayage est prêt", "Le nouveau rendu a été enregistré automatiquement dans le Studio.");
    } catch (generationError) {
      setError(generationError instanceof Error ? generationError.message : "La génération a échoué.");
    } finally {
      window.clearInterval(progressTimer);
      tryOnRequestInFlight.current = false;
      setTryOnGenerating(false);
    }
  }

  function announceBackgroundCompletion(title: string, detail: string) {
    setCompletionNotice(`${title}. ${detail}`);
    window.setTimeout(() => setCompletionNotice(""), 12000);
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(title, { body: detail, icon: "/icons/icon-192.png" });
    }
  }

  function startTryOnVideoPlayback() {
    if (!tryOnResult || !tryOnVideoUrl) return;
    const savedLook = wardrobe.find((item) => item.manifestHash === tryOnResult.manifestHash);
    const savedTrack = savedLook?.audioTrack ? `${savedLook.audioTrack.split("?")[0]}?v=2` : "";
    const selectedTrack = savedTrack || tryOnAudioTrack || SMART_MIRROR_AUDIO_TRACKS[Math.floor(Math.random() * SMART_MIRROR_AUDIO_TRACKS.length)];
    setTryOnAudioTrack(selectedTrack);
    setTryOnAudioMuted(false);
    setTryOnVideoLoaded(false);
    if (savedLook?.audioTrack !== selectedTrack) {
      setWardrobe((current) => current.map((item) => item.manifestHash === tryOnResult.manifestHash ? { ...item, audioTrack: selectedTrack } : item));
    }
    setTryOnVideoPlaying(true);
  }

  function toggleTryOnVideoAudio() {
    const nextMuted = !tryOnAudioMuted;
    setTryOnAudioMuted(nextMuted);
    if (tryOnVideoRef.current) tryOnVideoRef.current.muted = nextMuted;
  }

  async function createTryOnVideo() {
    if (!tryOnResult || tryOnVideoGenerating) return;
    const savedLook = wardrobe.find((item) => item.manifestHash === tryOnResult.manifestHash);
    if (savedLook?.videoUrl) {
      setTryOnVideoUrl(savedLook.videoUrl);
      setTryOnVideoHasAudio(Boolean(savedLook.videoHasAudio));
      warmVideoCache(savedLook.videoUrl);
      setTryOnVideoProgress(100);
      return;
    }
    if (savedLook?.videoTaskId) {
      setCompletionNotice("Cette vidéo est déjà en cours de création. Vous pouvez continuer à utiliser SMART MIRROR.");
      void restoreSavedTryOnVideo(savedLook);
      return;
    }
    const notificationUser = smartMirrorAuth.currentUser || authUser;
    if (notificationUser) void enablePushNotifications(notificationUser).catch(() => undefined);
    const imageList = [
      tryOnResult.images.bodyFront,
      tryOnResult.images.bodyRight,
      tryOnResult.images.bodyBack,
    ].filter(Boolean) as string[];
    if (imageList.length < 3) return setError("Les vues de l’essayage ne sont pas encore toutes disponibles.");
    setError("");
    setTryOnVideoGenerating(true);
    setTryOnVideoProgress(3);
    setTryOnVideoBackgroundColor("");
    const selectedAudioTrack = SMART_MIRROR_AUDIO_TRACKS[Math.floor(Math.random() * SMART_MIRROR_AUDIO_TRACKS.length)];
    const selectedAudioNumber = Number(selectedAudioTrack.match(/smart-lounge-(\d+)/)?.[1] || 1);
    setTryOnAudioTrack(selectedAudioTrack);
    try {
      const firebaseToken = notificationUser ? await notificationUser.getIdToken() : "";
      const createResponse = await fetch(KLING_VIDEO_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(firebaseToken ? { Authorization: `Bearer ${firebaseToken}` } : {}) },
        cache: "no-store",
        body: JSON.stringify({
          images: imageList,
          prompt: "A premium realistic fashion turntable video. The same person calmly turns to show the garment from front, right profile, back and left profile, then returns to front. Preserve the exact face, body, garment, colors and uniform SMART MIRROR beige background. No camera cut, no identity change, no added accessory.",
          duration: "5",
          aspectRatio: "9:16",
          backgroundColor: tryOnResult.backgroundColors?.bodyFront || "#e8e5dc",
          audioTrack: selectedAudioNumber,
          tryOnManifestHash: tryOnResult.manifestHash,
        }),
      });
      const createText = await createResponse.text();
      let created: { taskId?: string; error?: string; detail?: string } = {};
      try {
        created = createText ? JSON.parse(createText) : {};
      } catch {
        throw new Error("Le serveur vidéo a renvoyé une réponse illisible.");
      }
      if (!createResponse.ok || !created.taskId) {
        throw new Error([created.error, created.detail].filter(Boolean).join(" ") || "Kling n’a pas accepté la génération.");
      }
      let activeTaskId = created.taskId as string;
      setTryOnVideoTaskId(activeTaskId);
      setWardrobe((current) => current.map((item) => item.manifestHash === tryOnResult.manifestHash
        ? { ...item, videoTaskId: activeTaskId, videoBackgroundColor: tryOnResult.backgroundColors?.bodyFront || "#e8e5dc", audioTrack: selectedAudioTrack }
        : item));
      for (let attempt = 0; attempt < 120; attempt += 1) {
        await new Promise((resolve) => window.setTimeout(resolve, 4000));
        const statusResponse = await fetch(`${KLING_VIDEO_STATUS_API_URL}?taskId=${encodeURIComponent(activeTaskId)}`, { cache: "no-store" });
        const statusText = await statusResponse.text();
        let status: { taskId?: string; progress?: number; videoUrl?: string; status?: string; error?: string; message?: string; detail?: string; audioIncluded?: boolean; audioTrack?: number } = {};
        try {
          status = statusText ? JSON.parse(statusText) : {};
        } catch {
          throw new Error("Le suivi vidéo a renvoyé une réponse illisible.");
        }
        if (!statusResponse.ok) throw new Error([status.error, status.detail].filter(Boolean).join(" ") || "Suivi Kling indisponible.");
        if (status.taskId && status.taskId !== activeTaskId) {
          activeTaskId = status.taskId;
          setTryOnVideoTaskId(activeTaskId);
          setWardrobe((current) => current.map((item) => item.manifestHash === tryOnResult.manifestHash
            ? { ...item, videoTaskId: activeTaskId }
            : item));
        }
        if (typeof status.progress === "number") {
          setTryOnVideoProgress((current) => Math.max(current, Math.min(99, status.progress)));
        }
        if (status.videoUrl) {
          setTryOnVideoUrl(status.videoUrl);
          setTryOnVideoHasAudio(Boolean(status.audioIncluded));
          warmVideoCache(status.videoUrl);
          setTryOnVideoProgress(100);
          setWardrobe((current) => current.map((item) => item.manifestHash === tryOnResult.manifestHash
            ? { ...item, videoUrl: status.videoUrl, videoTaskId: activeTaskId, videoHasAudio: Boolean(status.audioIncluded), audioTrack: status.audioTrack ? SMART_MIRROR_AUDIO_TRACKS[status.audioTrack - 1] : selectedAudioTrack, unreadVideo: true }
            : item));
          announceBackgroundCompletion("Votre vidéo est prête", "Elle est conservée avec cet essai dans le Studio.");
          return;
        }
        if (status.status === "failed") throw new Error(status.error || status.message || "La création de la vidéo a échoué.");
      }
      throw new Error("Kling met plus de temps que prévu. Réessayez dans quelques instants.");
    } catch (videoError) {
      setError(videoError instanceof Error ? videoError.message : "La vidéo n’a pas pu être créée.");
      setTryOnVideoProgress(0);
    } finally {
      setTryOnVideoGenerating(false);
    }
  }

  function persistAvatarVideo(record: AvatarVideoRecord, target: AvatarVideoTarget) {
    if (target.usesDefaultAvatar) {
      setDefaultAvatarVideos((current) => {
        let stored: Partial<Record<"femme" | "homme", AvatarVideoRecord>> = {};
        try {
          stored = JSON.parse(localStorage.getItem("smartmirror-default-avatar-videos") || "{}");
        } catch {
          stored = {};
        }
        const existing = { ...stored[target.gender], ...current[target.gender] };
        const updated = { ...stored, ...current, [target.gender]: { ...existing, ...record } };
        localStorage.setItem("smartmirror-default-avatar-videos", JSON.stringify(updated));
        return updated;
      });
      return;
    }
    setAvatarLibrary((current) => {
      const updated = current.map((avatar) => avatar.id === target.avatarId ? {
        ...avatar,
        presentationVideoUrl: record.videoUrl ?? avatar.presentationVideoUrl,
        presentationVideoTaskId: record.taskId ?? avatar.presentationVideoTaskId,
        presentationVideoBackgroundColor: record.backgroundColor ?? avatar.presentationVideoBackgroundColor,
        presentationVideoHasAudio: record.hasAudio ?? avatar.presentationVideoHasAudio,
      } : avatar);
      localStorage.setItem("smartmirror-avatar-library", JSON.stringify(updated));
      return updated;
    });
  }

  async function createAvatarPresentationVideo() {
    if (avatarVideoGenerating || tryOnResult) return;
    if (avatarVideoUrl) {
      setAvatarVideoPlaying(true);
      setAvatarVideoLoaded(false);
      return;
    }
    const sourceImages = identityImagesForTryOn();
    const imageList = [sourceImages.bodyFront, sourceImages.bodyRight, sourceImages.bodyBack]
      .filter(Boolean)
      .map((url) => new URL(url as string, window.location.origin).href);
    if (imageList.length < 3) return setError("Les trois vues de l’avatar sont nécessaires pour créer sa présentation.");
    if ("Notification" in window && Notification.permission === "default") void Notification.requestPermission();
    setError("");
    setAvatarVideoGenerating(true);
    setAvatarVideoProgress(3);
    const backgroundColor = avatarBackgroundColors.bodyFront || "#e8e5dc";
    const target: AvatarVideoTarget = {
      usesDefaultAvatar: displayingDefaultAvatar,
      gender: profile.gender === "homme" ? "homme" : "femme",
      avatarId: activeAvatarId,
    };
    setAvatarVideoBackgroundColor(backgroundColor);
    try {
      let activeTaskId = avatarVideoTaskId;
      if (!activeTaskId) {
        const response = await fetch(KLING_VIDEO_API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          cache: "no-store",
          body: JSON.stringify({
            images: imageList,
            videoKind: "avatar-presentation",
            backgroundColor,
            audioTrack: Math.floor(Math.random() * SMART_MIRROR_AUDIO_TRACKS.length) + 1,
          }),
        });
        const created = await response.json() as { taskId?: string; error?: string; detail?: string };
        if (!response.ok || !created.taskId) throw new Error([created.error, created.detail].filter(Boolean).join(" ") || "Kling n’a pas accepté la présentation de l’avatar.");
        activeTaskId = created.taskId;
        setAvatarVideoTaskId(activeTaskId);
        persistAvatarVideo({ taskId: activeTaskId, backgroundColor }, target);
      }
      for (let attempt = 0; attempt < 120; attempt += 1) {
        await new Promise((resolve) => window.setTimeout(resolve, 4000));
        const response = await fetch(`${KLING_VIDEO_STATUS_API_URL}?taskId=${encodeURIComponent(activeTaskId)}`, { cache: "no-store" });
        const status = await response.json() as { taskId?: string; progress?: number; videoUrl?: string; status?: string; error?: string; detail?: string; audioIncluded?: boolean };
        if (!response.ok) throw new Error([status.error, status.detail].filter(Boolean).join(" ") || "Le suivi Kling est indisponible.");
        if (status.taskId && status.taskId !== activeTaskId) {
          activeTaskId = status.taskId;
          setAvatarVideoTaskId(activeTaskId);
          persistAvatarVideo({ taskId: activeTaskId, backgroundColor }, target);
        }
        if (typeof status.progress === "number") setAvatarVideoProgress((current) => Math.max(current, Math.min(99, status.progress || 0)));
        if (status.videoUrl) {
          setAvatarVideoUrl(status.videoUrl);
          setAvatarVideoHasAudio(Boolean(status.audioIncluded));
          setAvatarVideoProgress(100);
          warmVideoCache(status.videoUrl);
          persistAvatarVideo({ videoUrl: status.videoUrl, taskId: activeTaskId, backgroundColor, hasAudio: Boolean(status.audioIncluded) }, target);
          announceBackgroundCompletion("La présentation de votre avatar est prête", "Vous pouvez la regarder depuis l’accueil.");
          return;
        }
        if (status.status === "failed") throw new Error(status.error || "La présentation vidéo n’a pas pu être créée.");
      }
      throw new Error("Kling met plus de temps que prévu. La création continuera en arrière-plan.");
    } catch (videoError) {
      setError(videoError instanceof Error ? videoError.message : "La présentation vidéo n’a pas pu être créée.");
      setAvatarVideoProgress(0);
    } finally {
      setAvatarVideoGenerating(false);
    }
  }

  async function restoreSavedTryOnVideo(item: WardrobeItem) {
    const wasPending = !item.videoUrl;
    setTryOnVideoPlaying(false);
    setTryOnVideoLoaded(false);
    setTryOnVideoUrl(item.videoUrl || "");
    setTryOnVideoHasAudio(Boolean(item.videoHasAudio));
    if (item.videoUrl) warmVideoCache(item.videoUrl);
    setTryOnVideoTaskId(item.videoTaskId || "");
    setTryOnVideoBackgroundColor(item.videoBackgroundColor || "");
    setTryOnAudioTrack(item.audioTrack || "");
    setTryOnAudioMuted(false);
    setTryOnVideoProgress(item.videoUrl ? 100 : 0);
    if (!item.videoTaskId) return;
    setTryOnVideoGenerating(!item.videoUrl);
    try {
      let activeTaskId = item.videoTaskId;
      for (let attempt = 0; attempt < 120; attempt += 1) {
        if (attempt > 0) await new Promise((resolve) => window.setTimeout(resolve, 4000));
        const response = await fetch(`${KLING_VIDEO_STATUS_API_URL}?taskId=${encodeURIComponent(activeTaskId)}`, { cache: "no-store" });
        const status = await response.json() as { taskId?: string; videoUrl?: string; status?: string; progress?: number; audioIncluded?: boolean; audioTrack?: number };
        if (!response.ok) return;
        if (status.taskId && status.taskId !== activeTaskId) {
          activeTaskId = status.taskId;
          setTryOnVideoTaskId(activeTaskId);
          setWardrobe((current) => current.map((savedItem) => savedItem.id === item.id ? { ...savedItem, videoTaskId: activeTaskId } : savedItem));
        }
        if (typeof status.progress === "number") setTryOnVideoProgress(Math.min(99, status.progress));
        if (!status.videoUrl) {
          if (status.status === "failed") return;
          continue;
        }
        setTryOnVideoUrl(status.videoUrl);
        setTryOnVideoHasAudio(Boolean(status.audioIncluded));
        warmVideoCache(status.videoUrl);
        setTryOnVideoProgress(100);
        setWardrobe((current) => current.map((savedItem) => savedItem.id === item.id
          ? { ...savedItem, videoUrl: status.videoUrl, videoTaskId: activeTaskId, videoHasAudio: Boolean(status.audioIncluded), audioTrack: status.audioTrack ? SMART_MIRROR_AUDIO_TRACKS[status.audioTrack - 1] : savedItem.audioTrack, unreadVideo: wasPending ? true : savedItem.unreadVideo }
          : savedItem));
        if (wasPending) announceBackgroundCompletion("Votre vidéo est prête", "Elle est conservée avec cet essai dans le Studio.");
        return;
      }
    } catch {
      // Keep the saved URL available if refreshing its temporary access link fails.
    } finally {
      setTryOnVideoGenerating(false);
    }
  }

  function startTryOnFromSheet() {
    if (!garment) {
      setError("Ajoutez d’abord le recto du vêtement.");
      return;
    }
    setError("");
    setTryOnOpen(false);
    setTryOnProgress(1);
    // Give the mobile browser one full paint cycle to remove the sheet before
    // serializing photos and starting the long generation request.
    window.requestAnimationFrame(() => {
      window.setTimeout(() => void generateTryOn(), 120);
    });
  }

  async function generateBaseAvatar(requestedKeys?: PhotoKey[]) {
    if (avatarRequestInFlight.current) return;
    avatarRequestInFlight.current = true;
    setAvatarGenerationMode(Object.keys(baseAvatarImages).length ? "recreate" : "create");
    setAvatarProgress(4);
    setAvatarGenerating(true);
    setError("");
    try {
      await Promise.all(Object.values(identityUploadPromises.current));
      const identityPhotosForGeneration = {
        ...photos,
        ...uploadedIdentityPhotos.current,
      };
      const allViewOrder: { key: PhotoKey; index: number }[] = [
        { key: "bodyFront", index: 0 },
        { key: "bodyRight", index: 1 },
        { key: "bodyBack", index: 2 },
      ];
      const viewOrder = requestedKeys?.length
        ? allViewOrder.filter((view) => requestedKeys.includes(view.key))
        : allViewOrder;
      setAvatarPendingViews(viewOrder.map((view) => view.key));
      let generatedImages: Partial<Record<PhotoKey, string>> = requestedKeys?.length
        ? { ...baseAvatarImages }
        : {};
      let generatedBackgroundColors: AvatarBackgroundColors = requestedKeys?.length
        ? { ...avatarBackgroundColors }
        : {};
      let generatedBackgroundGradients: AvatarBackgroundGradients = requestedKeys?.length
        ? { ...avatarBackgroundGradients }
        : {};
      let generatedCount = 0;
      let analyzedByYoucam = false;
      let lastViewError: Error | null = null;
      const outfitOnlyReference = `https://smartmirror-ci.web.app/default-avatars/${
        profile.gender === "homme" ? "male" : "female"
      }-outfit-headless.png`;
      // Full avatar creation now uses one coherent 2K contact sheet. Individual
      // requests remain available for retrying only a defective view and are
      // also the rollback path to the historical renderer.
      if (!requestedKeys?.length) {
        const response = await fetch(TRYON_API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            mode: "avatar",
            generationMode: "multiview-sheet",
            avatarRenderMode: "legacy-background",
            gender: profile.gender,
            height: profile.height,
            identityImages: identityPhotosForGeneration,
            continuityImageUrl: outfitOnlyReference,
          }),
        });
        const result = await response.json();
        if (!response.ok) {
          throw new Error(result.detail || result.error || "La planche avatar 2K n’a pas pu être créée.");
        }
        if (!result.images?.bodyFront || !result.images?.bodyRight || !result.images?.bodyBack) {
          throw new Error("La planche avatar 2K est incomplète.");
        }
        generatedImages = result.images;
        generatedBackgroundColors = result.backgroundColors || {};
        generatedBackgroundGradients = result.backgroundGradients || {};
        generatedCount = 3;
        analyzedByYoucam = result.youcam?.status === "success";
        setBaseAvatarImages(generatedImages);
        warmAvatarImageCache(generatedImages);
        localStorage.setItem("smartmirror-base-avatar-v2", JSON.stringify(generatedImages));
        setAvatarBackgroundColors(generatedBackgroundColors);
        localStorage.setItem("smartmirror-avatar-background-colors", JSON.stringify(generatedBackgroundColors));
        setAvatarBackgroundGradients(generatedBackgroundGradients);
        localStorage.setItem("smartmirror-avatar-background-gradients", JSON.stringify(generatedBackgroundGradients));
        setAvatarPendingViews([]);
        setAvatarProgress(96);
        setBodyView(0);
        setStep(STUDIO_STEP);
      }
      for (const view of viewOrder) {
        if (!requestedKeys?.length) break;
        try {
          const response = await fetch(TRYON_API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              mode: "avatar",
              avatarRenderMode: "legacy-background",
              requestedView: view.key,
              gender: profile.gender,
               height: profile.height,
               identityImages: identityPhotosForGeneration,
               continuityImageUrl: view.key === "bodyFront"
                 ? outfitOnlyReference
                 : generatedImages.bodyFront || outfitOnlyReference,
            }),
          });
          const result = await response.json();
          if (!response.ok) {
            throw new Error(result.detail || result.error || "Une vue de l’avatar n’a pas pu être créée.");
          }
          generatedImages = { ...generatedImages, ...result.images };
          generatedBackgroundColors = { ...generatedBackgroundColors, ...(result.backgroundColors || {}) };
          generatedBackgroundGradients = { ...generatedBackgroundGradients, ...(result.backgroundGradients || {}) };
          generatedCount += 1;
          setAvatarProgress(Math.round((generatedCount / viewOrder.length) * 96));
          analyzedByYoucam = analyzedByYoucam || result.youcam?.status === "success";
          setBaseAvatarImages(generatedImages);
          warmAvatarImageCache(generatedImages);
          localStorage.setItem("smartmirror-base-avatar-v2", JSON.stringify(generatedImages));
          setAvatarBackgroundColors(generatedBackgroundColors);
          localStorage.setItem("smartmirror-avatar-background-colors", JSON.stringify(generatedBackgroundColors));
          setAvatarBackgroundGradients(generatedBackgroundGradients);
          localStorage.setItem("smartmirror-avatar-background-gradients", JSON.stringify(generatedBackgroundGradients));
          setAvatarPendingViews((current) => current.filter((key) => key !== view.key));
          setBodyView(view.index);
          if (generatedCount === 1) setStep(STUDIO_STEP);
        } catch (viewError) {
          lastViewError = viewError instanceof Error ? viewError : new Error("Une vue de l’avatar n’a pas pu être créée.");
        }
      }
      if (generatedCount === 0) throw lastViewError || new Error("Aucune vue de l’avatar n’a pu être créée.");
      setYoucamReady(analyzedByYoucam);
      localStorage.setItem("smartmirror-youcam-status", analyzedByYoucam ? "success" : "error");
      localStorage.setItem("smartmirror-profile", JSON.stringify({
        ...profile,
        onboardingVersion: 3,
        profilePhoto: photos.faceFront || "",
        identityPhotos: Object.keys(photos),
        identityPhotoData: photos,
        usesDefaultAvatar: false,
        avaturnAvatarId: avaturnAvatar?.avatarId,
      }));
      setUsesDefaultAvatar(false);
      const avatarItem: AvatarLibraryItem = {
        id: `avatar-${Date.now()}`,
        label: `Avatar ${avatarLibrary.length + 1}`,
        gender: profile.gender,
        images: generatedImages,
        backgroundColors: generatedBackgroundColors,
        backgroundGradients: generatedBackgroundGradients,
        identityPhotos: photos,
        measurements: {
          height: profile.height,
          topSize: profile.topSize,
          pantsSize: profile.pantsSize,
          shoeSize: profile.shoeSize,
        },
        createdAt: new Date().toISOString(),
      };
      setAvatarLibrary((current) => {
        const updated = [...current, avatarItem];
        localStorage.setItem("smartmirror-avatar-library", JSON.stringify(updated));
        return updated;
      });
      localStorage.setItem("smartmirror-active-avatar-id", avatarItem.id);
      setActiveAvatarId(avatarItem.id);
      setRecreateBackup(null);
      localStorage.setItem("smartmirror-client-flow", "photo-flow-v2");
      setBodyView(0);
      setAvatarProgress(100);
    } catch (avatarError) {
      setError(avatarError instanceof Error ? avatarError.message : "La création de l’avatar a échoué.");
    } finally {
      avatarRequestInFlight.current = false;
      setAvatarPendingViews([]);
      setAvatarGenerating(false);
    }
  }

  if (avatarStudioOpen) {
    return (
      <main className="avatar-journey">
        <button className="avatar-studio-close" type="button" onClick={() => setAvatarStudioOpen(false)}>Retour aux photos</button>
        <HumanAvatarFlow
          name={profile.name}
          gender={profile.gender || "homme"}
          initialAvatar={avaturnAvatar}
          onComplete={(avatar) => {
            setAvaturnAvatar(avatar);
            setAvatarStudioOpen(false);
          }}
        />
      </main>
    );
  }

  const accountRedirectPending = accountConnected && step === 1 && !identityCaptureStarted;

  if (!sessionReady || !authReady || accountRedirectPending) {
    return <main className="session-loading"><Logo /><span>Ouverture de votre SMART MIRROR…</span></main>;
  }

  if (step === SHOP_STEP) {
    return (
      <main className="wardrobe-shell">
        <BoutiqueHeader onNavigate={navigateMain} language={language} />
        <section className="shop-grid">
          {shopProducts.map((product) => (
            <article className="shop-product" key={product.name}>
              <div className="shop-product-image"><img src={product.image} alt={product.name} /><small>{product.color}</small></div>
              <span>{product.type}</span>
              <h2>{product.name}</h2>
              <strong>{product.price}</strong>
              <label className="shop-size-picker"><span>Taille</span><select value={shopSelectedSizes[product.id] || defaultSize(product.type)} onChange={(event) => setShopSelectedSizes((current) => ({ ...current, [product.id]: event.target.value }))}>{availableShopSizes(product.type).map((size) => <option key={size}>{size}</option>)}</select></label>
              <button onClick={() => void selectShopProduct(product)}>Voir sur moi</button>
              <button className="shop-buy-button">Acheter</button>
            </article>
          ))}
        </section>
        <section className="api-demo-note">
          <b>Ce que la boutique vient de transmettre</b>
          <span>shopId · productId · photo · catégorie · couleur · taille sélectionnée</span>
          <small>Le produit reste mémorisé pendant la connexion ou la création de l’avatar.</small>
        </section>
      </main>
    );
  }

  const activateDesktopAvatar = (choice: AvatarLibraryItem | "default-femme" | "default-homme") => {
    uploadedIdentityPhotos.current = {};
    identityUploadPromises.current = {};
    setIdentityUploadStatus({});
    if (typeof choice === "string") {
      const gender = choice === "default-homme" ? "homme" : "femme";
      const defaultPhotos = Object.fromEntries(photoGuides.map((photo) => [photo.key, defaultPhotoFor(photo.example, gender)])) as Partial<Record<PhotoKey, string>>;
      const nextProfile = { ...profile, gender, ...defaultMeasurements[gender], usesDefaultAvatar: true, profilePhoto: "", identityPhotos: [] };
      setProfile(nextProfile);
      setPhotos(defaultPhotos);
      setBaseAvatarImages({});
      setAvatarBackgroundColors({});
      setAvatarBackgroundGradients({});
      setUsesDefaultAvatar(true);
      setActiveAvatarId("");
      localStorage.removeItem("smartmirror-active-avatar-id");
      localStorage.setItem("smartmirror-base-avatar-v2", JSON.stringify({}));
      localStorage.setItem("smartmirror-profile", JSON.stringify(nextProfile));
    } else {
      const nextProfile = { ...profile, gender: choice.gender, ...choice.measurements, usesDefaultAvatar: false, profilePhoto: choice.identityPhotos.faceFront || "", identityPhotos: Object.keys(choice.identityPhotos), identityPhotoData: choice.identityPhotos };
      setProfile(nextProfile);
      setPhotos(choice.identityPhotos);
      setBaseAvatarImages(choice.images);
      setAvatarBackgroundColors(choice.backgroundColors || {});
      setAvatarBackgroundGradients(choice.backgroundGradients || {});
      warmAvatarImageCache(choice.images);
      setUsesDefaultAvatar(false);
      setActiveAvatarId(choice.id);
      localStorage.setItem("smartmirror-active-avatar-id", choice.id);
      localStorage.setItem("smartmirror-base-avatar-v2", JSON.stringify(choice.images));
      localStorage.setItem("smartmirror-avatar-background-colors", JSON.stringify(choice.backgroundColors || {}));
      localStorage.setItem("smartmirror-avatar-background-gradients", JSON.stringify(choice.backgroundGradients || {}));
      localStorage.setItem("smartmirror-profile", JSON.stringify(nextProfile));
    }
    setTryOnResult(null);
    setViewingSavedLook(false);
    setBodyView(0);
    setIdentityCaptureStarted(false);
    setRecreateBackup(null);
    setStep(STUDIO_STEP);
    setProfileSaveStatus("Avatar activé ✓");
  };

  if (step === PROFILE_STEP) {
    const hasPersonalAvatar = !usesDefaultAvatar
      && Boolean(baseAvatarImages.bodyFront)
      && !baseAvatarImages.bodyFront?.includes("/default-avatars/")
      && Object.values(photos).some((photo) => photo?.startsWith("data:image/"));
    const activePersonalAvatar = avatarLibrary.find((avatar) => avatar.id === activeAvatarId)
      || (!usesDefaultAvatar ? avatarLibrary.find((avatar) => avatar.images.bodyFront === baseAvatarImages.bodyFront) : undefined);
    const activeGender = activePersonalAvatar?.gender || (profile.gender === "homme" ? "homme" : "femme");
    const activeAvatarName = activePersonalAvatar?.label
      || (activeGender === "homme" ? "Koffi Smart" : "Awa Smart");
    const activeAvatarPhoto = activePersonalAvatar?.images.bodyFront
      || defaultPhotoFor("/pose-examples/body-front.webp", activeGender);
    const activeMeasurements = activePersonalAvatar?.measurements || defaultMeasurements[activeGender];
    return (
      <main className="profile-page">
        {(tryOnGenerating || tryOnVideoGenerating || avatarVideoGenerating || completionNotice) && <aside className="background-task-notice" role="status"><strong>{completionNotice || (avatarVideoGenerating ? `Création de la présentation ${avatarVideoProgress}%` : tryOnVideoGenerating ? `Création de la vidéo ${tryOnVideoProgress}%` : `Création de l’essayage ${tryOnProgress}%`)}</strong>{!completionNotice && <span>Vous pouvez continuer à utiliser SMART MIRROR.</span>}</aside>}
        <ProfileHeader language={language} onLanguage={(nextLanguage) => {
          setLanguage(nextLanguage);
          localStorage.setItem("smartmirror-language", nextLanguage);
          document.documentElement.lang = nextLanguage;
          window.location.reload();
        }} onBack={() => setStep(profileReturnStep)} onLogout={() => { void disconnectAccount(); }} />
        <section className="profile-panel">
          <div className="active-avatar-profile">
            <img src={activeAvatarPhoto} alt={`Avatar actif : ${activeAvatarName}`} />
            <div>
              <strong>{activeAvatarName}</strong>
              <span>{profile.email || "Compte SMART MIRROR"}</span>
            </div>
          </div>
          <button className="save-profile-button" type="button" onClick={() => {
            setMeasurementDraft(activeMeasurements);
            setMeasurementsOpen(true);
          }}>{language === "zh" ? "修改身体尺寸" : language === "en" ? "Edit measurements" : "Modifier les données de mensuration"}</button>
          {profileSaveStatus && <p className="profile-save-status" role="status">{profileSaveStatus}</p>}
          {error && <p className="profile-save-error" role="alert">{error}</p>}
          <section className="avatar-library" aria-label="Mes avatars">
            <div className="avatar-library-heading">
              <strong>{language === "zh" ? "我的虚拟形象" : language === "en" ? "My avatars" : "Mes avatars"}</strong>
              <span>{avatarLibrary.length + 2} {language === "zh" ? "个可用" : language === "en" ? "available" : "disponibles"}</span>
            </div>
            <div className="avatar-library-list">
              {[...avatarLibrary]
                .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                .map((avatar) => (
                  <article className="avatar-library-item" key={avatar.id}>
                    <button className="avatar-library-select" type="button" onClick={() => setAvatarChoice(avatar)}>
                      <img src={avatar.images.bodyFront || defaultPhotoFor("/pose-examples/body-front.webp", avatar.gender)} alt={avatar.label} style={imageSurfaceStyle(avatar.backgroundColors, avatar.backgroundGradients)} />
                      <span>{avatar.label}</span>
                    </button>
                    <button className="avatar-delete-button" type="button" aria-label={`Supprimer ${avatar.label}`} onClick={() => {
                      setAvatarToDelete(avatar);
                    }}>
                      <svg viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M4 7h16M9 7V4h6v3m-8 0 1 13h8l1-13M10 11v5m4-5v5" />
                      </svg>
                    </button>
                  </article>
                ))}
              {(["default-femme", "default-homme"] as const).map((id) => {
                const gender = id === "default-homme" ? "homme" : "femme";
                return (
                  <button className="avatar-library-select" type="button" key={id} onClick={() => setAvatarChoice(id)}>
                    <img src={defaultPhotoFor("/pose-examples/body-front.webp", gender)} alt={`Avatar ${gender} par défaut`} />
                    <span>{gender === "homme" ? "Homme" : "Femme"} par défaut</span>
                  </button>
                );
              })}
            </div>
          </section>
          <button className="regenerate-avatar-button" disabled={avatarGenerating} onClick={() => {
            setRecreateBackup({ photos, images: baseAvatarImages });
            uploadedIdentityPhotos.current = {};
            identityUploadPromises.current = {};
            setIdentityUploadStatus({});
            setPhotos({});
            setError("");
            setIdentityCaptureStarted(true);
            setStep(1);
          }}>
            {avatarGenerating
              ? `Création en cours · ${avatarProgress}%`
              : avatarLibrary.length > 0 || hasPersonalAvatar
                ? (language === "zh" ? "创建新的虚拟形象" : language === "en" ? "Create a new avatar" : "Créer un nouvel avatar")
                : (language === "zh" ? "创建我的虚拟形象" : language === "en" ? "Create my avatar" : "Créer mon avatar")}
          </button>
        </section>
        {measurementsOpen && (
          <div className="measurements-backdrop" role="presentation" onClick={() => setMeasurementsOpen(false)}>
            <section className="measurements-sheet" role="dialog" aria-modal="true" aria-label="Modifier les données de mensuration" onClick={(event) => event.stopPropagation()}>
              <div className="measurements-sheet-handle" />
              <h2>{language === "zh" ? `${activeAvatarName} 的身体尺寸` : language === "en" ? `${activeAvatarName}'s measurements` : `Mensurations de ${activeAvatarName}`}</h2>
              <p>{language === "zh" ? "这些数据将用于此虚拟形象之后的试穿。" : language === "en" ? "These measurements will be used for this avatar's next try-ons." : "Ces données seront utilisées pour les prochains essayages de cet avatar."}</p>
              <div className="measurements-grid">
                <label><span>Taille</span><select value={measurementDraft.height} onChange={(e) => setMeasurementDraft((current) => ({ ...current, height: Number(e.target.value) }))}>{Array.from({ length: 71 }, (_, i) => 140 + i).map((value) => <option key={value} value={value}>{value} cm</option>)}</select></label>
                <label><span>Chemise / haut</span><select value={measurementDraft.topSize} onChange={(e) => setMeasurementDraft((current) => ({ ...current, topSize: e.target.value }))}>{["XS", "S", "M", "L", "XL", "XXL", "3XL+"].map((value) => <option key={value}>{value}</option>)}</select></label>
                <label><span>Pantalon</span><select value={measurementDraft.pantsSize} onChange={(e) => setMeasurementDraft((current) => ({ ...current, pantsSize: e.target.value }))}>{Array.from({ length: 17 }, (_, i) => String(32 + i * 2)).map((value) => <option key={value}>{value}</option>)}</select></label>
                <label><span>Pointure</span><select value={measurementDraft.shoeSize} onChange={(e) => setMeasurementDraft((current) => ({ ...current, shoeSize: e.target.value }))}>{Array.from({ length: 20 }, (_, i) => String(33 + i)).map((value) => <option key={value}>{value}</option>)}</select></label>
              </div>
              <button type="button" onClick={() => {
                setProfile((current) => ({ ...current, ...measurementDraft }));
                if (activePersonalAvatar) {
                  const updated = avatarLibrary.map((avatar) => avatar.id === activePersonalAvatar.id ? { ...avatar, measurements: measurementDraft } : avatar);
                  setAvatarLibrary(updated);
                  localStorage.setItem("smartmirror-avatar-library", JSON.stringify(updated));
                } else {
                  const updatedDefaults = { ...defaultMeasurements, [activeGender]: measurementDraft };
                  setDefaultMeasurements(updatedDefaults);
                  localStorage.setItem("smartmirror-default-avatar-measurements", JSON.stringify(updatedDefaults));
                }
                localStorage.setItem("smartmirror-profile", JSON.stringify({ ...profile, ...measurementDraft, usesDefaultAvatar: !activePersonalAvatar }));
                setMeasurementsOpen(false);
                setProfileSaveStatus("Mensurations enregistrées ✓");
              }}>{language === "zh" ? "保存身体尺寸" : language === "en" ? "Save measurements" : "Enregistrer les mensurations"}</button>
            </section>
          </div>
        )}
        {avatarToDelete && (
          <div className="avatar-choice-backdrop" role="presentation" onClick={() => setAvatarToDelete(null)}>
            <section className="avatar-choice-dialog delete-avatar-dialog" role="alertdialog" aria-modal="true" aria-label="Confirmer la suppression" onClick={(event) => event.stopPropagation()}>
              <div className="delete-avatar-icon">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3m-8 0 1 13h8l1-13M10 11v5m4-5v5" /></svg>
              </div>
              <h2>Supprimer cet avatar ?</h2>
              <p><strong>{avatarToDelete.label}</strong> sera supprimé définitivement. Cette action est irréversible.</p>
              <div>
                <button type="button" onClick={() => setAvatarToDelete(null)}>Annuler</button>
                <button className="confirm-avatar-deletion" type="button" onClick={() => {
                  const updated = avatarLibrary.filter((item) => item.id !== avatarToDelete.id);
                  setAvatarLibrary(updated);
                  localStorage.setItem("smartmirror-avatar-library", JSON.stringify(updated));
                  if (activeAvatarId === avatarToDelete.id) {
                    const gender = avatarToDelete.gender === "homme" ? "homme" : "femme";
                    setActiveAvatarId("");
                    setUsesDefaultAvatar(true);
                    setBaseAvatarImages({});
                    setAvatarBackgroundColors({});
                    setAvatarBackgroundGradients({});
                    setProfile((current) => ({ ...current, gender, ...defaultMeasurements[gender] }));
                    localStorage.removeItem("smartmirror-active-avatar-id");
                    localStorage.removeItem("smartmirror-base-avatar-v2");
                  }
                  setAvatarToDelete(null);
                  setProfileSaveStatus("Avatar supprimé ✓");
                }}>Supprimer l’avatar</button>
              </div>
            </section>
          </div>
        )}
        {avatarChoice && (
          <div className="avatar-choice-backdrop" role="presentation" onClick={() => setAvatarChoice(null)}>
            <section className="avatar-choice-dialog" role="dialog" aria-modal="true" aria-label="Utiliser cet avatar" onClick={(event) => event.stopPropagation()}>
              <img
                src={typeof avatarChoice === "string"
                  ? defaultPhotoFor("/pose-examples/body-front.webp", avatarChoice === "default-homme" ? "homme" : "femme")
                  : avatarChoice.images.bodyFront || defaultPhotoFor("/pose-examples/body-front.webp", avatarChoice.gender)}
                alt="Aperçu de l’avatar sélectionné"
              />
              <h2>Utiliser cet avatar ?</h2>
              <p>Il deviendra votre avatar actif à l’accueil et pour vos prochains essayages.</p>
              <div>
                <button type="button" onClick={() => setAvatarChoice(null)}>Annuler</button>
                <button type="button" onClick={() => {
                  uploadedIdentityPhotos.current = {};
                  identityUploadPromises.current = {};
                  setIdentityUploadStatus({});
                  if (typeof avatarChoice === "string") {
                    const gender = avatarChoice === "default-homme" ? "homme" : "femme";
                    const defaultPhotos = Object.fromEntries(photoGuides.map((photo) => [photo.key, defaultPhotoFor(photo.example, gender)])) as Partial<Record<PhotoKey, string>>;
                    setProfile((current) => ({ ...current, gender, ...defaultMeasurements[gender] }));
                    setPhotos(defaultPhotos);
                    setBaseAvatarImages({});
                    setAvatarBackgroundColors({});
                    setAvatarBackgroundGradients({});
                    setUsesDefaultAvatar(true);
                    setActiveAvatarId("");
                    localStorage.removeItem("smartmirror-active-avatar-id");
                    localStorage.setItem("smartmirror-base-avatar-v2", JSON.stringify({}));
                    localStorage.setItem("smartmirror-profile", JSON.stringify({ ...profile, gender, ...defaultMeasurements[gender], usesDefaultAvatar: true, profilePhoto: "", identityPhotos: [] }));
                  } else {
                    setProfile((current) => ({ ...current, gender: avatarChoice.gender, ...avatarChoice.measurements }));
                    setPhotos(avatarChoice.identityPhotos);
                    setBaseAvatarImages(avatarChoice.images);
                    setAvatarBackgroundColors(avatarChoice.backgroundColors || {});
                    setAvatarBackgroundGradients(avatarChoice.backgroundGradients || {});
                    warmAvatarImageCache(avatarChoice.images);
                    setUsesDefaultAvatar(false);
                    setActiveAvatarId(avatarChoice.id);
                    localStorage.setItem("smartmirror-active-avatar-id", avatarChoice.id);
                    localStorage.setItem("smartmirror-base-avatar-v2", JSON.stringify(avatarChoice.images));
                    localStorage.setItem("smartmirror-avatar-background-colors", JSON.stringify(avatarChoice.backgroundColors || {}));
                    localStorage.setItem("smartmirror-avatar-background-gradients", JSON.stringify(avatarChoice.backgroundGradients || {}));
                    localStorage.setItem("smartmirror-profile", JSON.stringify({ ...profile, gender: avatarChoice.gender, ...avatarChoice.measurements, usesDefaultAvatar: false, profilePhoto: avatarChoice.identityPhotos.faceFront || "", identityPhotos: Object.keys(avatarChoice.identityPhotos), identityPhotoData: avatarChoice.identityPhotos }));
                  }
                  setBodyView(0);
                  setAvatarChoice(null);
                  setProfileSaveStatus("Avatar activé ✓");
                  setStep(STUDIO_STEP);
                }}>Utiliser cet avatar</button>
              </div>
            </section>
          </div>
        )}
      </main>
    );
  }

  if (step === CLOSET_STEP) {
    return (
      <main className="closet-page">
        {(tryOnGenerating || tryOnVideoGenerating || avatarVideoGenerating || completionNotice) && <aside className="background-task-notice" role="status"><strong>{completionNotice || (avatarVideoGenerating ? `Création de la présentation ${avatarVideoProgress}%` : tryOnVideoGenerating ? `Création de la vidéo ${tryOnVideoProgress}%` : `Création de l’essayage ${tryOnProgress}%`)}</strong>{!completionNotice && <span>Vous pouvez continuer à utiliser SMART MIRROR.</span>}</aside>}
        <StudioHeader onNavigate={navigateMain} language={language} />
        <section className="closet-looks">
          {wardrobe.length ? (
            <div className="wardrobe-grid">{[...wardrobe].reverse().map((item, index) => {
              const tryOnNumber = wardrobe.length - index;
              return (
              <article key={item.id}>
                <button
                  className="delete-tryon-button"
                  type="button"
                  aria-label={`Supprimer l’essai n° ${tryOnNumber}`}
                  title="Supprimer cet essai"
                  onClick={() => deleteSavedTryOn(item, tryOnNumber)}
                >
                  <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M4 7h16" />
                    <path d="M9 7V4h6v3" />
                    <path d="m6 7 1 13h10l1-13" />
                    <path d="M10 11v5M14 11v5" />
                  </svg>
                </button>
                <div className="wardrobe-thumbs single" style={imageSurfaceStyle(item.backgroundColors, item.backgroundGradients)}><img src={item.image} alt={item.name} loading="lazy" decoding="async" style={imageSurfaceStyle(item.backgroundColors, item.backgroundGradients)} /></div>{(item.unreadTryOn || item.unreadVideo) && <b className="studio-new-badge">{item.unreadVideo ? "NOUVELLE VIDÉO" : "NOUVEL ESSAI"}</b>}<span>ESSAI N° {tryOnNumber}</span><strong>{item.name}</strong><small>Taille {item.size} · Manifest vérifié</small><button onClick={() => { const savedImages = item.images || { bodyFront: item.image }; warmAvatarImageCache(savedImages); setTryOnOpen(false); setPendingShopProduct(null); localStorage.removeItem("smartmirror-pending-product"); setSelectedTryOnNumber(tryOnNumber); setViewingSavedLook(true); setWardrobe((current) => current.map((savedItem) => savedItem.id === item.id ? { ...savedItem, unreadTryOn: false, unreadVideo: false } : savedItem)); setStep(STUDIO_STEP); setGarment(item.garmentFront); setGarmentBack(item.garmentBack); setGarmentType(item.type); setGarmentSize(item.size); setTryOnScale(100); setTryOnResult({ imageUrl: item.image, images: savedImages, manifestHash: item.manifestHash, manifestVerified: true, backgroundColors: item.backgroundColors, backgroundGradients: item.backgroundGradients }); void restoreSavedTryOnVideo(item); setBodyView(0); }}>Voir et pivoter</button>
              </article>
              );
            })}</div>
          ) : <div className="empty-wardrobe"><b>Aucun essayage enregistré.</b><span>Essayez un vêtement dans le studio, puis enregistrez le résultat ici.</span></div>}
        </section>
      </main>
    );
  }

  if (step === STUDIO_STEP || (identityCaptureStarted && accountConnected && step >= 1 && step <= 5)) {
    const connectedCaptureMode = identityCaptureStarted && accountConnected && step >= 1 && step <= 5;
    const activeView = bodyRotation[bodyView];
    const activeGuide = photoGuides.find((photo) => photo.key === activeView.key);
    const defaultAvatarImage = activeGuide ? defaultPhotoFor(activeGuide.example, profile.gender) : "";
    const activeAvatarImage = tryOnResult?.images?.[activeView.key]
      || baseAvatarImages[activeView.key]
      || photos[activeView.key]
      || defaultAvatarImage;
    const activeAvatarScale = tryOnResult ? tryOnScale : avatarScale;
    const activeBackgroundColor = tryOnResult?.backgroundColors?.[activeView.key]
      || avatarBackgroundColors[activeView.key]
      || "#e8e5dc";
    const activeBackgroundGradient = tryOnResult?.backgroundGradients?.[activeView.key]
      || avatarBackgroundGradients[activeView.key];
    const activeBackgroundStyle = activeBackgroundGradient
      ? `linear-gradient(to bottom, ${activeBackgroundGradient.top}, ${activeBackgroundGradient.bottom})`
      : "none";
    const videoBackgroundColor = tryOnVideoBackgroundColor || tryOnResult?.backgroundColors?.bodyFront || activeBackgroundColor;
    const activeDownloadKey = downloadViewKeys[bodyView] || "front";
    const activeDownloadCooldown = Number(downloadCooldowns[activeDownloadKey]) || 0;
    const activeDownloadError = downloadErrors[activeDownloadKey] || "";
    const hasPersonalPhotos = photoGuides.some((photo) => photos[photo.key]?.startsWith("data:image/"));
    const shouldMirrorProfile = activeView.key === "bodyRight" && activeView.label === "Profil gauche";
    const rotate = (direction: number) => setBodyView((current) => (current + direction + bodyRotation.length) % bodyRotation.length);
    const dashboardAvatar = avatarLibrary.find((avatar) => avatar.id === activeAvatarId)
      || (!usesDefaultAvatar ? avatarLibrary.find((avatar) => avatar.images.bodyFront === baseAvatarImages.bodyFront) : undefined);
    const dashboardGender = dashboardAvatar?.gender || (profile.gender === "homme" ? "homme" : "femme");
    const dashboardName = dashboardAvatar?.label || (dashboardGender === "homme" ? "Koffi Smart" : "Awa Smart");
    const dashboardPhoto = dashboardAvatar?.images.bodyFront || baseAvatarImages.bodyFront || defaultPhotoFor("/pose-examples/body-front.webp", dashboardGender);
    const dashboardMeasurements = dashboardAvatar?.measurements || defaultMeasurements[dashboardGender];
    const recentStudioLooks = [...wardrobe].reverse();
    const showDashboardLook = (item: WardrobeItem, tryOnNumber: number) => {
      const savedImages = item.images || { bodyFront: item.image };
      warmAvatarImageCache(savedImages);
      setTryOnOpen(false);
      setPendingShopProduct(null);
      localStorage.removeItem("smartmirror-pending-product");
      setSelectedTryOnNumber(tryOnNumber);
      setViewingSavedLook(true);
      setWardrobe((current) => current.map((savedItem) => savedItem.id === item.id ? { ...savedItem, unreadTryOn: false, unreadVideo: false } : savedItem));
      setGarment(item.garmentFront);
      setGarmentBack(item.garmentBack);
      setGarmentType(item.type);
      setGarmentSize(item.size);
      setTryOnScale(100);
      setTryOnResult({
        imageUrl: item.image,
        images: savedImages,
        manifestHash: item.manifestHash,
        manifestVerified: true,
        backgroundColors: item.backgroundColors,
        backgroundGradients: item.backgroundGradients,
      });
      void restoreSavedTryOnVideo(item);
      setBodyView(0);
    };
    return (
      <main className="wardrobe-shell">
        {(tryOnGenerating || tryOnVideoGenerating || avatarVideoGenerating || completionNotice) && <aside className="background-task-notice" role="status"><strong>{completionNotice || (avatarVideoGenerating ? `Création de la présentation ${avatarVideoProgress}%` : tryOnVideoGenerating ? `Création de la vidéo ${tryOnVideoProgress}%` : `Création de l’essayage ${tryOnProgress}%`)}</strong>{!completionNotice && <span>Vous pouvez continuer à utiliser SMART MIRROR.</span>}</aside>}
        {viewingSavedLook && tryOnResult ? (
          <TryOnDetailHeader
            number={selectedTryOnNumber}
            onBack={() => { setTryOnVideoPlaying(false); setTryOnVideoLoaded(false); setViewingSavedLook(false); setTryOnResult(null); setBodyView(0); setStep(CLOSET_STEP); }}
            onProfile={() => navigateMain(PROFILE_STEP)}
          />
        ) : (
          <header className="wardrobe-header primary-header">
        <MainNavigation active="home" onNavigate={navigateMain} language={language} studioNotifications={studioNotificationCount} />
          </header>
        )}
        <div className="desktop-studio-layout">
          <aside className="desktop-profile-rail">
            <header className="desktop-profile-brand">
              <div>
                <span className="desktop-profile-brand-mark">S</span>
                <p><strong>SMART MIRROR</strong><small>Votre style, de temps en temps.</small></p>
              </div>
              <button className={`desktop-settings-button${desktopSettingsOpen ? " is-open" : ""}`} type="button" aria-label={desktopSettingsOpen ? "Fermer les paramètres" : "Paramètres"} aria-expanded={desktopSettingsOpen} onClick={() => setDesktopSettingsOpen((current) => !current)}>
                {desktopSettingsOpen ? <span aria-hidden="true">×</span> : <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6 1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></svg>}
              </button>
            </header>
            {desktopSettingsOpen ? <section className="desktop-settings-panel">
              <div>
                <span>PARAMÈTRES</span>
                <strong>Langue</strong>
                <button className={language === "fr" ? "selected" : ""} type="button" onClick={() => { localStorage.setItem("smartmirror-language", "fr"); document.documentElement.lang = "fr"; setDesktopSettingsOpen(false); window.location.reload(); }}><span>🇫🇷</span> Français <b>{language === "fr" ? "✓" : ""}</b></button>
                <button className={language === "en" ? "selected" : ""} type="button" onClick={() => { localStorage.setItem("smartmirror-language", "en"); document.documentElement.lang = "en"; setDesktopSettingsOpen(false); window.location.reload(); }}><span>🇬🇧</span> English <b>{language === "en" ? "✓" : ""}</b></button>
                <button className={language === "zh" ? "selected" : ""} type="button" onClick={() => { localStorage.setItem("smartmirror-language", "zh"); document.documentElement.lang = "zh"; setDesktopSettingsOpen(false); window.location.reload(); }}><span>🇨🇳</span> 中文 <b>{language === "zh" ? "✓" : ""}</b></button>
              </div>
                <button className="settings-logout" type="button" onClick={async () => {
                  const disconnected = await disconnectAccount();
                  if (!disconnected) setDesktopSettingsOpen(false);
                }}>
                  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 4H5v16h5" /><path d="M14 8l4 4-4 4M18 12H9" /></svg>
                  {language === "zh" ? "退出登录" : language === "en" ? "Sign out" : "Déconnexion"}
                </button>
            </section> : <>
            <span className="desktop-active-avatar-label">Avatar actuellement utilisé</span>
            <div className="desktop-profile-avatar" style={imageSurfaceStyle(dashboardAvatar?.backgroundColors, dashboardAvatar?.backgroundGradients)}>
              <img src={dashboardPhoto} alt={dashboardName} style={imageSurfaceStyle(dashboardAvatar?.backgroundColors, dashboardAvatar?.backgroundGradients)} />
            </div>
            <h2>{dashboardName}</h2>
            <p>{profile.email || "Compte SMART MIRROR"}</p>
            <button className="desktop-measurements-button" type="button" onClick={() => { setMeasurementDraft(dashboardMeasurements); setMeasurementsOpen(true); }}>Modifier les mensurations</button>
            <section className="desktop-avatar-library">
              <header><strong>Choisir un avatar existant</strong></header>
              <div>
                {[...avatarLibrary]
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                  .map((avatar) => (
                    <button type="button" className={avatar.id === activeAvatarId ? "active" : ""} key={avatar.id} onClick={() => activateDesktopAvatar(avatar)}>
                      <img src={avatar.images.bodyFront || defaultPhotoFor("/pose-examples/body-front.webp", avatar.gender)} alt={avatar.label} style={imageSurfaceStyle(avatar.backgroundColors, avatar.backgroundGradients)} />
                      <span>{avatar.label}</span>
                    </button>
                  ))}
                {(["default-femme", "default-homme"] as const).map((id) => {
                  const gender = id === "default-homme" ? "homme" : "femme";
                  const isActive = usesDefaultAvatar && dashboardGender === gender;
                  return <button type="button" className={isActive ? "active" : ""} key={id} onClick={() => activateDesktopAvatar(id)}>
                    <img src={defaultPhotoFor("/pose-examples/body-front.webp", gender)} alt={`Avatar ${gender} par défaut`} />
                    <span>{gender === "homme" ? "Avatar homme par défaut" : "Avatar femme par défaut"}</span>
                  </button>;
                })}
              </div>
            </section>
            <div className="desktop-create-divider"><strong>Avatar personnalisé</strong><span>{connectedCaptureMode ? "Création actuellement ouverte au centre" : "Utilisez vos photos pour créer une nouvelle identité."}</span></div>
            <button className={`desktop-create-avatar${connectedCaptureMode ? " cancel-mode" : ""}`} disabled={avatarGenerating} type="button" onClick={() => {
              if (connectedCaptureMode) {
                if (recreateBackup) {
                  setPhotos(recreateBackup.photos);
                  setBaseAvatarImages(recreateBackup.images);
                }
                setRecreateBackup(null);
                setIdentityCaptureStarted(false);
                setError("");
                setStep(STUDIO_STEP);
                return;
              }
              setRecreateBackup({ photos, images: baseAvatarImages });
              uploadedIdentityPhotos.current = {};
              identityUploadPromises.current = {};
              setIdentityUploadStatus({});
              setPhotos({});
              setError("");
              setIdentityCaptureStarted(true);
              setStep(1);
            }}>
              {connectedCaptureMode
                ? (language === "zh" ? "取消创建" : language === "en" ? "Cancel creation" : "Annuler la création")
                : avatarGenerating
                ? `Création en cours · ${avatarProgress}%`
                : avatarLibrary.length > 0
                  ? (language === "zh" ? "创建新的虚拟形象" : language === "en" ? "Create a new avatar" : "Créer un nouvel avatar")
                  : (language === "zh" ? "创建我的虚拟形象" : language === "en" ? "Create my avatar" : "Créer mon avatar")}
            </button>
            </>}
          </aside>
          <div className={`desktop-studio-center${connectedCaptureMode ? " connected-capture-mode" : ""}`}>
            {connectedCaptureMode && currentPhotoStep && currentPhotoGuide && (
              <section className="connected-face-capture">
                <header>
                  <div className="connected-capture-progress-label"><span>CRÉEZ VOTRE IDENTITÉ</span><b>Étape {step} sur 5</b></div>
                  <div className="connected-capture-progress"><i style={{ width: `${Math.max(20, step * 20)}%` }} /></div>
                  <h1>{currentPhotoStep.title}</h1>
                  <p>{currentPhotoStep.utility}</p>
                </header>
                <div className={`single-photo-stage ${photos[currentPhotoStep.key] ? "complete" : ""}`}>
                  <input id={`connected-camera-${currentPhotoStep.key}`} type="file" accept="image/*" capture="user" onChange={(event) => onIdentityPhoto(currentPhotoStep.key, event)} />
                  <input id={`connected-import-${currentPhotoStep.key}`} type="file" accept="image/*" onChange={(event) => onIdentityPhoto(currentPhotoStep.key, event)} />
                  <img
                    className={profile.gender === "femme" && !photos[currentPhotoStep.key] ? "face-example-female" : undefined}
                    src={photos[currentPhotoStep.key] || defaultPhotoFor(currentPhotoGuide.example, profile.gender)}
                    alt={photos[currentPhotoStep.key] ? currentPhotoGuide.label : `Exemple : ${currentPhotoGuide.label}`}
                  />
                  <div className="single-photo-caption">
                    <strong>{currentPhotoGuide.label}</strong>
                    <span>{photos[currentPhotoStep.key] ? "Photo ajoutée ✓" : `${currentPhotoGuide.hint} · Facultatif`}</span>
                  </div>
                  <div className="shot-actions">
                    <label htmlFor={`connected-camera-${currentPhotoStep.key}`}>Prendre une photo</label>
                    <label htmlFor={`connected-import-${currentPhotoStep.key}`}>Importer</label>
                  </div>
                </div>
              </section>
            )}
            {connectedCaptureMode && step === 5 && (
              <section className="connected-face-capture connected-avatar-review">
                <header>
                  <div className="connected-capture-progress-label"><span>VOTRE IDENTITÉ</span><b>Étape 5 sur 5</b></div>
                  <div className="connected-capture-progress"><i style={{ width: "100%" }} /></div>
                  <h1>Tout est prêt.</h1>
                  <p>Vérifiez vos photos avant de générer votre avatar personnel.</p>
                </header>
                <div className="connected-review-grid">
                  {photoGuides.map((photo) => (
                    <button type="button" key={photo.key} onClick={() => setStep(onboardingPhotoSteps.find((item) => item.key === photo.key)?.step || 1)}>
                      <img src={photos[photo.key] || defaultPhotoFor(photo.example, profile.gender)} alt={photo.label} />
                      <span>{photo.label}</span>
                      <small>{photos[photo.key] ? "Ajoutée" : "Modèle par défaut"}</small>
                    </button>
                  ))}
                </div>
                <div className="connected-review-actions">
                  <button type="button" className="secondary" disabled={avatarGenerating} onClick={() => setStep(4)}>Retour</button>
                  <button type="button" disabled={avatarGenerating} onClick={() => void generateBaseAvatar()}>{avatarGenerating ? "Génération en cours…" : "Générer mon avatar"}</button>
                </div>
              </section>
            )}
            {tryOnResult && !viewingSavedLook && <button className="close-center-look" type="button" onClick={() => { setViewingSavedLook(false); setTryOnResult(null); if (!tryOnVideoGenerating) { setTryOnVideoUrl(""); setTryOnVideoTaskId(""); setTryOnVideoProgress(0); } setTryOnVideoPlaying(false); setBodyView(0); }}>Fermer l’essai</button>}
        <section className={`body-viewer${tryOnVideoPlaying || avatarVideoPlaying ? " video-playing" : ""}`} style={{ backgroundColor: tryOnVideoPlaying ? videoBackgroundColor : avatarVideoPlaying ? (avatarVideoBackgroundColor || activeBackgroundColor) : activeBackgroundColor, backgroundImage: tryOnVideoPlaying || avatarVideoPlaying ? "none" : activeBackgroundStyle }}>
          {tryOnResult && <button
            className={`tryon-video-button${tryOnVideoPlaying ? " is-closing" : tryOnVideoUrl ? " is-ready" : tryOnVideoGenerating ? " is-generating" : ""}`}
            type="button"
            disabled={tryOnVideoGenerating}
            onClick={() => {
              if (tryOnVideoPlaying) return setTryOnVideoPlaying(false);
              if (tryOnVideoUrl) return startTryOnVideoPlayback();
              void createTryOnVideo();
            }}
          >
            {tryOnVideoPlaying ? "Fermer" : tryOnVideoUrl ? "Regarder" : tryOnVideoGenerating ? `Création ${tryOnVideoProgress}%` : "Créer une vidéo"}
          </button>}
          {!tryOnResult && <button
            className={`tryon-video-button avatar-presentation-button${avatarVideoPlaying ? " is-closing" : avatarVideoUrl ? " is-ready" : avatarVideoGenerating ? " is-generating" : ""}`}
            type="button"
            disabled={avatarVideoGenerating}
            onClick={() => {
              if (avatarVideoPlaying) { setAvatarVideoPlaying(false); setAvatarVideoLoaded(false); return; }
              if (avatarVideoUrl) { setAvatarVideoMuted(false); setAvatarVideoLoaded(false); setAvatarVideoPlaying(true); return; }
              void createAvatarPresentationVideo();
            }}
          >{avatarVideoPlaying ? "Fermer" : avatarVideoUrl ? "Regarder" : avatarVideoGenerating ? `Création ${avatarVideoProgress}%` : avatarVideoTaskId ? "Reprendre la création" : "Créer une vidéo de présentation"}</button>}
          {tryOnVideoPlaying && <button className={`tryon-audio-toggle${tryOnAudioMuted ? " is-muted" : ""}`} type="button" aria-label={tryOnAudioMuted ? "Activer le son" : "Couper le son"} onClick={toggleTryOnVideoAudio}>
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4Z" /><path d="M16 9c1.2 1.1 1.2 4.9 0 6" />{tryOnAudioMuted && <path className="mute-slash" d="M3 3l18 18" />}</svg>
          </button>}
          {avatarVideoPlaying && <button className={`tryon-audio-toggle${avatarVideoMuted ? " is-muted" : ""}`} type="button" aria-label={avatarVideoMuted ? "Activer le son" : "Couper le son"} onClick={() => { const muted = !avatarVideoMuted; setAvatarVideoMuted(muted); if (avatarVideoRef.current) avatarVideoRef.current.muted = displayingDefaultAvatar || muted; if (avatarAudioRef.current) avatarAudioRef.current.muted = muted; }}>
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4Z" /><path d="M16 9c1.2 1.1 1.2 4.9 0 6" />{avatarVideoMuted && <path className="mute-slash" d="M3 3l18 18" />}</svg>
          </button>}
          {!tryOnVideoPlaying && !avatarVideoPlaying && <button className="rotate-control rotate-left" type="button" aria-label="Pivoter vers la gauche" onClick={() => rotate(-1)}>←</button>}
          <div className={`body-frame zoom-${bodyZoom}${tryOnResult ? " showing-tryon" : ""}${shouldMirrorProfile ? " mirrored" : ""}`} style={{ backgroundColor: tryOnVideoPlaying ? videoBackgroundColor : avatarVideoPlaying ? (avatarVideoBackgroundColor || activeBackgroundColor) : activeBackgroundColor, backgroundImage: tryOnVideoPlaying || avatarVideoPlaying ? "none" : activeBackgroundStyle }}>
            {avatarVideoPlaying && avatarVideoUrl ? <video
              ref={avatarVideoRef}
              className="tryon-result-video avatar-presentation-video"
              src={avatarVideoUrl}
              autoPlay
              muted={displayingDefaultAvatar || avatarVideoMuted}
              playsInline
              preload="auto"
              data-has-audio={avatarVideoHasAudio ? "true" : "false"}
              aria-label="Vidéo de présentation de l’avatar"
              onLoadStart={() => setAvatarVideoLoaded(false)}
              onWaiting={(event) => {
                if (event.currentTarget.dataset.loopReset !== "1") setAvatarVideoLoaded(false);
              }}
              onCanPlay={(event) => { event.currentTarget.muted = displayingDefaultAvatar || avatarVideoMuted; }}
              onPlaying={(event) => { event.currentTarget.muted = displayingDefaultAvatar || avatarVideoMuted; setAvatarVideoLoaded(true); }}
              onLoadedMetadata={(event) => {
                const video = event.currentTarget;
                video.dataset.loopReset = "1";
                video.currentTime = Math.min(0.4, video.duration / 10);
              }}
              onTimeUpdate={(event) => {
                const video = event.currentTarget;
                if (video.duration > 0 && video.currentTime >= video.duration - 0.45 && video.dataset.loopReset !== "1") {
                  video.dataset.loopReset = "1";
                  video.currentTime = Math.min(0.4, video.duration / 10);
                }
              }}
              onSeeked={(event) => {
                const video = event.currentTarget;
                if (video.dataset.loopReset !== "1") return;
                void video.play();
                setAvatarVideoLoaded(true);
                delete video.dataset.loopReset;
              }}
              onEnded={(event) => {
                const video = event.currentTarget;
                video.dataset.loopReset = "1";
                video.currentTime = Math.min(0.4, video.duration / 10);
              }}
            /> : tryOnVideoPlaying && tryOnVideoUrl ? <><video
              ref={tryOnVideoRef}
              className="tryon-result-video"
              src={tryOnVideoUrl}
              autoPlay
              muted={tryOnAudioMuted}
              playsInline
              preload="auto"
              aria-label="Vidéo de l’essayage"
              onLoadStart={() => setTryOnVideoLoaded(false)}
              onWaiting={() => setTryOnVideoLoaded(false)}
              onCanPlay={(event) => { event.currentTarget.muted = tryOnAudioMuted; }}
              onPlaying={(event) => { event.currentTarget.muted = tryOnAudioMuted; setTryOnVideoLoaded(true); }}
              onLoadedMetadata={(event) => {
                const video = event.currentTarget;
                video.dataset.loopReset = "1";
                video.style.visibility = "hidden";
                video.currentTime = Math.min(0.4, video.duration / 10);
              }}
              onTimeUpdate={(event) => {
                const video = event.currentTarget;
                if (video.duration > 0 && video.currentTime >= video.duration - 0.45 && video.dataset.loopReset !== "1") {
                  video.dataset.loopReset = "1";
                  video.style.visibility = "hidden";
                  video.currentTime = Math.min(0.4, video.duration / 10);
                }
              }}
              onSeeked={(event) => {
                const video = event.currentTarget;
                if (video.dataset.loopReset !== "1") return;
                void video.play();
                requestAnimationFrame(() => requestAnimationFrame(() => {
                  video.style.visibility = "visible";
                  setTryOnVideoLoaded(true);
                  delete video.dataset.loopReset;
                }));
              }}
              onEnded={(event) => {
                const video = event.currentTarget;
                video.dataset.loopReset = "1";
                video.style.visibility = "hidden";
                video.currentTime = Math.min(0.4, video.duration / 10);
              }}
            />{!tryOnVideoHasAudio && tryOnAudioTrack && <audio className="tryon-result-audio" src={tryOnAudioTrack} autoPlay loop muted={tryOnAudioMuted} preload="auto" aria-hidden="true" />}</> : activeAvatarImage ? <img key={`${activeView.key}-${activeView.label}`} src={activeAvatarImage} alt={activeView.label} loading="eager" decoding="async" fetchPriority="high" onLoad={() => setLoadedImageUrls((current) => ({ ...current, [activeAvatarImage]: true }))} style={{ "--avatar-scale": activeAvatarScale / 100, backgroundColor: activeBackgroundColor } as React.CSSProperties} /> : <div className="body-placeholder">Photo indisponible</div>}
            {avatarVideoPlaying && displayingDefaultAvatar && <audio ref={avatarAudioRef} className="tryon-result-audio" src={DEFAULT_AVATAR_AUDIO_TRACKS[profile.gender === "homme" ? "homme" : "femme"]} autoPlay loop muted={avatarVideoMuted} preload="auto" aria-hidden="true" />}
            {tryOnVideoPlaying && !tryOnVideoLoaded && <div className="video-loading-indicator" role="status"><i /><strong>Chargement de la vidéo…</strong><span>Votre essayage arrive.</span></div>}
            {avatarVideoPlaying && !avatarVideoLoaded && <div className="video-loading-indicator" role="status"><i /><strong>Chargement de la présentation…</strong><span>Votre avatar se prépare.</span></div>}
            {!tryOnVideoPlaying && !avatarVideoPlaying && activeAvatarImage && !loadedImageUrls[activeAvatarImage] && <div className="image-loading-indicator" role="status"><i /><span>Chargement de la vue…</span></div>}
            {!tryOnVideoPlaying && !avatarVideoPlaying && <span>{activeView.label}</span>}
            {youcamReady && <small className="youcam-badge">Visage et teint analysés par YouCam</small>}
          </div>
          {!tryOnVideoPlaying && !avatarVideoPlaying && <button className="rotate-control rotate-right" type="button" aria-label="Pivoter vers la droite" onClick={() => rotate(1)}>→</button>}
          {!tryOnVideoPlaying && !avatarVideoPlaying && <div className="scale-controls" aria-label="Taille de l’avatar">
            <button type="button" onClick={() => { setBodyZoom("full"); tryOnResult ? setTryOnScale((value) => Math.min(150, value + 10)) : setAvatarScale((value) => Math.min(150, value + 10)); }} disabled={activeAvatarScale >= 150} aria-label="Agrandir l’avatar">+</button>
            <span>{activeAvatarScale}%</span>
            <button type="button" onClick={() => { setBodyZoom("full"); tryOnResult ? setTryOnScale((value) => Math.max(70, value - 10)) : setAvatarScale((value) => Math.max(70, value - 10)); }} disabled={activeAvatarScale <= 70} aria-label="Réduire l’avatar">−</button>
          </div>}
          {!tryOnVideoPlaying && !avatarVideoPlaying && <div className="zoom-controls">
            <button type="button" className={bodyZoom === "top" ? "active" : ""} onClick={() => setBodyZoom(bodyZoom === "top" ? "full" : "top")} aria-label="Zoomer sur le haut">↑<small>HAUT</small></button>
            <button type="button" className={bodyZoom === "bottom" ? "active" : ""} onClick={() => setBodyZoom(bodyZoom === "bottom" ? "full" : "bottom")} aria-label="Zoomer sur le bas">↓<small>BAS</small></button>
          </div>}
          {(tryOnGenerating || (avatarGenerating && avatarPendingViews.includes(activeView.key))) && (
            <div
              className="tryon-creation-indicator"
              role="status"
              aria-label={avatarGenerating ? "Création de l’avatar en cours" : "Création de l’essayage en cours"}
            >
              <i />
              <i />
              <i />
            </div>
          )}
        </section>
        {false && <section className="wardrobe-actions">
          {hasPersonalPhotos && !youcamReady && (
            <button className="youcam-action" disabled={avatarGenerating} onClick={() => {
              baseAvatarAttempted.current = true;
              void generateBaseAvatar();
            }}><b>Y</b><span>{avatarGenerating ? "Analyse YouCam en cours…" : "Analyser mon visage avec YouCam"}</span></button>
          )}
          <button onClick={() => { setTryOnOpen(true); setTryOnResult(null); setGarmentBack(""); garmentInput.current?.click(); }}><b>+</b><span>Ajouter un vêtement</span></button>
          <button onClick={() => { setTryOnOpen(true); setTryOnResult(null); setGarmentBack(""); garmentInput.current?.click(); }}><b>◎</b><span>Essayer un vêtement</span></button>
          <input ref={garmentInput} hidden type="file" accept="image/*" onChange={onGarment} />
          <input ref={garmentBackInput} hidden type="file" accept="image/*" onChange={onGarmentBack} />
        </section>}
        {false && garment && (
          <section className="wardrobe-editor">
            <div className="garment-photo-pair">
              <button type="button" onClick={() => garmentInput.current?.click()}>
                <img src={garment} alt="Recto du vêtement" />
                <span>RECTO ✓</span>
              </button>
              <button type="button" className={!garmentBack ? "missing" : ""} onClick={() => garmentBackInput.current?.click()}>
                {garmentBack ? <img src={garmentBack} alt="Verso du vêtement" /> : <b>+</b>}
                <span>{garmentBack ? "VERSO ✓" : "VERSO (FACULTATIF)"}</span>
              </button>
            </div>
            <div>
              <span className="journey-kicker">{tryOnOpen ? "ESSAYAGE" : "NOUVEL ARTICLE"}</span>
              <div className="auto-detection-note">
                <b>Reconnaissance automatique</b>
                <span>L’IA identifiera seule le vêtement ou l’ensemble présent sur vos photos.</span>
                <small>Vos tailles : haut {profile.topSize} · pantalon {profile.pantsSize} · chaussures {profile.shoeSize}</small>
                <small>Taille du vêtement essayé : <b>{garmentSize}</b></small>
              </div>
              {tryOnOpen && <button className="ai-try-button connected" disabled={tryOnGenerating} onClick={generateTryOn}>{tryOnGenerating ? "Genblaze crée votre essayage…" : "Générer « Voir sur moi »"}</button>}
              {tryOnResult && <div className="tryon-result"><img src={tryOnResult.imageUrl} alt="Essayage généré par SMART MIRROR" /><span>Rendu enregistré automatiquement · Genblaze · B2 · Manifest {tryOnResult.manifestVerified ? "vérifié" : "créé"}</span></div>}
            </div>
          </section>
        )}
        <section className="single-tryon-action">
          {viewingSavedLook && tryOnResult ? <><button disabled={lookDownloading || (!tryOnVideoPlaying && activeDownloadCooldown > 0)} onClick={tryOnVideoPlaying ? downloadSavedVideo : downloadSavedLook}>{lookDownloading ? (tryOnVideoPlaying ? "Préparation de la vidéo…" : "Préparation de la vue…") : !tryOnVideoPlaying && activeDownloadCooldown > 0 ? `Téléchargement lancé · ${activeDownloadCooldown} s` : tryOnVideoPlaying ? "Télécharger cette vidéo dans ma galerie" : "Télécharger cette vue dans ma galerie"}</button>{activeDownloadError && <p className="studio-error" role="alert">{activeDownloadError}</p>}</> : avatarGenerating ? (
            <button className="tryon-action-progress" type="button" disabled aria-live="polite">
              <span>
                <i aria-hidden="true" />
                {avatarGenerationMode === "recreate" ? "Votre avatar se recrée" : "Votre avatar prend forme"}
                <b>{avatarProgress}%</b>
              </span>
              <small><i style={{ width: `${avatarProgress}%` }} /></small>
            </button>
          ) : tryOnGenerating ? (
            <button className="tryon-action-progress" type="button" disabled aria-live="polite">
              <span><i aria-hidden="true" />Votre essayage prend forme <b>{tryOnProgress}%</b></span>
              <small><i style={{ width: `${tryOnProgress}%` }} /></small>
            </button>
          ) : <button onClick={() => {
            setViewingSavedLook(false);
            setTryOnOpen(true);
            setTryOnResult(null);
            setGarment("");
            setGarmentBack("");
            setGarmentType("auto");
            setGarmentSize("AUTO");
            setTryOnProgress(0);
          }}>Essayer un vêtement</button>}
        </section>
          </div>
          <aside className="desktop-studio-rail">
            <header className="desktop-panel-header">
              <strong>{desktopRailView === "studio" ? "STUDIO" : "BOUTIQUE"}</strong>
              <span><button type="button" onClick={() => setDesktopRailView((current) => current === "studio" ? "shop" : "studio")}>{desktopRailView === "studio" ? "Boutique" : "Studio"}</button></span>
            </header>
            {desktopRailView === "studio" ? <>{recentStudioLooks.length ? <div className="desktop-recent-looks">
              {recentStudioLooks.map((item, index) => (
                <article className={viewingSavedLook && selectedTryOnNumber === wardrobe.length - index ? "selected" : ""} key={item.id}>
                  {(item.unreadTryOn || item.unreadVideo) && <b className="studio-new-badge">{item.unreadVideo ? "NOUVELLE VIDÉO" : "NOUVEL ESSAI"}</b>}
                  <span style={imageSurfaceStyle(item.backgroundColors, item.backgroundGradients)}>
                    <img src={item.image} alt={item.name} loading="lazy" decoding="async" style={imageSurfaceStyle(item.backgroundColors, item.backgroundGradients)} />
                  </span>
                  <small>ESSAI N° {wardrobe.length - index}</small>
                  <strong>{item.name}</strong>
                  <button
                    className={viewingSavedLook && selectedTryOnNumber === wardrobe.length - index ? "studio-card-close" : ""}
                    type="button"
                    onClick={() => {
                      if (viewingSavedLook && selectedTryOnNumber === wardrobe.length - index) {
                        setTryOnVideoPlaying(false);
                        setTryOnVideoLoaded(false);
                        setViewingSavedLook(false);
                        setTryOnResult(null);
                        setBodyView(0);
                      } else {
                        showDashboardLook(item, wardrobe.length - index);
                      }
                    }}
                  >{viewingSavedLook && selectedTryOnNumber === wardrobe.length - index ? "Fermer" : "Voir et pivoter"}</button>
                </article>
              ))}
            </div> : <p className="desktop-empty-studio">Vos prochains essayages apparaîtront ici.</p>}
            <button className="desktop-open-studio" type="button" onClick={() => navigateMain(CLOSET_STEP)}>Voir tous les articles du Studio</button></> : <>
              <div className="desktop-shop-products">
                {shopProducts.map((product) => (
                  <article key={product.id}>
                    <div className="desktop-shop-image"><img src={product.image} alt={product.name} /></div>
                    <small>{product.type}</small>
                    <strong>{product.name}</strong>
                    <b>{product.price}</b>
                    <div className="desktop-shop-buy-row">
                      <select aria-label={`Choisir la taille de ${product.name}`} value={shopSelectedSizes[product.id] || defaultSize(product.type)} onChange={(event) => setShopSelectedSizes((current) => ({ ...current, [product.id]: event.target.value }))}>{availableShopSizes(product.type).map((size) => <option key={size}>{size}</option>)}</select>
                      <button type="button">Acheter</button>
                    </div>
                    <button type="button" onClick={() => void selectShopProduct(product)}>Voir sur moi</button>
                  </article>
                ))}
              </div>
              <button className="desktop-open-studio" type="button" onClick={() => navigateMain(SHOP_STEP)}>Voir tous les articles de la Boutique</button>
            </>}
          </aside>
        </div>
        {measurementsOpen && (
          <div className="measurements-backdrop" role="presentation" onClick={() => setMeasurementsOpen(false)}>
            <section className="measurements-sheet" role="dialog" aria-modal="true" aria-label="Modifier les données de mensuration" onClick={(event) => event.stopPropagation()}>
              <div className="measurements-sheet-handle" />
              <h2>Mensurations de {dashboardName}</h2>
              <p>Ces données seront utilisées pour les prochains essayages de cet avatar.</p>
              <div className="measurements-grid">
                <label><span>Taille</span><select value={measurementDraft.height} onChange={(e) => setMeasurementDraft((current) => ({ ...current, height: Number(e.target.value) }))}>{Array.from({ length: 71 }, (_, i) => 140 + i).map((value) => <option key={value} value={value}>{value} cm</option>)}</select></label>
                <label><span>Chemise / haut</span><select value={measurementDraft.topSize} onChange={(e) => setMeasurementDraft((current) => ({ ...current, topSize: e.target.value }))}>{["XS", "S", "M", "L", "XL", "XXL", "3XL+"].map((value) => <option key={value}>{value}</option>)}</select></label>
                <label><span>Pantalon</span><select value={measurementDraft.pantsSize} onChange={(e) => setMeasurementDraft((current) => ({ ...current, pantsSize: e.target.value }))}>{Array.from({ length: 17 }, (_, i) => String(32 + i * 2)).map((value) => <option key={value}>{value}</option>)}</select></label>
                <label><span>Pointure</span><select value={measurementDraft.shoeSize} onChange={(e) => setMeasurementDraft((current) => ({ ...current, shoeSize: e.target.value }))}>{Array.from({ length: 20 }, (_, i) => String(33 + i)).map((value) => <option key={value}>{value}</option>)}</select></label>
              </div>
              <button type="button" onClick={() => {
                setProfile((current) => ({ ...current, ...measurementDraft }));
                if (dashboardAvatar) {
                  const updated = avatarLibrary.map((avatar) => avatar.id === dashboardAvatar.id ? { ...avatar, measurements: measurementDraft } : avatar);
                  setAvatarLibrary(updated);
                  localStorage.setItem("smartmirror-avatar-library", JSON.stringify(updated));
                } else {
                  const updatedDefaults = { ...defaultMeasurements, [dashboardGender]: measurementDraft };
                  setDefaultMeasurements(updatedDefaults);
                  localStorage.setItem("smartmirror-default-avatar-measurements", JSON.stringify(updatedDefaults));
                }
                localStorage.setItem("smartmirror-profile", JSON.stringify({ ...profile, ...measurementDraft, usesDefaultAvatar: !dashboardAvatar }));
                setMeasurementsOpen(false);
                setProfileSaveStatus("Mensurations enregistrées ✓");
              }}>Enregistrer les mensurations</button>
            </section>
          </div>
        )}
        <input ref={garmentInput} hidden type="file" accept="image/*" onChange={onGarment} />
        <input ref={garmentCameraInput} hidden type="file" accept="image/*" capture="environment" onChange={onGarment} />
        <input ref={garmentBackInput} hidden type="file" accept="image/*" onChange={onGarmentBack} />
        <input ref={garmentBackCameraInput} hidden type="file" accept="image/*" capture="environment" onChange={onGarmentBack} />
        {tryOnOpen && (
          <div className="tryon-modal-backdrop" role="presentation" onMouseDown={(event) => {
            if (event.target === event.currentTarget) setTryOnOpen(false);
          }}>
            <section className="tryon-modal" role="dialog" aria-modal="true" aria-labelledby="tryon-modal-title">
              <div className="tryon-modal-header">
                <div><span>ESSAYAGE</span><h2 id="tryon-modal-title">Choisissez votre vêtement</h2></div>
                <button type="button" aria-label="Fermer" onClick={() => setTryOnOpen(false)}>×</button>
              </div>
              <div className="garment-photo-pair">
                <div className="garment-import-card required">
                  <button type="button" className="garment-gallery-zone" onClick={() => garmentInput.current?.click()}>
                    {garment ? <img src={garment} alt="Recto du vêtement" /> : <><b aria-hidden="true">+</b><span>Importer une photo recto (obligatoire)</span></>}
                  </button>
                  <button type="button" className="garment-camera-action" onClick={() => garmentCameraInput.current?.click()}>
                    <svg viewBox="0 0 24 20" aria-hidden="true"><path d="M2 6h4l2-3h8l2 3h4v12H2Z" /><circle cx="12" cy="12" r="4" /></svg>
                    Utiliser la caméra
                  </button>
                </div>
                <div className="garment-import-card optional">
                  <button type="button" className="garment-gallery-zone" onClick={() => garmentBackInput.current?.click()}>
                    {garmentBack ? <img src={garmentBack} alt="Verso du vêtement" /> : <><b aria-hidden="true">+</b><span>Importer une photo verso (facultative)</span></>}
                  </button>
                  <button type="button" className="garment-camera-action" onClick={() => garmentBackCameraInput.current?.click()}>
                    <svg viewBox="0 0 24 20" aria-hidden="true"><path d="M2 6h4l2-3h8l2 3h4v12H2Z" /><circle cx="12" cy="12" r="4" /></svg>
                    Utiliser la caméra
                  </button>
                </div>
              </div>
              <label className="imported-garment-size">
                <span>Taille du vêtement</span>
                <select value={garmentSize} onChange={(event) => setGarmentSize(event.target.value)}>
                  <option value="AUTO">Ma taille — automatique</option>
                  <optgroup label="Tailles internationales">
                    {[
                      "XXS", "XS", "S", "M", "L", "XL", "XXL", "3XL", "4XL", "5XL",
                    ].map((size) => <option key={size} value={size}>{size}</option>)}
                  </optgroup>
                  <optgroup label="Tailles européennes">
                    {Array.from({ length: 21 }, (_, index) => String(32 + index)).map((size) => <option key={`eu-${size}`} value={size}>{size}</option>)}
                  </optgroup>
                </select>
                <small>Sans modification, SMART MIRROR utilisera votre taille correspondant au vêtement détecté.</small>
              </label>
              <div className="auto-detection-note">
                <b>Reconnaissance automatique</b>
                <span>L’IA identifiera seule le vêtement ou l’ensemble présent sur vos photos.</span>
                <small>Vos tailles : haut {profile.topSize} · pantalon {profile.pantsSize} · chaussures {profile.shoeSize}</small>
                <small>Taille du vêtement essayé : <b>{garmentSize === "AUTO" ? "votre taille (automatique)" : garmentSize}</b></small>
              </div>
              <button className="ai-try-button connected" disabled={!garment || tryOnGenerating} onClick={startTryOnFromSheet}>
                Lancer l’essayage
              </button>
              {error && <p className="tryon-error" role="alert">{error}</p>}
            </section>
          </div>
        )}
        {error && !tryOnOpen && <p className="studio-error" role="alert">{error}</p>}
      </main>
    );
  }

  return (
    <main className={`journey-shell ${step === 1 ? "onboarding-home-shell" : ""}`}>
      {(tryOnGenerating || tryOnVideoGenerating || avatarVideoGenerating || completionNotice) && <aside className="background-task-notice" role="status"><strong>{completionNotice || (avatarVideoGenerating ? `Création de la présentation ${avatarVideoProgress}%` : tryOnVideoGenerating ? `Création de la vidéo ${tryOnVideoProgress}%` : `Création de l’essayage ${tryOnProgress}%`)}</strong>{!completionNotice && <span>Vous pouvez continuer à utiliser SMART MIRROR.</span>}</aside>}
      <header className="journey-topbar">
        {recreateBackup ? (
          <button className="journey-cancel-recreation" type="button" onClick={() => {
            setPhotos(recreateBackup.photos);
            setBaseAvatarImages(recreateBackup.images);
            setRecreateBackup(null);
            setError("");
            setStep(PROFILE_STEP);
          }}>← Retour au profil</button>
        ) : step === 1 && identityCaptureStarted ? (
          <button className="journey-cancel-recreation" type="button" onClick={() => setIdentityCaptureStarted(false)}>← Retour</button>
        ) : <Logo />}
        {step === 1 && !accountConnected ? (
          <button className="public-settings-trigger mobile" type="button" aria-label="Paramètres" onClick={() => setPublicSettingsOpen(true)}>
            <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6 1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></svg>
          </button>
        ) : <span className="journey-step">{Math.min(step, 5)}/5</span>}
      </header>
      <div className="journey-progress"><i style={{ width: `${progress}%` }} /></div>

      <section className={`journey-content step-${step}`}>
        {currentPhotoStep && currentPhotoGuide && (
          <div className={`journey-card photo-step-card ${step === 1 ? "onboarding-home-split" : ""}`}>
            {step === 1 && (
              <header className="onboarding-brand">
                <span>S</span>
                <p><strong>SMART MIRROR</strong><small>Votre style, de temps en temps.</small></p>
                <button className="public-settings-trigger desktop" type="button" aria-label="Paramètres" onClick={() => setPublicSettingsOpen(true)}>
                  <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6 1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></svg>
                </button>
              </header>
            )}
            <span className="journey-kicker">{step === 1 ? "CRÉEZ VOTRE IDENTITÉ" : "VOTRE IDENTITÉ"}</span>
            <h1>{currentPhotoStep.title}</h1>
            <p className="journey-lead">{currentPhotoStep.utility}</p>
            {step === 1 && (
              <div className="start-gender">
                <span>Votre genre</span>
                <div className="gender-choice" role="group" aria-label="Genre">
                  <button type="button" className={profile.gender === "femme" ? "selected" : ""} onClick={() => updateProfile("gender", "femme")}>Femme</button>
                  <button type="button" className={profile.gender === "homme" ? "selected" : ""} onClick={() => updateProfile("gender", "homme")}>Homme</button>
                </div>
                <button className="onboarding-create-avatar" type="button" onClick={() => requireAuthentication("create")}>
                  {language === "zh" ? "创建我的虚拟形象" : language === "en" ? "Create my avatar" : "Créer mon avatar"}
                </button>
              </div>
            )}
            <div className={`single-photo-stage ${photos[currentPhotoStep.key] ? "complete" : ""}`}>
              <input id={`camera-${currentPhotoStep.key}`} type="file" accept="image/*" capture={currentPhotoGuide.kind === "face" ? "user" : "environment"} onChange={(event) => onIdentityPhoto(currentPhotoStep.key, event)} />
              <input id={`import-${currentPhotoStep.key}`} type="file" accept="image/*" onChange={(event) => onIdentityPhoto(currentPhotoStep.key, event)} />
              <img
                className={step === 1 && identityCaptureStarted && profile.gender === "femme" && !photos[currentPhotoStep.key] ? "face-example-female" : undefined}
                src={photos[currentPhotoStep.key] || defaultPhotoFor(step === 1 && !identityCaptureStarted ? "/pose-examples/body-front.webp" : currentPhotoGuide.example, profile.gender)}
                alt={photos[currentPhotoStep.key] ? currentPhotoGuide.label : `Exemple : ${currentPhotoGuide.label}`}
              />
              <div className="single-photo-caption">
                <strong>{currentPhotoGuide.label}</strong>
                <span>{identityUploadStatus[currentPhotoStep.key] === "uploading" ? "Envoi sécurisé en cours…" : identityUploadStatus[currentPhotoStep.key] === "uploaded" ? "Photo envoyée ✓" : identityUploadStatus[currentPhotoStep.key] === "error" ? "Photo prête · l’envoi sera retenté" : photos[currentPhotoStep.key] ? "Photo ajoutée ✓" : `${currentPhotoGuide.hint} · Facultatif`}</span>
              </div>
              {step === 1 && !identityCaptureStarted ? (
                <button className="onboarding-use-default" type="button" onClick={() => requireAuthentication("default")}>
                  {language === "zh" ? "使用默认虚拟形象" : language === "en" ? "Use the default avatar" : "Utiliser l’avatar par défaut"} <Arrow />
                </button>
              ) : (
                <div className="shot-actions">
                  <label htmlFor={`camera-${currentPhotoStep.key}`}>Prendre une photo</label>
                  <label htmlFor={`import-${currentPhotoStep.key}`}>Importer</label>
                </div>
              )}
            </div>
            {step === 1 && !identityCaptureStarted && !photos.faceFront && (
              <p className="skip-explanation">
                {language === "zh"
                  ? `如果不添加照片，我们将直接使用默认${profile.gender === "homme" ? "男性" : "女性"}虚拟形象。`
                  : language === "en"
                    ? `Without a photo, we will use the default ${profile.gender === "homme" ? "male" : "female"} avatar.`
                    : `Sans photo, nous utiliserons directement l’avatar ${profile.gender === "homme" ? "homme" : "femme"} par défaut.`}
              </p>
            )}
            {step === 1 && (
              <aside className="onboarding-shop-preview" aria-label="Aperçu de la boutique">
                <header>
                  <strong>BOUTIQUE</strong>
                  <span>Découvrez votre prochain look</span>
                </header>
                <div>
                  {shopProducts.map((product) => (
                    <article key={product.id}>
                      <img src={product.image} alt={product.name} />
                      <small>{product.type}</small>
                      <strong>{product.name}</strong>
                      <b>{product.price}</b>
                    </article>
                  ))}
                </div>
              </aside>
            )}
          </div>
        )}

        {step === 5 && (
          <div className="journey-card identity-review-card">
            <span className="journey-kicker">VOTRE IDENTITÉ</span>
            <h1>Tout est prêt.</h1>
            <p className="journey-lead">Vérifiez vos photos. Elles serviront à créer votre avatar de référence en sous-vêtement pour tous vos futurs essayages.</p>
            <div className="identity-review-grid">
              {photoGuides.map((photo) => (
                <button type="button" key={photo.key} onClick={() => setStep(onboardingPhotoSteps.find((item) => item.key === photo.key)?.step || 1)}>
                  <img src={photos[photo.key] || defaultPhotoFor(photo.example, profile.gender)} alt={photo.label} />
                  <span>{photo.label}</span>
                  <small>{photos[photo.key] ? "Ajoutée" : "Modèle par défaut"}</small>
                </button>
              ))}
            </div>
            <div className="avatar-generate-bar">
              <span>L’avatar sera conservé et réutilisé pour éviter toute nouvelle génération inutile.</span>
              <div className="avatar-generate-actions">
                <button type="button" disabled={avatarGenerating} onClick={() => void generateBaseAvatar()}>
                  {avatarGenerating ? "Génération en cours…" : "Générer mon avatar"}
                </button>
                <button className="avatar-generate-back" type="button" disabled={avatarGenerating} onClick={() => setStep(4)}>Retour</button>
              </div>
            </div>
          </div>
        )}

        {error && <p className="journey-error" role="alert">{error}</p>}
        {step > 1 && step < 5 && <div className="journey-actions">
          {step > 1 && <button className="journey-secondary" onClick={() => setStep((current) => current - 1)}>Retour</button>}
          <button className="journey-primary" onClick={next}>{step === 1 && !photos.faceFront ? "Utiliser l’avatar par défaut" : "Continuer"} <Arrow /></button>
        </div>}
      </section>

      {publicSettingsOpen && (
        <div className="public-settings-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setPublicSettingsOpen(false); }}>
          <section className="public-settings-dialog" role="dialog" aria-modal="true" aria-labelledby="public-settings-title">
            <header><strong id="public-settings-title">{language === "zh" ? "设置" : language === "en" ? "Settings" : "Paramètres"}</strong><button type="button" aria-label="Fermer" onClick={() => setPublicSettingsOpen(false)}>×</button></header>
            <span>{language === "zh" ? "语言" : language === "en" ? "Language" : "Langue"}</span>
            {(["fr", "en", "zh"] as AppLanguage[]).map((choice) => (
              <button className={language === choice ? "selected" : ""} type="button" key={choice} onClick={() => {
                localStorage.setItem("smartmirror-language", choice);
                document.documentElement.lang = choice;
                setPublicSettingsOpen(false);
                window.location.reload();
              }}><b>{choice === "fr" ? "🇫🇷" : choice === "en" ? "🇬🇧" : "🇨🇳"}</b>{choice === "fr" ? "Français" : choice === "en" ? "English" : "中文"}<i>{language === choice ? "✓" : ""}</i></button>
            ))}
          </section>
        </div>
      )}

      {authOpen && (
        <div className="auth-overlay" role="presentation" onMouseDown={(event) => {
          if (event.target === event.currentTarget && !authBusy) setAuthOpen(false);
        }}>
          <section className="auth-dialog" role="dialog" aria-modal="true" aria-labelledby="auth-title">
            <button className="auth-close" type="button" aria-label="Fermer" disabled={authBusy} onClick={() => setAuthOpen(false)}>×</button>
            <div className="auth-brand"><span>S</span><strong>SMART MIRROR</strong></div>
            <h2 id="auth-title">{authMethod === "code" ? "Entrez votre code" : "Connectez-vous pour continuer"}</h2>
            <p>{authMethod === "code" ? `Validation de démonstration pour ${authEmail.trim().toLowerCase()}.` : "Retrouvez votre avatar et vos essayages sur tous vos appareils."}</p>

            {authMethod === "choices" && (
              <div className="auth-options">
                <button className="auth-google" type="button" disabled={authBusy} onClick={() => void continueWithGoogle()}>
                  <svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M21.6 12.2c0-.7-.1-1.4-.2-2H12v3.9h5.4a4.6 4.6 0 0 1-2 3v2.6h3.3c1.9-1.8 2.9-4.4 2.9-7.5Z"/><path fill="#34A853" d="M12 22c2.7 0 5-.9 6.7-2.3l-3.3-2.6c-.9.6-2.1 1-3.4 1a5.9 5.9 0 0 1-5.5-4.1H3.1v2.7A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.5 14a6 6 0 0 1 0-3.9V7.4H3.1a10 10 0 0 0 0 9.3L6.5 14Z"/><path fill="#EA4335" d="M12 6c1.5 0 2.8.5 3.8 1.5l2.9-2.8A9.7 9.7 0 0 0 3.1 7.4l3.4 2.7A5.9 5.9 0 0 1 12 6Z"/></svg>
                  {authBusy ? "Connexion…" : "Continuer avec Google"}
                </button>
                <button className="auth-email" type="button" disabled={authBusy} onClick={() => { setAuthMethod("email"); setAuthMessage(""); }}>
                  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h18v14H3z"/><path d="m4 7 8 6 8-6"/></svg>
                  Continuer avec un e-mail
                </button>
              </div>
            )}

            {authMethod === "email" && (
              <form className="auth-form" onSubmit={(event) => { event.preventDefault(); void requestEmailCode(); }}>
                <label htmlFor="auth-email">Votre adresse e-mail</label>
                <input id="auth-email" type="email" autoComplete="email" autoFocus value={authEmail} onChange={(event) => setAuthEmail(event.target.value)} placeholder="nom@exemple.com" />
                <button type="submit" disabled={authBusy}>{authBusy ? "Envoi…" : "Recevoir mon code"}</button>
                <button className="auth-back" type="button" onClick={() => { setAuthMethod("choices"); setAuthMessage(""); }}>← Autre méthode</button>
              </form>
            )}

            {authMethod === "code" && (
              <form className="auth-form" onSubmit={(event) => { event.preventDefault(); void verifyEmailCode(); }}>
                <label htmlFor="auth-code">Code à 6 chiffres</label>
                <input id="auth-code" className="auth-code" inputMode="numeric" autoComplete="one-time-code" autoFocus maxLength={6} value={authCode} onChange={(event) => setAuthCode(event.target.value.replace(/\D/g, ""))} placeholder="000000" />
                <button type="submit" disabled={authBusy}>{authBusy ? "Vérification…" : "Vérifier et continuer"}</button>
                <button className="auth-back" type="button" onClick={() => { setAuthMethod("email"); setAuthCode(""); setAuthMessage(""); }}>← Modifier l’e-mail</button>
              </form>
            )}

            {authMessage && <p className="auth-message" role="status">{authMessage}</p>}
            <small className="auth-privacy">En continuant, vous acceptez les conditions d’utilisation et la politique de confidentialité de SMART MIRROR.</small>
          </section>
        </div>
      )}
    </main>
  );
}
