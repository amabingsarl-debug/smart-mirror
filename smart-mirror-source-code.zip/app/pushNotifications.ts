import type { User } from "firebase/auth";
import { deleteToken, getMessaging, getToken, isSupported } from "firebase/messaging";
import { firebaseApp } from "./firebaseClient";

const VAPID_KEY = "BGEE16zG2ucb-kpH31aKTP4DouIytEQKDRbAA1OqbarGesjoNEw-50VXfGV0gD-Tg4b-j9re1UX3jpgNBGGo1FU";

async function sendDeviceToken(user: User, token: string, action: "register" | "unregister") {
  const idToken = await user.getIdToken();
  const response = await fetch("/api/push-device", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${idToken}` },
    body: JSON.stringify({ token, action }),
  });
  if (!response.ok) throw new Error(`Enregistrement des notifications refusé (${response.status}).`);
}

export async function enablePushNotifications(user: User) {
  if (!(await isSupported()) || !("serviceWorker" in navigator) || !("Notification" in window)) return false;
  const permission = Notification.permission === "granted" ? "granted" : await Notification.requestPermission();
  if (permission !== "granted") return false;
  const registration = await navigator.serviceWorker.ready;
  const messaging = getMessaging(firebaseApp);
  const token = await getToken(messaging, { vapidKey: VAPID_KEY, serviceWorkerRegistration: registration });
  if (!token) return false;
  await sendDeviceToken(user, token, "register");
  sessionStorage.setItem("smartmirror-push-registered", user.uid);
  return true;
}

export async function disablePushNotifications(user: User) {
  if (!(await isSupported())) return;
  const messaging = getMessaging(firebaseApp);
  const registration = await navigator.serviceWorker.ready;
  const token = await getToken(messaging, { vapidKey: VAPID_KEY, serviceWorkerRegistration: registration }).catch(() => "");
  if (token) await sendDeviceToken(user, token, "unregister").catch(() => undefined);
  await deleteToken(messaging).catch(() => false);
  sessionStorage.removeItem("smartmirror-push-registered");
}
