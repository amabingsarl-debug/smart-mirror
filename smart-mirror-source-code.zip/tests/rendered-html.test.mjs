import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("documents the Smart Mirror product surface in the source", async () => {
  const [page, functions, firebaseConfig, manifest] = await Promise.all([
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../functions/main.py", import.meta.url), "utf8"),
    readFile(new URL("../firebase.json", import.meta.url), "utf8"),
    readFile(new URL("../public/manifest.webmanifest", import.meta.url), "utf8"),
  ]);

  assert.match(page, /SMART MIRROR/i);
  assert.match(page, /shopProducts/);
  assert.match(page, /generateTryOn/);
  assert.match(page, /createTryOnVideo/);
  assert.match(functions, /generate_tryon/);
  assert.match(functions, /generate_kling_video/);
  assert.match(functions, /Backblaze|B2_BUCKET/i);
  assert.match(functions, /Genblaze|Pipeline/i);
  assert.match(firebaseConfig, /generate-tryon/);
  assert.match(firebaseConfig, /kling-video/);
  assert.match(manifest, /SMART MIRROR/);
});
