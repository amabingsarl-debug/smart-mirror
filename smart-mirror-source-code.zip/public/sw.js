importScripts("https://www.gstatic.com/firebasejs/12.17.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/12.17.0/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyCpEfEfXeggfyRwq2R7KjcKWEu3Q7T_b_E",
  authDomain: "smartmirror-ci.firebaseapp.com",
  projectId: "smartmirror-ci",
  messagingSenderId: "709233619866",
  appId: "1:709233619866:web:0e111caa476cbbe6d44023",
});
firebase.messaging();

const CACHE = "smart-mirror-v144";
const AVATAR_CACHE = "smartmirror-avatar-media-v3";
const APP_SHELL = ["/manifest.webmanifest", "/icons/icon-192.png", "/icons/icon-512.png"];

function permanentMediaKey(url) {
  return new Request(`${url.origin}${url.pathname}`, { method: "GET" });
}

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE && key !== AVATAR_CACHE).map((key) => caches.delete(key))),
    ),
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== "GET") return;

  if (request.destination === "image") {
    event.respondWith(
      caches.open(AVATAR_CACHE).then(async (cache) => {
        const cached = await cache.match(request);
        if (cached) return cached;
        try {
          const response = await fetch(request);
          if (response.ok || response.type === "opaque") await cache.put(request, response.clone());
          return response;
        } catch (error) {
          const fallback = await caches.match(request);
          if (fallback) return fallback;
          throw error;
        }
      }),
    );
    return;
  }

  if (request.destination === "video") {
    event.respondWith(
      caches.open(AVATAR_CACHE).then(async (cache) => {
        const cacheKey = permanentMediaKey(url);
        const cached = await cache.match(cacheKey);
        if (cached) return cached;
        const response = await fetch(request);
        if ((response.ok || response.type === "opaque") && response.status !== 206) {
          await cache.put(cacheKey, response.clone());
        }
        return response;
      }),
    );
    return;
  }

  if (url.origin !== self.location.origin) return;

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request, { cache: "no-store" })
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put("/", copy));
          return response;
        })
        .catch(() => caches.match("/")),
    );
    return;
  }

  event.respondWith(
    fetch(request, { cache: "no-cache" })
      .then((response) => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put(request, copy));
        }
        return response;
      })
      .catch(() => caches.match(request)),
  );
});

self.addEventListener("message", (event) => {
  if (!["CACHE_AVATAR_IMAGES", "CACHE_MEDIA_URLS"].includes(event.data?.type) || !Array.isArray(event.data.urls)) return;
  const urls = event.data.urls.filter((url) => typeof url === "string" && /^https:\/\//.test(url));
  event.waitUntil(
    caches.open(AVATAR_CACHE).then((cache) =>
      Promise.allSettled(urls.map(async (url) => {
        const request = new Request(url, { mode: "no-cors", credentials: "omit" });
        const cacheKey = permanentMediaKey(new URL(url));
        if (await cache.match(cacheKey)) return;
        const response = await fetch(request);
        await cache.put(cacheKey, response);
      })),
    ),
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const destination = event.notification?.data?.url || "/?studio=1";
  event.waitUntil(clients.matchAll({ type: "window", includeUncontrolled: true }).then(async (windows) => {
    const existing = windows.find((client) => new URL(client.url).origin === self.location.origin);
    if (existing) {
      await existing.navigate(destination);
      return existing.focus();
    }
    return clients.openWindow(destination);
  }));
});
